library(ape)

#import each sequence list from its csv file
#NO "strings as factor"
tws<-read.table("./01_csvLists/12s.csv", quote="\"", stringsAsFactors=FALSE)
sts<-read.table("./01_csvLists/16s.csv", quote="\"", stringsAsFactors=FALSE)
bfb<-read.table("./01_csvLists/B-Fib.csv", quote="\"", stringsAsFactors=FALSE)
coi<-read.table("./01_csvLists/COI.csv", quote="\"", stringsAsFactors=FALSE)
cyt<-read.table("./01_csvLists/cytb.csv", quote="\"", stringsAsFactors=FALSE)
msk<-read.table("./01_csvLists/musk.csv", quote="\"", stringsAsFactors=FALSE)
ndo<-read.table("./01_csvLists/ND1.csv", quote="\"", stringsAsFactors=FALSE)
ndt<-read.table("./01_csvLists/ND2.csv", quote="\"", stringsAsFactors=FALSE)
ode<-read.table("./01_csvLists/OD.csv", quote="\"", stringsAsFactors=FALSE)
rag<-read.table("./01_csvLists/RAG1.csv", quote="\"", stringsAsFactors=FALSE)
tgf<-read.table("./01_csvLists/tgfb2.csv", quote="\"", stringsAsFactors=FALSE)
znk<-read.table("./01_csvLists/zenk.csv", quote="\"", stringsAsFactors=FALSE)


#convert to character lists
as.list(tws)$V1->tws.list
as.list(sts)$V1->sts.list
as.list(bfb)$V1->bfb.list
as.list(coi)$V1->coi.list
as.list(cyt)$V1->cyt.list
as.list(msk)$V1->msk.list
as.list(ndo)$V1->ndo.list
as.list(ndt)$V1->ndt.list
as.list(ode)$V1->ode.list
as.list(rag)$V1->rag.list
as.list(tgf)$V1->tgf.list
as.list(znk)$V1->znk.list



#use read.GenBank to acquire the sequences
tws.gen<-read.GenBank(tws.list,species.names=TRUE,gene.names=TRUE)
sts.gen<-read.GenBank(sts.list,species.names=TRUE,gene.names=TRUE)
bfb.gen<-read.GenBank(bfb.list,species.names=TRUE,gene.names=TRUE)
coi.gen<-read.GenBank(coi.list,species.names=TRUE,gene.names=TRUE)
cyt.gen<-read.GenBank(cyt.list,species.names=TRUE,gene.names=TRUE)
msk.gen<-read.GenBank(msk.list,species.names=TRUE,gene.names=TRUE)
ndo.gen<-read.GenBank(ndo.list,species.names=TRUE,gene.names=TRUE)
ndt.gen<-read.GenBank(ndt.list,species.names=TRUE,gene.names=TRUE)
ode.gen<-read.GenBank(ode.list,species.names=TRUE,gene.names=TRUE)
rag.gen<-read.GenBank(rag.list,species.names=TRUE,gene.names=TRUE)
tgf.gen<-read.GenBank(tgf.list,species.names=TRUE,gene.names=TRUE)
znk.gen<-read.GenBank(znk.list,species.names=TRUE,gene.names=TRUE)


#use species names
names.tws<-data.frame(species=attr(tws.gen,"species"),accs=names(tws.gen),
                      desc=attr(tws.gen,"description"));names.tws
names(tws.gen)<-attr(tws.gen,"species")
names.sts<-data.frame(species=attr(sts.gen,"species"),accs=names(sts.gen),
                      desc=attr(sts.gen,"description"));names.sts
names(sts.gen)<-attr(sts.gen,"species")
names.bfb<-data.frame(species=attr(bfb.gen,"species"),accs=names(bfb.gen),
                      desc=attr(bfb.gen,"description"));names.bfb
names(bfb.gen)<-attr(bfb.gen,"species")
names.coi<-data.frame(species=attr(coi.gen,"species"),accs=names(coi.gen),
                      desc=attr(coi.gen,"description"));names.coi
names(coi.gen)<-attr(coi.gen,"species")
names.cyt<-data.frame(species=attr(cyt.gen,"species"),accs=names(cyt.gen),
                      desc=attr(cyt.gen,"description"));names.cyt
names(cyt.gen)<-attr(cyt.gen,"species")
names.msk<-data.frame(species=attr(msk.gen,"species"),accs=names(msk.gen),
                      desc=attr(msk.gen,"description"));names.msk
names(msk.gen)<-attr(msk.gen,"species")
names.ndo<-data.frame(species=attr(ndo.gen,"species"),accs=names(ndo.gen),
                      desc=attr(ndo.gen,"description"));names.ndo
names(ndo.gen)<-attr(ndo.gen,"species")
names.ndt<-data.frame(species=attr(ndt.gen,"species"),accs=names(ndt.gen),
                      desc=attr(ndt.gen,"description"));names.ndt
names(ndt.gen)<-attr(ndt.gen,"species")
names.ode<-data.frame(species=attr(ode.gen,"species"),accs=names(ode.gen),
                      desc=attr(ode.gen,"description"));names.ode
names(ode.gen)<-attr(ode.gen,"species")
names.rag<-data.frame(species=attr(rag.gen,"species"),accs=names(rag.gen),
                      desc=attr(rag.gen,"description"));names.rag
names(rag.gen)<-attr(rag.gen,"species")
names.tgf<-data.frame(species=attr(tgf.gen,"species"),accs=names(tgf.gen),
                      desc=attr(tgf.gen,"description"));names.tgf
names(tgf.gen)<-attr(tgf.gen,"species")
names.znk<-data.frame(species=attr(znk.gen,"species"),accs=names(znk.gen),
                      desc=attr(znk.gen,"description"));names.znk
names(znk.gen)<-attr(znk.gen,"species")

#set WD

#export each
write.dna(tws.gen,file="./02_genbankFASTA/renamed_12s.fasta",  format="fasta")
write.dna(sts.gen,file="./02_genbankFASTA/renamed_16s.fasta",  format="fasta")
write.dna(bfb.gen,file="./02_genbankFASTA/renamed_B-Fib.fasta",format="fasta")
write.dna(coi.gen,file="./02_genbankFASTA/renamed_COI.fasta",  format="fasta")
write.dna(cyt.gen,file="./02_genbankFASTA/renamed_cytb.fasta", format="fasta")
write.dna(msk.gen,file="./02_genbankFASTA/renamed_musk.fasta", format="fasta")
write.dna(ndo.gen,file="./02_genbankFASTA/renamed_ND1.fasta",  format="fasta")
write.dna(ndt.gen,file="./02_genbankFASTA/renamed_ND2.fasta",  format="fasta")
write.dna(ode.gen,file="./02_genbankFASTA/renamed_OD.fasta",   format="fasta")
write.dna(rag.gen,file="./02_genbankFASTA/renamed_RAG1.fasta", format="fasta")
write.dna(tgf.gen,file="./02_genbankFASTA/renamed_tgfb2.fasta",format="fasta")
write.dna(znk.gen,file="./02_genbankFASTA/renamed_zenk.fasta", format="fasta")


