Data and code for "Range of motion in the avian wing is strongly associated with 
flight behavior and body mass" by Baliga, Szabo, and Altshuler
Questions/comments -> please contact Vikram Baliga.

This folder contains the materials used towards phylogenetic inference in our 
study. Folders are numbered to show the logical order in which we proceeded:

01_csvLists: lists of GenBank accession numbers; one for each gene. The 
   readGenBankR.R script was then used to download sequences
02_genbankFASTA: results of using readGenBankR.R to download sequences. Each in
   .fasta format
03_alignedSeqs: output after aligning sequences in Geneious and trimming 
   flanking regions
04_concatSeqs: sequences concatenated as one Nexus file
05_modelSelection: input files and output from partitionFinder analysis of 
   partitioning schemes
06_RAxML: input files and resulting output of using RAxML to infer trees via 
   maximum likelihood
07_BEAST: input files and resulting output of using BEAST to infer trees via 
   Bayesian methods. 
Although the full posterior distribution is not included, randomly sampled trees
  (of sample sizes
10, 100, 1000, and 10,000) are included after outgroup taxa were pruned, along 
   with the full MCC tree.