##this script runs MCMCglmm models for each extension ROM or wing shape related
##analysis. model selection via DIC & cross-validation for each type of analysis
##appears first. Then the best-fit models are re-run to compute coefficients
##...etc for Table S3.


############################### posterior trees ################################
## import posterior-distribution trees for effect size calculations
PDpruned<-read.tree("./trees/PDpruned_1Ktrees.tre")
## add in the MCC tree as the first listed tree
c(timetree,PDpruned)->PDpruned

####################### extension ROM cross-validation #########################
#cross-validation of MCMCglmm models using folds of species' data
#first organize the folds:
CS_sps<-list()
CS_dats<-list()
CS_tests<-list()
prior<-list(R=list(V=diag(3)/2,nu=5e-04),G=list(G1=list(V=diag(3)/2,nu=5e-04)))
set.seed(10)
for (i in 1:10){
  CS_sps[[i]]<-flightdf %>% group_by(flightgroup) %>%
    sample_frac(size=0.9) %>% data.frame()
  CS_dats[[i]]<-newdat[newdat$phylo %in% CS_sps[[i]]$phylo,]
  CS_tests[[i]]<-newdat[!newdat$phylo %in% CS_sps[[i]]$phylo,]
}

#then use parallel processing to efficiently run chains
library(parallel)
library(doParallel)
Sys.time()
timetree->inTree
inv.phylo<-inverseA(inTree,nodes="TIPS",scale=TRUE)
prior<-list(R=list(V=diag(3)/2,nu=5e-04),G=list(G1=list(V=diag(3)/2,nu=5e-04)))
setCores<-round(detectCores()*0.66) #use 66% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
  cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
  parallel::clusterExport(cl,"CS_dats")
  parallel::clusterExport(cl,"CS_tests")
  parallel::clusterExport(cl,"prior")
  parallel::clusterExport(cl,"inv.phylo")
  registerDoParallel(cl)
  seedlist<-c(rep(1000,setCores))
  parallel::clusterExport(cl,"seedlist")
  foreach(I=1:setCores) %dopar% {set.seed(seedlist[I])}
  NREPS<-length(CS_dats)
  CS_m08_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~flightgroup*LnMass-1,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=CS_dats[[i]],
             ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m08 done");Sys.time()
  CS_m04_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~flightgroup+LnMass-1,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=CS_dats[[i]],
             ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m04 done");Sys.time()
  CS_m02_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~flightgroup-1,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=CS_dats[[i]],
             ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m02 done");Sys.time()
  CS_m03_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~LnMass,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=CS_dats[[i]],
             ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m03 done");Sys.time()
  CS_m01_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~1,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=CS_dats[[i]],
             ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m01 done");Sys.time()
stopCluster(cl)
stopImplicitCluster()
registerDoSEQ()
Sys.time()

#MCMC diagnosis
#switch out the model objects as needed in the following functions
#Gelman-Rubin can be assessed via:
m6<-lapply(CS_m04_mods,function(m) m$Sol)
m6<-do.call(mcmc.list,m6)
gelman.diag(m6)
#autocorrelation:
autocorr(CS_m04_mods[[1]]$Sol[,1:10],lags=39)


#collect relevant metrics
#lambdas first, only for PC1 for simplicity
print("collecting PC1 lambda traces");Sys.time()
CS_m08_lambda_traces<-lapply(1:length(CS_m08_mods),
                             function(i){(CS_m08_mods[[i]]$VCV[,1])/(
                             CS_m08_mods[[i]]$VCV[,1]+CS_m08_mods[[i]]$VCV[,10])})
CS_m04_lambda_traces<-lapply(1:length(CS_m04_mods),
                             function(i){(CS_m04_mods[[i]]$VCV[,1])/(
                             CS_m04_mods[[i]]$VCV[,1]+CS_m04_mods[[i]]$VCV[,10])})
CS_m02_lambda_traces<-lapply(1:length(CS_m02_mods),
                             function(i){(CS_m02_mods[[i]]$VCV[,1])/(
                             CS_m02_mods[[i]]$VCV[,1]+CS_m02_mods[[i]]$VCV[,10])})
CS_m03_lambda_traces<-lapply(1:length(CS_m03_mods),
                             function(i){(CS_m03_mods[[i]]$VCV[,1])/(
                             CS_m03_mods[[i]]$VCV[,1]+CS_m03_mods[[i]]$VCV[,10])})
CS_m01_lambda_traces<-lapply(1:length(CS_m01_mods),
                             function(i){(CS_m01_mods[[i]]$VCV[,1])/(
                             CS_m01_mods[[i]]$VCV[,1]+CS_m01_mods[[i]]$VCV[,10])})


#"fits" = predictions of model for training data (i.e. data that were used to
# generate the model)
print("generating model fits");Sys.time()
CS_m08_fits<-lapply(CS_m08_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                    verbose=TRUE)
CS_m04_fits<-lapply(CS_m04_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                    verbose=TRUE)
CS_m02_fits<-lapply(CS_m02_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                    verbose=TRUE)
CS_m03_fits<-lapply(CS_m03_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                    verbose=TRUE)
CS_m01_fits<-lapply(CS_m01_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                    verbose=TRUE)

#"preds" = predictions on test data (data that were held out)
print("generating model predictions on test data");Sys.time()
CS_m08_preds<-lapply(1:length(CS_m08_mods),
                     function(i){
                       predict(CS_m08_mods[[i]],newdata=CS_tests[[i]],
                               marginal=NULL,posterior="all",verbose=TRUE)})
CS_m04_preds<-lapply(1:length(CS_m04_mods),
                     function(i){
                       predict(CS_m04_mods[[i]],newdata=CS_tests[[i]],
                               marginal=NULL,posterior="all",verbose=TRUE)})
CS_m02_preds<-lapply(1:length(CS_m02_mods),
                     function(i){
                       predict(CS_m02_mods[[i]],newdata=CS_tests[[i]],
                               marginal=NULL,posterior="all",verbose=TRUE)})
CS_m03_preds<-lapply(1:length(CS_m03_mods),
                     function(i){
                       predict(CS_m03_mods[[i]],newdata=CS_tests[[i]],
                               marginal=NULL,posterior="all",verbose=TRUE)})
CS_m01_preds<-lapply(1:length(CS_m01_mods),
                     function(i){
                       predict(CS_m01_mods[[i]],newdata=CS_tests[[i]],
                               marginal=NULL,posterior="all",verbose=TRUE)})

# reformat the original data to facilitate model fitting and comparisons
CS_PCstack<-(c(newdat$PC1,newdat$PC2,newdat$PC3))
CS_dats_PCstack<-list()
CS_tests_PCstack<-list()
for (i in 1:length(CS_dats)){
  CS_dats_PCstack[[i]]<-c(CS_dats[[i]]$PC1,CS_dats[[i]]$PC2,CS_dats[[i]]$PC3)
  CS_tests_PCstack[[i]]<-c(CS_tests[[i]]$PC1,CS_tests[[i]]$PC2,CS_tests[[i]]$PC3)
}

#set up a new cluster for linear model fitting and MSEs
setCores<-round(detectCores()*0.75) #use 75% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
  cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
  #parallel::clusterExport(cl,"CS_sps")
  parallel::clusterExport(cl,"CS_dats")
  parallel::clusterExport(cl,"CS_tests")
  print("re-importing fits and preds");Sys.time()
  parallel::clusterExport(cl,"CS_m08_fits")
  parallel::clusterExport(cl,"CS_m04_fits")
  parallel::clusterExport(cl,"CS_m02_fits")
  parallel::clusterExport(cl,"CS_m03_fits")
  parallel::clusterExport(cl,"CS_m01_fits")
  parallel::clusterExport(cl,"CS_m08_preds")
  parallel::clusterExport(cl,"CS_m04_preds")
  parallel::clusterExport(cl,"CS_m02_preds")
  parallel::clusterExport(cl,"CS_m03_preds")
  parallel::clusterExport(cl,"CS_m01_preds")
  parallel::clusterExport(cl,"CS_PCstack")
  parallel::clusterExport(cl,"CS_dats_PCstack")
  parallel::clusterExport(cl,"CS_tests_PCstack")

  #"fitsLMs" = fit lm()s to fits~training data
  print("generating LMs of fits ~ training data");Sys.time()
  CS_m08_fitsLMs<-parallel::parLapply(cl=cl,1:length(CS_m08_fits),
                                      function(i){
                                      lm(CS_m08_fits[[i]][1:56]~(CS_dats_PCstack[[i]][1:56]))
                                      })
  CS_m04_fitsLMs<-parallel::parLapply(cl=cl,1:length(CS_m04_fits),
                                      function(i){
                                      lm(CS_m04_fits[[i]][1:56]~(CS_dats_PCstack[[i]][1:56]))
                                      })
  CS_m02_fitsLMs<-parallel::parLapply(cl=cl,1:length(CS_m02_fits),
                                      function(i){
                                      lm(CS_m02_fits[[i]][1:56]~(CS_dats_PCstack[[i]][1:56]))
                                      })
  CS_m03_fitsLMs<-parallel::parLapply(cl=cl,1:length(CS_m03_fits),
                                      function(i){
                                      lm(CS_m03_fits[[i]][1:56]~(CS_dats_PCstack[[i]][1:56]))
                                      })
  CS_m01_fitsLMs<-parallel::parLapply(cl=cl,1:length(CS_m01_fits),
                                      function(i){
                                      lm(CS_m01_fits[[i]][1:56]~(CS_dats_PCstack[[i]][1:56]))
                                      })

  #"predsLMs" = fit lm()s to preds~training data
  print("generating LMs of preds ~ training data");Sys.time()
  CS_m08_predsLMs<-parallel::parLapply(cl=cl,1:length(CS_m08_preds),
                                       function(i){
                                       lm(CS_m08_preds[[i]][1:5]~(CS_tests_PCstack[[i]][1:5]))
                                       })
  CS_m04_predsLMs<-parallel::parLapply(cl=cl,1:length(CS_m04_preds),
                                       function(i){
                                       lm(CS_m04_preds[[i]][1:5]~(CS_tests_PCstack[[i]][1:5]))
                                       })
  CS_m02_predsLMs<-parallel::parLapply(cl=cl,1:length(CS_m02_preds),
                                       function(i){
                                       lm(CS_m02_preds[[i]][1:5]~(CS_tests_PCstack[[i]][1:5]))
                                       })
  CS_m03_predsLMs<-parallel::parLapply(cl=cl,1:length(CS_m03_preds),
                                       function(i){
                                       lm(CS_m03_preds[[i]][1:5]~(CS_tests_PCstack[[i]][1:5]))
                                       })
  CS_m01_predsLMs<-parallel::parLapply(cl=cl,1:length(CS_m01_preds),
                                       function(i){
                                       lm(CS_m01_preds[[i]][1:5]~(CS_tests_PCstack[[i]][1:5]))
                                       })

  #'fitsMSEs' and 'predMSEs' = mean squared error from each regression
  print("computing mean squared errors of fits");Sys.time()
  CS_m08_fitsMSEs<-parallel::parSapply(cl=cl,CS_m08_fitsLMs,mse)
  CS_m04_fitsMSEs<-parallel::parSapply(cl=cl,CS_m04_fitsLMs,mse)
  CS_m02_fitsMSEs<-parallel::parSapply(cl=cl,CS_m02_fitsLMs,mse)
  CS_m03_fitsMSEs<-parallel::parSapply(cl=cl,CS_m03_fitsLMs,mse)
  CS_m01_fitsMSEs<-parallel::parSapply(cl=cl,CS_m01_fitsLMs,mse)

  print("computing mean squared errors of predictions");Sys.time()
  CS_m08_predsMSEs<-parallel::parSapply(cl=cl,CS_m08_predsLMs,mse)
  CS_m04_predsMSEs<-parallel::parSapply(cl=cl,CS_m04_predsLMs,mse)
  CS_m02_predsMSEs<-parallel::parSapply(cl=cl,CS_m02_predsLMs,mse)
  CS_m03_predsMSEs<-parallel::parSapply(cl=cl,CS_m03_predsLMs,mse)
  CS_m01_predsMSEs<-parallel::parSapply(cl=cl,CS_m01_predsLMs,mse)

stopCluster(cl)
Sys.time()


#collect and re-format MSEs for plotting
CS_m08_fitsMSEs_df<-CS_m08_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
CS_m04_fitsMSEs_df<-CS_m04_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
CS_m02_fitsMSEs_df<-CS_m02_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
CS_m03_fitsMSEs_df<-CS_m03_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
CS_m01_fitsMSEs_df<-CS_m01_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
CS_m08_fitsMSEs_df$df<-24
CS_m04_fitsMSEs_df$df<-16
CS_m02_fitsMSEs_df$df<-15
CS_m03_fitsMSEs_df$df<-7
CS_m01_fitsMSEs_df$df<-1
CS_m08_predsMSEs_df<-CS_m08_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
CS_m04_predsMSEs_df<-CS_m04_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
CS_m02_predsMSEs_df<-CS_m02_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
CS_m03_predsMSEs_df<-CS_m03_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
CS_m01_predsMSEs_df<-CS_m01_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
CS_m08_predsMSEs_df$df<-24
CS_m04_predsMSEs_df$df<-16
CS_m02_predsMSEs_df$df<-15
CS_m03_predsMSEs_df$df<-7
CS_m01_predsMSEs_df$df<-1

CS_fitsMSEs<-rbind(CS_m08_fitsMSEs_df,
                   CS_m04_fitsMSEs_df,
                   CS_m02_fitsMSEs_df,
                   CS_m03_fitsMSEs_df,
                   CS_m01_fitsMSEs_df)
CS_predsMSEs<-rbind(CS_m08_predsMSEs_df,
                    CS_m04_predsMSEs_df,
                    CS_m02_predsMSEs_df,
                    CS_m03_predsMSEs_df,
                    CS_m01_predsMSEs_df)
CS_combinedMSEs<-left_join(CS_fitsMSEs,CS_predsMSEs,by='df')

#plot the MSEs
p <- ggplot(CS_predsMSEs, aes(df, predsMSEs))
p + geom_point(aes(group=df),col='red',alpha=0.1,size=2) + 
  geom_point(data=CS_fitsMSEs,aes(group=df,y=fitsMSEs),alpha=0.1,col='black',size=2)+
  stat_summary(aes(y=predsMSEs,group=1),fun.y=mean,colour="red",
               geom="point",group=1,size=4)+ 
  stat_summary(data=CS_fitsMSEs,aes(y=fitsMSEs,group=1),fun.y=mean,
               colour="black",geom="point",group=1,size=4)+ 
  theme_bw()

#mean MSE of training and test
aggregate(CS_fitsMSEs$fitsMSEs,list(CS_fitsMSEs$df),mean)
aggregate(CS_predsMSEs$predsMSEs,list(CS_predsMSEs$df),mean)

mean(ldply(sapply(CS_m08_mods,summary)[1,])$V1)
mean(ldply(lapply(CS_m08_lambda_traces,mean))$V1)

#to compute conditional R2s, use the code below
#switch out the models as necessary
#but remember that the number of columns in the $Sol and $VCV matrices will 
#change depending on the number of fixed effects or dependent variables
CS_m08_mods[[1]]->mmF;colnames(CS_m08_mods[[1]]$Sol)
mVarF <- var(as.vector(apply(mmF$Sol[,1:18],2,mean) %*% t(mmF$X)))
#mVarF <- var(as.vector(mean(mmF$Sol[,1]) %*% t(mmF$X)))
# MCMCglmm - marginal
mVarF/(mVarF+sum(apply(mmF$VCV,2,mean)))
# alternative with crebile intervals
vmVarF<-numeric(dim(mmF$VCV)[1])
for(i in 1:dim(mmF$VCV)[1]){
  Var<-var(as.vector(mmF$Sol[,1:18][i,] %*% t(mmF$X)))
  #Var<-var(as.vector(mmF$Sol[,1:1][i] %*% t(mmF$X)))
  vmVarF[i]<-Var}
R2m<-vmVarF/(vmVarF+mmF$VCV[,1]+mmF$VCV[,2])
mean(R2m)
posterior.mode(R2m)
HPDinterval(R2m)
# MCMCglmm - conditional
R2c<-as.mcmc((vmVarF+rowSums(mmF$VCV[,1:10]))/(vmVarF+rowSums(mmF$VCV)))
mean(R2c)
posterior.mode(R2c)
HPDinterval(R2c)

#################### effect sizes for extension ROM MCMCs ######################
# re-run models with full datasets. effect sizes measured via cohen's f2
# posterior trees will be used to determine the senstivity to phylogeny
# this will take some time

library(parallel)
Sys.time()
prior<-list(R=list(V=diag(3)/2,nu=5e-04),G=list(G1=list(V=diag(3)/2,nu=5e-04)))
setCores<-round(detectCores()*0.66) #use 66% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
  cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
  parallel::clusterExport(cl,"newdat")
  parallel::clusterExport(cl,"prior")
  parallel::clusterExport(cl,"PDpruned")
  NREPS<-length(PDpruned)
  CS_m04_fullMods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~flightgroup+LnMass-1,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=newdat,prior=prior,
             ginverse=list(phylo=inverseA(PDpruned[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m04 done");Sys.time()
  CS_m02_fullMods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~flightgroup-1,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=newdat,prior=prior,
             ginverse=list(phylo=inverseA(PDpruned[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m02 done");Sys.time()
  CS_m03_fullMods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~LnMass,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=newdat,prior=prior,
             ginverse=list(phylo=inverseA(PDpruned[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m03 done");Sys.time()
  CS_m01_fullMods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~1,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=newdat,prior=prior,
             ginverse=list(phylo=inverseA(PDpruned[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m01 done");Sys.time()
stopCluster(cl)
Sys.time()

#combine results
CS_m01_VCV<-do.call(mcmc.list,lapply(CS_m01_fullMods,function(m) m$VCV[,10:18]))
CS_m04_VCV<-do.call(mcmc.list,lapply(CS_m04_fullMods,function(m) m$VCV[,10:18]))
CS_m03_VCV<-do.call(mcmc.list,lapply(CS_m03_fullMods,function(m) m$VCV[,10:18]))
CS_m02_VCV<-do.call(mcmc.list,lapply(CS_m02_fullMods,function(m) m$VCV[,10:18]))

# Cohen's F2, computed via residual variance
CS_v_null_mods<-lapply(lapply(CS_m01_VCV,colMeans),mean)
CS_v_all_mods<-lapply(lapply(CS_m04_VCV,colMeans),mean)
CS_v_nofg_mods<-lapply(lapply(CS_m03_VCV,colMeans),mean)
CS_v_nomass_mods<-lapply(lapply(CS_m02_VCV,colMeans),mean)
CS_f2_fg<-NULL
CS_f2_mass<-NULL
for (i in 1:length(CS_v_all_mods)){
  CS_f2_fg[[i]]<-mean((((CS_v_null_mods[[i]]-CS_v_all_mods[[i]])/CS_v_null_mods[[i]])-((CS_v_null_mods[[i]]-CS_v_nofg_mods[[i]])/CS_v_null_mods[[i]]))/(1-(CS_v_null_mods[[i]]-CS_v_all_mods[[i]])/CS_v_null_mods[[i]]))
  CS_f2_mass[[i]]<-mean((((CS_v_null_mods[[i]]-CS_v_all_mods[[i]])/CS_v_null_mods[[i]])-((CS_v_null_mods[[i]]-CS_v_nomass_mods[[i]])/CS_v_null_mods[[i]]))/(1-(CS_v_null_mods[[i]]-CS_v_all_mods[[i]])/CS_v_null_mods[[i]]))
}

CS_f2s<-data.frame(flightBehavior=CS_f2_fg,
                   mass=CS_f2_mass)
quantile(CS_f2s$flightBehavior,c(0.05,0.5,0.95))
quantile(CS_f2s$mass,c(0.05,0.5,0.95))

CS_f2s_plot<-ggplot(CS_f2s) + 
  coord_cartesian(xlim=c(-0.1,.3)) +
  geom_density(aes(x=CS_f2_fg,y=..density..,fill='CS_f2_fg'))+
  geom_density(aes(x=CS_f2_mass,y=..density..,fill='CS_f2_mass'))+
  theme_ridges()
CS_f2s_plot

#lambda
quantile(melt(CS_m04_lambda_traces)[,1],c(0.025,0.5,0.975))
mean_hdi(melt(CS_m04_lambda_traces)$value)
median_hdi(melt(CS_m04_lambda_traces)$value)
mode_hdi(melt(CS_m04_lambda_traces)$value)

###################### Wing shape-space cross-validation #######################
#same process for the wing shape (static) data
#see commenting in previous section for clarification

STAT_sps<-list()
STAT_dats<-list()
STAT_tests<-list()
prior<-list(R=list(V=diag(3)/2,nu=5e-04),G=list(G1=list(V=diag(3)/2,nu=5e-04)))
set.seed(10)
for (i in 1:10){
  STAT_sps[[i]]<-flightdf %>% group_by(flightgroup) %>%
    sample_frac(size=0.9) %>% data.frame()
  STAT_dats[[i]]<-statdatdat[statdatdat$phylo %in% STAT_sps[[i]]$phylo,]
  STAT_tests[[i]]<-statdatdat[!statdatdat$phylo %in% STAT_sps[[i]]$phylo,]
}


library(parallel)
timetree->inTree
inv.phylo<-inverseA(inTree,nodes="TIPS",scale=TRUE)
prior<-list(R=list(V=diag(3)/2,nu=5e-04),G=list(G1=list(V=diag(3)/2,nu=5e-04)))
Sys.time()
setCores<-round(detectCores()*0.66) #use 66% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
  cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
  parallel::clusterExport(cl,"STAT_dats")
  parallel::clusterExport(cl,"STAT_tests")
  parallel::clusterExport(cl,"prior")
  parallel::clusterExport(cl,"inv.phylo")
  NREPS<-length(STAT_dats)
  STAT_m08_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~flightgroup*LnMass-1,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=STAT_dats[[i]],
             ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m08 done");Sys.time()
  STAT_m04_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~flightgroup+LnMass-1,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=STAT_dats[[i]],
             ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m04 done");Sys.time()
  STAT_m02_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~flightgroup-1,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=STAT_dats[[i]],
             ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m02 done");Sys.time()
  STAT_m03_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~LnMass,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=STAT_dats[[i]],
             ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m03 done");Sys.time()
  STAT_m01_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~1,
             family=c("gaussian","gaussian","gaussian"),
             random=~us(trait):phylo,scale=TRUE,data=STAT_dats[[i]],
             ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m01 done");Sys.time()
stopCluster(cl)
Sys.time()


#collect relevant metrics
#lambdas first, only for PC1 for simplicity
print("collecting PC1 lambda traces");Sys.time()
STAT_m08_lambda_traces<-lapply(1:length(STAT_m08_mods),
                               function(i){(STAT_m08_mods[[i]]$VCV[,1])/(
                                 STAT_m08_mods[[i]]$VCV[,1]+STAT_m08_mods[[i]]$VCV[,10])})
STAT_m04_lambda_traces<-lapply(1:length(STAT_m04_mods),
                               function(i){(STAT_m04_mods[[i]]$VCV[,1])/(
                                 STAT_m04_mods[[i]]$VCV[,1]+STAT_m04_mods[[i]]$VCV[,10])})
STAT_m02_lambda_traces<-lapply(1:length(STAT_m02_mods),
                               function(i){(STAT_m02_mods[[i]]$VCV[,1])/(
                                 STAT_m02_mods[[i]]$VCV[,1]+STAT_m02_mods[[i]]$VCV[,10])})
STAT_m03_lambda_traces<-lapply(1:length(STAT_m03_mods),
                               function(i){(STAT_m03_mods[[i]]$VCV[,1])/(
                                 STAT_m03_mods[[i]]$VCV[,1]+STAT_m03_mods[[i]]$VCV[,10])})
STAT_m01_lambda_traces<-lapply(1:length(STAT_m01_mods),
                               function(i){(STAT_m01_mods[[i]]$VCV[,1])/(
                                 STAT_m01_mods[[i]]$VCV[,1]+STAT_m01_mods[[i]]$VCV[,10])})


#"fits" = predictions of model for training data (i.e. data that were used to
# generate the model)
print("generating model fits");Sys.time()
STAT_m08_fits<-lapply(STAT_m08_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                      verbose=TRUE)
STAT_m04_fits<-lapply(STAT_m04_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                      verbose=TRUE)
STAT_m02_fits<-lapply(STAT_m02_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                      verbose=TRUE)
STAT_m03_fits<-lapply(STAT_m03_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                      verbose=TRUE)
STAT_m01_fits<-lapply(STAT_m01_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                      verbose=TRUE)


#"preds" = predictions on test data (data that were held out)
print("generating model predictions on test data");Sys.time()
STAT_m08_preds<-lapply(1:length(STAT_m08_mods),
                       function(i){
                         predict(STAT_m08_mods[[i]],newdata=STAT_tests[[i]],
                                 marginal=NULL,posterior="all",verbose=TRUE)})
STAT_m04_preds<-lapply(1:length(STAT_m04_mods),
                       function(i){
                         predict(STAT_m04_mods[[i]],newdata=STAT_tests[[i]],
                                 marginal=NULL,posterior="all",verbose=TRUE)})
STAT_m02_preds<-lapply(1:length(STAT_m02_mods),
                       function(i){
                         predict(STAT_m02_mods[[i]],newdata=STAT_tests[[i]],
                                 marginal=NULL,posterior="all",verbose=TRUE)})
STAT_m03_preds<-lapply(1:length(STAT_m03_mods),
                       function(i){
                         predict(STAT_m03_mods[[i]],newdata=STAT_tests[[i]],
                                 marginal=NULL,posterior="all",verbose=TRUE)})
STAT_m01_preds<-lapply(1:length(STAT_m01_mods),
                       function(i){
                         predict(STAT_m01_mods[[i]],newdata=STAT_tests[[i]],
                                 marginal=NULL,posterior="all",verbose=TRUE)})

# reformat the original data to facilitate model fitting and comparisons
STAT_PCstack<-(c(statdatdat$PC1,statdatdat$PC2,statdatdat$PC3))
STAT_dats_PCstack<-list()
STAT_tests_PCstack<-list()
for (i in 1:length(STAT_dats)){
  STAT_dats_PCstack[[i]]<-c(STAT_dats[[i]]$PC1,STAT_dats[[i]]$PC2,STAT_dats[[i]]$PC3)
  STAT_tests_PCstack[[i]]<-c(STAT_tests[[i]]$PC1,STAT_tests[[i]]$PC2,STAT_tests[[i]]$PC3)
}

#set up a new cluster for linear model fitting and MSEs
setCores<-round(detectCores()*0.75) #use 75% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
  cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
  parallel::clusterExport(cl,"STAT_sps")
  parallel::clusterExport(cl,"STAT_dats")
  parallel::clusterExport(cl,"STAT_tests")
  print("re-importing fits and preds");Sys.time()
  parallel::clusterExport(cl,"STAT_m08_fits")
  parallel::clusterExport(cl,"STAT_m04_fits")
  parallel::clusterExport(cl,"STAT_m02_fits")
  parallel::clusterExport(cl,"STAT_m03_fits")
  parallel::clusterExport(cl,"STAT_m01_fits")
  parallel::clusterExport(cl,"STAT_m08_preds")
  parallel::clusterExport(cl,"STAT_m04_preds")
  parallel::clusterExport(cl,"STAT_m02_preds")
  parallel::clusterExport(cl,"STAT_m03_preds")
  parallel::clusterExport(cl,"STAT_m01_preds")
  parallel::clusterExport(cl,"STAT_PCstack")
  parallel::clusterExport(cl,"STAT_dats_PCstack")
  parallel::clusterExport(cl,"STAT_tests_PCstack")
  
  #"fitsLMs" = fit lm()s to fits~training data
  print("generating LMs of fits ~ training data");Sys.time()
  STAT_m08_fitsLMs<-parallel::parLapply(cl=cl,1:length(STAT_m08_fits),
                                        function(i){
                                          lm(STAT_m08_fits[[i]][1:168]~(STAT_dats_PCstack[[i]][1:168]))
                                        })
  STAT_m04_fitsLMs<-parallel::parLapply(cl=cl,1:length(STAT_m04_fits),
                                        function(i){
                                          lm(STAT_m04_fits[[i]][1:168]~(STAT_dats_PCstack[[i]][1:168]))
                                        })
  STAT_m02_fitsLMs<-parallel::parLapply(cl=cl,1:length(STAT_m02_fits),
                                        function(i){
                                          lm(STAT_m02_fits[[i]][1:168]~(STAT_dats_PCstack[[i]][1:168]))
                                        })
  STAT_m03_fitsLMs<-parallel::parLapply(cl=cl,1:length(STAT_m03_fits),
                                        function(i){
                                          lm(STAT_m03_fits[[i]][1:168]~(STAT_dats_PCstack[[i]][1:168]))
                                        })
  STAT_m01_fitsLMs<-parallel::parLapply(cl=cl,1:length(STAT_m01_fits),
                                        function(i){
                                          lm(STAT_m01_fits[[i]][1:168]~(STAT_dats_PCstack[[i]][1:168]))
                                        })
  
  
  #"predsLMs" = fit lm()s to preds~training data
  print("generating LMs of preds ~ training data");Sys.time()
  STAT_m08_predsLMs<-parallel::parLapply(cl=cl,1:length(STAT_m08_preds),
                                         function(i){
                                           lm(STAT_m08_preds[[i]][1:15]~(STAT_tests_PCstack[[i]][1:15]))
                                         })
  STAT_m04_predsLMs<-parallel::parLapply(cl=cl,1:length(STAT_m04_preds),
                                         function(i){
                                           lm(STAT_m04_preds[[i]][1:15]~(STAT_tests_PCstack[[i]][1:15]))
                                         })
  STAT_m02_predsLMs<-parallel::parLapply(cl=cl,1:length(STAT_m02_preds),
                                         function(i){
                                           lm(STAT_m02_preds[[i]][1:15]~(STAT_tests_PCstack[[i]][1:15]))
                                         })
  STAT_m03_predsLMs<-parallel::parLapply(cl=cl,1:length(STAT_m03_preds),
                                         function(i){
                                           lm(STAT_m03_preds[[i]][1:15]~(STAT_tests_PCstack[[i]][1:15]))
                                         })
  STAT_m01_predsLMs<-parallel::parLapply(cl=cl,1:length(STAT_m01_preds),
                                         function(i){
                                           lm(STAT_m01_preds[[i]][1:15]~(STAT_tests_PCstack[[i]][1:15]))
                                         })
  
  
  #'fitsMSEs' and 'predMSEs' = mean squared error from each regression
  print("computing mean squared errors of fits");Sys.time()
  STAT_m08_fitsMSEs<-parallel::parSapply(cl=cl,STAT_m08_fitsLMs,mse)
  STAT_m04_fitsMSEs<-parallel::parSapply(cl=cl,STAT_m04_fitsLMs,mse)
  STAT_m02_fitsMSEs<-parallel::parSapply(cl=cl,STAT_m02_fitsLMs,mse)
  STAT_m03_fitsMSEs<-parallel::parSapply(cl=cl,STAT_m03_fitsLMs,mse)
  STAT_m01_fitsMSEs<-parallel::parSapply(cl=cl,STAT_m01_fitsLMs,mse)
  
  print("computing mean squared errors of predictions");Sys.time()
  STAT_m08_predsMSEs<-parallel::parSapply(cl=cl,STAT_m08_predsLMs,mse)
  STAT_m04_predsMSEs<-parallel::parSapply(cl=cl,STAT_m04_predsLMs,mse)
  STAT_m02_predsMSEs<-parallel::parSapply(cl=cl,STAT_m02_predsLMs,mse)
  STAT_m03_predsMSEs<-parallel::parSapply(cl=cl,STAT_m03_predsLMs,mse)
  STAT_m01_predsMSEs<-parallel::parSapply(cl=cl,STAT_m01_predsLMs,mse)

stopCluster(cl)
Sys.time()


#collect and re-format MSEs for plotting
STAT_m08_fitsMSEs_df<-STAT_m08_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
STAT_m04_fitsMSEs_df<-STAT_m04_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
STAT_m02_fitsMSEs_df<-STAT_m02_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
STAT_m03_fitsMSEs_df<-STAT_m03_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
STAT_m01_fitsMSEs_df<-STAT_m01_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
STAT_m08_fitsMSEs_df$df<-24
STAT_m04_fitsMSEs_df$df<-16
STAT_m02_fitsMSEs_df$df<-15
STAT_m03_fitsMSEs_df$df<-7
STAT_m01_fitsMSEs_df$df<-1
STAT_m08_predsMSEs_df<-STAT_m08_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
STAT_m04_predsMSEs_df<-STAT_m04_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
STAT_m02_predsMSEs_df<-STAT_m02_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
STAT_m03_predsMSEs_df<-STAT_m03_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
STAT_m01_predsMSEs_df<-STAT_m01_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
STAT_m08_predsMSEs_df$df<-24
STAT_m04_predsMSEs_df$df<-16
STAT_m02_predsMSEs_df$df<-15
STAT_m03_predsMSEs_df$df<-7
STAT_m01_predsMSEs_df$df<-1

STAT_fitsMSEs<-rbind(STAT_m08_fitsMSEs_df,
                     STAT_m04_fitsMSEs_df,
                     STAT_m02_fitsMSEs_df,
                     STAT_m03_fitsMSEs_df,
                     STAT_m01_fitsMSEs_df)
STAT_predsMSEs<-rbind(STAT_m08_predsMSEs_df,
                      STAT_m04_predsMSEs_df,
                      STAT_m02_predsMSEs_df,
                      STAT_m03_predsMSEs_df,
                      STAT_m01_predsMSEs_df)
STAT_combinedMSEs<-left_join(STAT_fitsMSEs,STAT_predsMSEs,by='df')


p <- ggplot(STAT_predsMSEs, aes(df, predsMSEs))
p + geom_point(aes(group=df),col='red',alpha=0.1,size=2) + 
  geom_point(data=STAT_fitsMSEs,aes(group=df,y=fitsMSEs),alpha=0.1,col='black',size=2)+
  stat_summary(aes(y=predsMSEs,group=1),fun.y=mean,colour="red",
               geom="point",group=1,size=4)+ 
  stat_summary(data=STAT_fitsMSEs,aes(y=fitsMSEs,group=1),fun.y=mean,
               colour="black",geom="point",group=1,size=4)+ 
  theme_bw()

aggregate(STAT_fitsMSEs$fitsMSEs,list(STAT_fitsMSEs$df),mean)
aggregate(STAT_predsMSEs$predsMSEs,list(STAT_predsMSEs$df),mean)


#################### effect sizes for wing shape MCMCs ######################
# re-run models with full datasets. effect sizes measured via cohen's f2

#first use PD trees to re-run pPCA on the eFourier coefficients
#this is because phylogenetic PCA will vary with the tree used
staticshapes.pPCA<-phyl.pca(timetree,staticshapes.eFourier[[1]],method='BM')

stat_pPCA_PDtrees<-NULL
for (i in 1:length(PDpruned)){
  stat_pPCA_PDtrees[[i]]<-phyl.pca(PDpruned[[i]],staticshapes.eFourier[[1]],
                                   method='BM')
}

stat_pPCA_PD_dats<-NULL
for (i in 1:length(stat_pPCA_PDtrees)){
  stat_pPCA_PD_dats[[i]]<-data.frame(phylo=statdatdat$phylo,
                                     stat_pPCA_PDtrees[[i]]$S,
                                     flightgroup=statdatdat$flightgroup,
                                     LnMass=statdatdat$LnMass)
}


library(parallel)
Sys.time()
prior<-list(R=list(V=diag(3)/2,nu=5e-04),G=list(G1=list(V=diag(3)/2,nu=5e-04)))
setCores<-round(detectCores()*0.66) #use 66% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
  cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
  parallel::clusterExport(cl,"stat_pPCA_PD_dats")
  parallel::clusterExport(cl,"prior")
  parallel::clusterExport(cl,"PDpruned")
  NREPS<-length(PDpruned)
  STAT_m04_fullMods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~flightgroup+LnMass-1,
             family=c("gaussian","gaussian","gaussian"),prior=prior,
             random=~us(trait):phylo,scale=TRUE,data=stat_pPCA_PD_dats[[i]],
             ginverse=list(phylo=inverseA(PDpruned[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m04 done");Sys.time()
  STAT_m02_fullMods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~flightgroup-1,
             family=c("gaussian","gaussian","gaussian"),prior=prior,
             random=~us(trait):phylo,scale=TRUE,data=stat_pPCA_PD_dats[[i]],
             ginverse=list(phylo=inverseA(PDpruned[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m02 done");Sys.time()
  STAT_m03_fullMods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~LnMass,
             family=c("gaussian","gaussian","gaussian"),prior=prior,
             random=~us(trait):phylo,scale=TRUE,data=stat_pPCA_PD_dats[[i]],
             ginverse=list(phylo=inverseA(PDpruned[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m03 done");Sys.time()
  STAT_m01_fullMods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(cbind(PC1,PC2,PC3)~1,
             family=c("gaussian","gaussian","gaussian"),prior=prior,
             random=~us(trait):phylo,scale=TRUE,data=stat_pPCA_PD_dats[[i]],
             ginverse=list(phylo=inverseA(PDpruned[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,rcov=~us(trait):units,
             nitt=45000,burnin=4500,thin=39)})
  print("m01 done");Sys.time()
stopCluster(cl)
Sys.time()

#combine results
STAT_m01_VCV<-do.call(mcmc.list,lapply(STAT_m01_fullMods,function(m) m$VCV[,10:18]))
STAT_m04_VCV<-do.call(mcmc.list,lapply(STAT_m04_fullMods,function(m) m$VCV[,10:18]))
STAT_m03_VCV<-do.call(mcmc.list,lapply(STAT_m03_fullMods,function(m) m$VCV[,10:18]))
STAT_m02_VCV<-do.call(mcmc.list,lapply(STAT_m02_fullMods,function(m) m$VCV[,10:18]))

# Cohen's F2, computed via residual variance
STAT_v_null_mods<-lapply(lapply(STAT_m01_VCV,colMeans),mean)
STAT_v_all_mods<-lapply(lapply(STAT_m04_VCV,colMeans),mean)
STAT_v_nofg_mods<-lapply(lapply(STAT_m03_VCV,colMeans),mean)
STAT_v_nomass_mods<-lapply(lapply(STAT_m02_VCV,colMeans),mean)
STAT_f2_fg<-NULL
STAT_f2_mass<-NULL
for (i in 1:length(STAT_v_all_mods)){
  STAT_f2_fg[[i]]<-mean((((STAT_v_null_mods[[i]]-STAT_v_all_mods[[i]])/STAT_v_null_mods[[i]])-((STAT_v_null_mods[[i]]-STAT_v_nofg_mods[[i]])/STAT_v_null_mods[[i]]))/(1-(STAT_v_null_mods[[i]]-STAT_v_all_mods[[i]])/STAT_v_null_mods[[i]]))
  STAT_f2_mass[[i]]<-mean((((STAT_v_null_mods[[i]]-STAT_v_all_mods[[i]])/STAT_v_null_mods[[i]])-((STAT_v_null_mods[[i]]-STAT_v_nomass_mods[[i]])/STAT_v_null_mods[[i]]))/(1-(STAT_v_null_mods[[i]]-STAT_v_all_mods[[i]])/STAT_v_null_mods[[i]]))
}

STAT_f2s<-data.frame(flightBehavior=STAT_f2_fg,
                     mass=STAT_f2_mass)
quantile(STAT_f2s$flightBehavior,c(0.05,0.5,0.95))
quantile(STAT_f2s$mass,c(0.05,0.5,0.95))

STAT_f2s_plot<-ggplot(STAT_f2s) + 
  coord_cartesian(xlim=c(-0.5,.5)) +
  geom_density(aes(x=STAT_f2_fg,y=..density..,fill='STAT_f2_fg'))+
  geom_density(aes(x=STAT_f2_mass,y=..density..,fill='STAT_f2_mass'))+
  theme_ridges()
STAT_f2s_plot

#lambda
quantile(melt(STAT_m04_lambda_traces)[,1],c(0.025,0.5,0.975))
mean_hdi(melt(STAT_m04_lambda_traces)$value)
median_hdi(melt(STAT_m04_lambda_traces)$value)
mode_hdi(melt(STAT_m04_lambda_traces)$value)

#################### linkage trajectory cross-validation #######################
#the procedure is largely the same as above, but
#the dependent variable is univariate
#and the models have different combinations of fixed effects

LT_sps<-list()
LT_dats<-list()
LT_tests<-list()
prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))
set.seed(10)
for (i in 1:10){
  LT_sps[[i]]<-flightdf %>% group_by(flightgroup) %>%
    sample_frac(size=0.9) %>% data.frame()
  LT_dats[[i]]<-dat[dat$phylo %in% LT_sps[[i]]$phylo,]
  LT_tests[[i]]<-dat[!dat$phylo %in% LT_sps[[i]]$phylo,]
}


library(parallel)
Sys.time()
timetree->inTree
inv.phylo<-inverseA(inTree,nodes="TIPS",scale=TRUE)
prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))
setCores<-round(detectCores()*0.66) #use 75% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
parallel::clusterExport(cl,"LT_dats")
parallel::clusterExport(cl,"LT_tests")
parallel::clusterExport(cl,"prior")
parallel::clusterExport(cl,"inv.phylo")
NREPS<-length(LT_dats)
LT_m56_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(manusAngle)~log(elbowAngle)+flightgroup+LnMass+
             flightgroup:log(elbowAngle)+
             LnMass:log(elbowAngle)-1,
           random=~phylo,scale=TRUE,data=LT_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m56 done");Sys.time()
LT_m24_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(manusAngle)~log(elbowAngle)+flightgroup+LnMass+
             flightgroup:log(elbowAngle)-1,
           random=~phylo,scale=TRUE,data=LT_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m24 done");Sys.time()
LT_m22_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(manusAngle)~log(elbowAngle)+flightgroup+
             flightgroup:log(elbowAngle)-1,
           random=~phylo,scale=TRUE,data=LT_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m22 done");Sys.time()
LT_m40_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(manusAngle)~log(elbowAngle)+flightgroup+LnMass+
             LnMass:log(elbowAngle)-1,
           random=~phylo,scale=TRUE,data=LT_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m40 done");Sys.time()
LT_m08_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(manusAngle)~log(elbowAngle)+flightgroup+LnMass-1,
           random=~phylo,scale=TRUE,data=LT_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m08 done");Sys.time()
LT_m06_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(manusAngle)~log(elbowAngle)+flightgroup-1,
           random=~phylo,scale=TRUE,data=LT_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m06 done");Sys.time()
LT_m07_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(manusAngle)~log(elbowAngle)+LnMass,
           random=~phylo,scale=TRUE,data=LT_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m07 done");Sys.time()
LT_m05_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(manusAngle)~log(elbowAngle),
           random=~phylo,scale=TRUE,data=LT_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m05 done");Sys.time()

stopCluster(cl)
Sys.time()


#collect relevant metrics
#lambdas first
print("collecting lambda traces");Sys.time()
LT_m56_lambda_traces<-lapply(1:length(LT_m56_mods),
                             function(i){(LT_m56_mods[[i]]$VCV[,1])/(
                               LT_m56_mods[[i]]$VCV[,1]+LT_m56_mods[[i]]$VCV[,2])})
LT_m24_lambda_traces<-lapply(1:length(LT_m24_mods),
                             function(i){(LT_m24_mods[[i]]$VCV[,1])/(
                               LT_m24_mods[[i]]$VCV[,1]+LT_m24_mods[[i]]$VCV[,2])})
LT_m22_lambda_traces<-lapply(1:length(LT_m22_mods),
                             function(i){(LT_m22_mods[[i]]$VCV[,1])/(
                               LT_m22_mods[[i]]$VCV[,1]+LT_m22_mods[[i]]$VCV[,2])})
LT_m40_lambda_traces<-lapply(1:length(LT_m40_mods),
                             function(i){(LT_m40_mods[[i]]$VCV[,1])/(
                               LT_m40_mods[[i]]$VCV[,1]+LT_m40_mods[[i]]$VCV[,2])})
LT_m08_lambda_traces<-lapply(1:length(LT_m08_mods),
                             function(i){(LT_m08_mods[[i]]$VCV[,1])/(
                               LT_m08_mods[[i]]$VCV[,1]+LT_m08_mods[[i]]$VCV[,2])})
LT_m06_lambda_traces<-lapply(1:length(LT_m06_mods),
                             function(i){(LT_m06_mods[[i]]$VCV[,1])/(
                               LT_m06_mods[[i]]$VCV[,1]+LT_m06_mods[[i]]$VCV[,2])})
LT_m07_lambda_traces<-lapply(1:length(LT_m07_mods),
                             function(i){(LT_m07_mods[[i]]$VCV[,1])/(
                               LT_m07_mods[[i]]$VCV[,1]+LT_m07_mods[[i]]$VCV[,2])})
LT_m05_lambda_traces<-lapply(1:length(LT_m05_mods),
                             function(i){(LT_m05_mods[[i]]$VCV[,1])/(
                               LT_m05_mods[[i]]$VCV[,1]+LT_m05_mods[[i]]$VCV[,2])})


#"fits" = predictions of model for training data (i.e. data that were used to
# generate the model)
print("generating model fits");Sys.time()
LT_m56_fits<-lapply(LT_m56_mods,predict.MCMCglmm,marginal=NULL)
LT_m24_fits<-lapply(LT_m24_mods,predict.MCMCglmm,marginal=NULL)
LT_m22_fits<-lapply(LT_m22_mods,predict.MCMCglmm,marginal=NULL)
LT_m40_fits<-lapply(LT_m40_mods,predict.MCMCglmm,marginal=NULL)
LT_m08_fits<-lapply(LT_m08_mods,predict.MCMCglmm,marginal=NULL)
LT_m06_fits<-lapply(LT_m06_mods,predict.MCMCglmm,marginal=NULL)
LT_m07_fits<-lapply(LT_m07_mods,predict.MCMCglmm,marginal=NULL)
LT_m05_fits<-lapply(LT_m05_mods,predict.MCMCglmm,marginal=NULL)


#"preds" = predictions on test data (data that were held out)
print("generating model predictions on test data");Sys.time()
LT_m56_preds<-lapply(1:length(LT_m56_mods),
                     function(i){
                       predict(LT_m56_mods[[i]],newdata=LT_tests[[i]],
                               marginal=NULL)})
LT_m24_preds<-lapply(1:length(LT_m24_mods),
                     function(i){
                       predict(LT_m24_mods[[i]],newdata=LT_tests[[i]],
                               marginal=NULL)})
LT_m22_preds<-lapply(1:length(LT_m22_mods),
                     function(i){
                       predict(LT_m22_mods[[i]],newdata=LT_tests[[i]],
                               marginal=NULL)})
LT_m40_preds<-lapply(1:length(LT_m40_mods),
                     function(i){
                       predict(LT_m40_mods[[i]],newdata=LT_tests[[i]],
                               marginal=NULL)})
LT_m08_preds<-lapply(1:length(LT_m08_mods),
                     function(i){
                       predict(LT_m08_mods[[i]],newdata=LT_tests[[i]],
                               marginal=NULL)})
LT_m06_preds<-lapply(1:length(LT_m06_mods),
                     function(i){
                       predict(LT_m06_mods[[i]],newdata=LT_tests[[i]],
                               marginal=NULL)})
LT_m07_preds<-lapply(1:length(LT_m07_mods),
                     function(i){
                       predict(LT_m07_mods[[i]],newdata=LT_tests[[i]],
                               marginal=NULL)})
LT_m05_preds<-lapply(1:length(LT_m05_mods),
                     function(i){
                       predict(LT_m05_mods[[i]],newdata=LT_tests[[i]],
                               marginal=NULL)})

#set up a new cluster for linear model fitting and MSEs
setCores<-round(detectCores()*0.75) #use 75% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
parallel::clusterExport(cl,"LT_dats")
parallel::clusterExport(cl,"LT_tests")
print("re-importing fits and preds");Sys.time()
parallel::clusterExport(cl,"LT_m56_fits")
parallel::clusterExport(cl,"LT_m24_fits")
parallel::clusterExport(cl,"LT_m22_fits")
parallel::clusterExport(cl,"LT_m40_fits")
parallel::clusterExport(cl,"LT_m08_fits")
parallel::clusterExport(cl,"LT_m06_fits")
parallel::clusterExport(cl,"LT_m07_fits")
parallel::clusterExport(cl,"LT_m05_fits")  
parallel::clusterExport(cl,"LT_m56_preds")
parallel::clusterExport(cl,"LT_m24_preds")
parallel::clusterExport(cl,"LT_m22_preds")
parallel::clusterExport(cl,"LT_m40_preds")
parallel::clusterExport(cl,"LT_m08_preds")
parallel::clusterExport(cl,"LT_m06_preds")
parallel::clusterExport(cl,"LT_m07_preds")
parallel::clusterExport(cl,"LT_m05_preds")

#"fitsLMs" = fit lm()s to fits~training data
print("generating LMs of fits ~ training data");Sys.time()
LT_m56_fitsLMs<-parallel::parLapply(cl=cl,1:length(LT_m56_fits),
                                    function(i){
                                      lm(LT_m56_fits[[i]]~log(LT_dats[[i]]$manusAngle))
                                    })
LT_m24_fitsLMs<-parallel::parLapply(cl=cl,1:length(LT_m24_fits),
                                    function(i){
                                      lm(LT_m24_fits[[i]]~log(LT_dats[[i]]$manusAngle))
                                    })
LT_m22_fitsLMs<-parallel::parLapply(cl=cl,1:length(LT_m22_fits),
                                    function(i){
                                      lm(LT_m22_fits[[i]]~log(LT_dats[[i]]$manusAngle))
                                    })
LT_m40_fitsLMs<-parallel::parLapply(cl=cl,1:length(LT_m40_fits),
                                    function(i){
                                      lm(LT_m40_fits[[i]]~log(LT_dats[[i]]$manusAngle))
                                    })
LT_m08_fitsLMs<-parallel::parLapply(cl=cl,1:length(LT_m08_fits),
                                    function(i){
                                      lm(LT_m08_fits[[i]]~log(LT_dats[[i]]$manusAngle))
                                    })
LT_m06_fitsLMs<-parallel::parLapply(cl=cl,1:length(LT_m06_fits),
                                    function(i){
                                      lm(LT_m06_fits[[i]]~log(LT_dats[[i]]$manusAngle))
                                    })
LT_m07_fitsLMs<-parallel::parLapply(cl=cl,1:length(LT_m07_fits),
                                    function(i){
                                      lm(LT_m07_fits[[i]]~log(LT_dats[[i]]$manusAngle))
                                    })
LT_m05_fitsLMs<-parallel::parLapply(cl=cl,1:length(LT_m05_fits),
                                    function(i){
                                      lm(LT_m05_fits[[i]]~log(LT_dats[[i]]$manusAngle))
                                    })


#"predsLMs" = fit lm()s to preds~training data
print("generating LMs of preds ~ training data");Sys.time()
LT_m56_predsLMs<-parallel::parLapply(cl=cl,1:length(LT_m56_preds),
                                     function(i){
                                       lm(LT_m56_preds[[i]]~log(LT_tests[[i]]$manusAngle))
                                     })
LT_m24_predsLMs<-parallel::parLapply(cl=cl,1:length(LT_m24_preds),
                                     function(i){
                                       lm(LT_m24_preds[[i]]~log(LT_tests[[i]]$manusAngle))
                                     })
LT_m22_predsLMs<-parallel::parLapply(cl=cl,1:length(LT_m22_preds),
                                     function(i){
                                       lm(LT_m22_preds[[i]]~log(LT_tests[[i]]$manusAngle))
                                     })
LT_m40_predsLMs<-parallel::parLapply(cl=cl,1:length(LT_m40_preds),
                                     function(i){
                                       lm(LT_m40_preds[[i]]~log(LT_tests[[i]]$manusAngle))
                                     })
LT_m08_predsLMs<-parallel::parLapply(cl=cl,1:length(LT_m08_preds),
                                     function(i){
                                       lm(LT_m08_preds[[i]]~log(LT_tests[[i]]$manusAngle))
                                     })
LT_m06_predsLMs<-parallel::parLapply(cl=cl,1:length(LT_m06_preds),
                                     function(i){
                                       lm(LT_m06_preds[[i]]~log(LT_tests[[i]]$manusAngle))
                                     })
LT_m07_predsLMs<-parallel::parLapply(cl=cl,1:length(LT_m07_preds),
                                     function(i){
                                       lm(LT_m07_preds[[i]]~log(LT_tests[[i]]$manusAngle))
                                     })
LT_m05_predsLMs<-parallel::parLapply(cl=cl,1:length(LT_m05_preds),
                                     function(i){
                                       lm(LT_m05_preds[[i]]~log(LT_tests[[i]]$manusAngle))
                                     })


#'fitsMSEs' and 'predMSEs' = mean squared error from each regression
print("computing mean squared errors of fits");Sys.time()
LT_m56_fitsMSEs<-parallel::parSapply(cl=cl,LT_m56_fitsLMs,mse)
LT_m24_fitsMSEs<-parallel::parSapply(cl=cl,LT_m24_fitsLMs,mse)
LT_m22_fitsMSEs<-parallel::parSapply(cl=cl,LT_m22_fitsLMs,mse)
LT_m40_fitsMSEs<-parallel::parSapply(cl=cl,LT_m40_fitsLMs,mse)
LT_m08_fitsMSEs<-parallel::parSapply(cl=cl,LT_m08_fitsLMs,mse)
LT_m06_fitsMSEs<-parallel::parSapply(cl=cl,LT_m06_fitsLMs,mse)
LT_m07_fitsMSEs<-parallel::parSapply(cl=cl,LT_m07_fitsLMs,mse)
LT_m05_fitsMSEs<-parallel::parSapply(cl=cl,LT_m05_fitsLMs,mse)

print("computing mean squared errors of predictions");Sys.time()
LT_m56_predsMSEs<-parallel::parSapply(cl=cl,LT_m56_predsLMs,mse)
LT_m24_predsMSEs<-parallel::parSapply(cl=cl,LT_m24_predsLMs,mse)
LT_m22_predsMSEs<-parallel::parSapply(cl=cl,LT_m22_predsLMs,mse)
LT_m40_predsMSEs<-parallel::parSapply(cl=cl,LT_m40_predsLMs,mse)
LT_m08_predsMSEs<-parallel::parSapply(cl=cl,LT_m08_predsLMs,mse)
LT_m06_predsMSEs<-parallel::parSapply(cl=cl,LT_m06_predsLMs,mse)
LT_m07_predsMSEs<-parallel::parSapply(cl=cl,LT_m07_predsLMs,mse)
LT_m05_predsMSEs<-parallel::parSapply(cl=cl,LT_m05_predsLMs,mse)

stopCluster(cl)
Sys.time()


#model complexity order: 
#m56:22df
#m24:21df
#m22:20df
#m40:14df
#m08:13df
#m06:12df
#m07:4df
#m05:3df

#collect and re-format MSEs for plotting
LT_m56_fitsMSEs_df<-LT_m56_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
LT_m24_fitsMSEs_df<-LT_m24_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
LT_m22_fitsMSEs_df<-LT_m22_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
LT_m40_fitsMSEs_df<-LT_m40_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
LT_m08_fitsMSEs_df<-LT_m08_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
LT_m06_fitsMSEs_df<-LT_m06_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
LT_m07_fitsMSEs_df<-LT_m07_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
LT_m05_fitsMSEs_df<-LT_m05_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
LT_m56_fitsMSEs_df$df<-22
LT_m24_fitsMSEs_df$df<-21
LT_m22_fitsMSEs_df$df<-20
LT_m40_fitsMSEs_df$df<-14
LT_m08_fitsMSEs_df$df<-13
LT_m06_fitsMSEs_df$df<-12
LT_m07_fitsMSEs_df$df<-4
LT_m05_fitsMSEs_df$df<-3
LT_m56_predsMSEs_df<-LT_m56_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
LT_m24_predsMSEs_df<-LT_m24_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
LT_m22_predsMSEs_df<-LT_m22_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
LT_m40_predsMSEs_df<-LT_m40_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
LT_m08_predsMSEs_df<-LT_m08_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
LT_m06_predsMSEs_df<-LT_m06_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
LT_m07_predsMSEs_df<-LT_m07_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
LT_m05_predsMSEs_df<-LT_m05_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
LT_m56_predsMSEs_df$df<-22
LT_m24_predsMSEs_df$df<-21
LT_m22_predsMSEs_df$df<-20
LT_m40_predsMSEs_df$df<-14
LT_m08_predsMSEs_df$df<-13
LT_m06_predsMSEs_df$df<-12
LT_m07_predsMSEs_df$df<-4
LT_m05_predsMSEs_df$df<-3

LT_fitsMSEs<-rbind(LT_m56_fitsMSEs_df,
                   LT_m24_fitsMSEs_df,
                   LT_m22_fitsMSEs_df,
                   LT_m40_fitsMSEs_df,
                   LT_m08_fitsMSEs_df,
                   LT_m06_fitsMSEs_df,
                   LT_m07_fitsMSEs_df,
                   LT_m05_fitsMSEs_df)
LT_predsMSEs<-rbind(LT_m56_predsMSEs_df,
                    LT_m24_predsMSEs_df,
                    LT_m22_predsMSEs_df,
                    LT_m40_predsMSEs_df,
                    LT_m08_predsMSEs_df,
                    LT_m06_predsMSEs_df,
                    LT_m07_predsMSEs_df,
                    LT_m05_predsMSEs_df)
LT_combinedMSEs<-left_join(LT_fitsMSEs,LT_predsMSEs,by='df')


p <- ggplot(LT_combinedMSEs, aes(df, predsMSEs))
p + geom_point(aes(group=df,y=predsMSEs),col='red',alpha=0.1,size=2) + 
  geom_point(aes(group=df,y=fitsMSEs),size=2,alpha=0.1) + 
  stat_summary(aes(y=predsMSEs,group=1),fun.y=mean,colour="red",
               geom="point",group=1,size=5)+ 
  theme_bw()



p <- ggplot(LT_predsMSEs, aes(df, predsMSEs))
p + geom_point(aes(group=df),col='red',alpha=0.1,size=2) + 
  geom_point(data=LT_fitsMSEs,aes(group=df,y=fitsMSEs),alpha=0.1,col='black',size=2)+
  stat_summary(aes(y=predsMSEs,group=1),fun.y=mean,colour="red",
               geom="point",group=1,size=4)+ 
  stat_summary(data=LT_fitsMSEs,aes(y=fitsMSEs,group=1),fun.y=mean,
               colour="black",geom="point",group=1,size=4)+ 
  theme_bw()

#mean MSEs
aggregate(LT_fitsMSEs$fitsMSEs,list(LT_fitsMSEs$df),mean)
aggregate(LT_predsMSEs$predsMSEs,list(LT_predsMSEs$df),mean)

mean(ldply(sapply(LT_m56_mods,summary)[1,])$V1)
mean(ldply(lapply(LT_m56_lambda_traces,mean))$V1)

#R2s
LT_m22_mods[[1]]->mmF;colnames(LT_m22_mods[[1]]$Sol)
mVarF <- var(as.vector(apply(mmF$Sol[,1:18],2,mean) %*% t(mmF$X)))
#mVarF <- var(as.vector(mean(mmF$Sol[,1]) %*% t(mmF$X)))
# MCMCglmm - marginal
mVarF/(mVarF+sum(apply(mmF$VCV,2,mean)))
# alternative with crebile intervals
vmVarF<-numeric(dim(mmF$VCV)[1])
for(i in 1:dim(mmF$VCV)[1]){
  Var<-var(as.vector(mmF$Sol[,1:18][i,] %*% t(mmF$X)))
  #Var<-var(as.vector(mmF$Sol[,1:1][i] %*% t(mmF$X)))
  vmVarF[i]<-Var}
R2m<-vmVarF/(vmVarF+mmF$VCV[,1]+mmF$VCV[,2])
mean(R2m)
posterior.mode(R2m)
HPDinterval(R2m)
# MCMCglmm - conditional
R2c<-as.mcmc((vmVarF+mmF$VCV[,1])/(vmVarF+rowSums(mmF$VCV)))
mean(R2c)
posterior.mode(R2c)
HPDinterval(R2c)


#################### effect sizes for linkage trajectory MCMCs ######################
# re-run models with full datasets. effect sizes measured via cohen's f2

prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))
library(parallel)
Sys.time()
setCores<-round(detectCores()*0.66) #use 66% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
  cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
  parallel::clusterExport(cl,"dat")
  parallel::clusterExport(cl,"prior")
  parallel::clusterExport(cl,"PDpruned")
  NREPS<-length(PDpruned)
  LT_m24_fullMods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(log(manusAngle)~log(elbowAngle)+flightgroup+LnMass+
               flightgroup:log(elbowAngle)-1,
             random=~phylo,scale=TRUE,data=dat,prior=prior,
             ginverse=list(phylo=inverseA(PDpruned[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,
             nitt=15000,burnin=1500,thin=13)})
  print("m24 done");Sys.time()
  LT_m22_fullMods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(log(manusAngle)~log(elbowAngle)+flightgroup+
               flightgroup:log(elbowAngle)-1,
             random=~phylo,scale=TRUE,data=dat,prior=prior,
             ginverse=list(phylo=inverseA(PDpruned[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,
             nitt=15000,burnin=1500,thin=13)})
  print("m22 done");Sys.time()
  LT_m07_fullMods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(log(manusAngle)~log(elbowAngle)+LnMass,
             random=~phylo,scale=TRUE,data=dat,prior=prior,
             ginverse=list(phylo=inverseA(PDpruned[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,
             nitt=15000,burnin=1500,thin=13)})
  print("m07 done");Sys.time()
  LT_m05_fullMods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(log(manusAngle)~log(elbowAngle)-1,
             random=~phylo,scale=TRUE,data=dat,prior=prior,
             ginverse=list(phylo=inverseA(PDpruned[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,
             nitt=15000,burnin=1500,thin=13)})
  print("m01 done");Sys.time()
stopCluster(cl)
Sys.time()

#combine results
LT_m05_VCV<-do.call(mcmc.list,lapply(LT_m05_fullMods,function(m) m$VCV[,2]))
LT_m24_VCV<-do.call(mcmc.list,lapply(LT_m24_fullMods,function(m) m$VCV[,2]))
LT_m07_VCV<-do.call(mcmc.list,lapply(LT_m07_fullMods,function(m) m$VCV[,2]))
LT_m22_VCV<-do.call(mcmc.list,lapply(LT_m22_fullMods,function(m) m$VCV[,2]))

LT_v_null_mods<-lapply(LT_m05_VCV,mean)
LT_v_all_mods<-lapply(LT_m24_VCV,mean)
LT_v_nofg_mods<-lapply(LT_m07_VCV,mean)
LT_v_nomass_mods<-lapply(LT_m22_VCV,mean)

# Cohen's F2, computed via residual variance
LT_f2_fg<-NULL
LT_f2_mass<-NULL
for (i in 1:length(LT_v_all_mods)){
  LT_f2_fg[[i]]<-mean((((LT_v_null_mods[[i]]-LT_v_all_mods[[i]])/LT_v_null_mods[[i]])-((LT_v_null_mods[[i]]-LT_v_nofg_mods[[i]])/LT_v_null_mods[[i]]))/(1-(LT_v_null_mods[[i]]-LT_v_all_mods[[i]])/LT_v_null_mods[[i]]))
  LT_f2_mass[[i]]<-mean((((LT_v_null_mods[[i]]-LT_v_all_mods[[i]])/LT_v_null_mods[[i]])-((LT_v_null_mods[[i]]-LT_v_nomass_mods[[i]])/LT_v_null_mods[[i]]))/(1-(LT_v_null_mods[[i]]-LT_v_all_mods[[i]])/LT_v_null_mods[[i]]))
}

LT_f2s<-data.frame(flightBehavior=LT_f2_fg,
                   mass=LT_f2_mass)
quantile(LT_f2s$flightBehavior,c(0.05,0.5,0.95))
quantile(LT_f2s$mass,c(0.05,0.5,0.95))

LT_f2s_plot<-ggplot(LT_f2s) + 
  coord_cartesian(xlim=c(0,.5)) +
  geom_density(aes(x=LT_f2_fg,y=..density..,fill='LT_f2_fg'))+
  geom_density(aes(x=LT_f2_mass,y=..density..,fill='LT_f2_mass'))+
  theme_ridges()
LT_f2s_plot

#lambda
quantile(melt(LT_m22_lambda_traces)[,1],c(0.025,0.5,0.975))
mean_hdi(melt(LT_m22_lambda_traces)$value)
median_hdi(melt(LT_m22_lambda_traces)$value)
mode_hdi(melt(LT_m22_lambda_traces)$value)


#################### Aspect ratio vs LT cross-validation #######################
#again, univariate dependent variable
#similar to linkage trajectory analyses

AR_sps<-list()
AR_dats<-list()
AR_tests<-list()
prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))
set.seed(10)
for (i in 1:10){
  AR_sps[[i]]<-flightdf %>% group_by(flightgroup) %>%
    sample_frac(size=0.9) %>% data.frame()
  AR_dats[[i]]<-dat[dat$phylo %in% AR_sps[[i]]$phylo,]
  AR_tests[[i]]<-dat[!dat$phylo %in% AR_sps[[i]]$phylo,]
}

library(parallel)
Sys.time()
timetree->inTree
inv.phylo<-inverseA(inTree,nodes="TIPS",scale=TRUE)
prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))
setCores<-round(detectCores()*0.66) #use 75% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
parallel::clusterExport(cl,"AR_dats")
parallel::clusterExport(cl,"AR_tests")
parallel::clusterExport(cl,"prior")
parallel::clusterExport(cl,"inv.phylo")
NREPS<-length(AR_dats)
AR_m56_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(b2.s)~log(manusAngle)+flightgroup+LnMass+
             flightgroup:log(manusAngle)+
             LnMass:log(manusAngle)-1,
           random=~phylo,scale=TRUE,data=AR_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m56 done");Sys.time()
AR_m24_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(b2.s)~log(manusAngle)+flightgroup+LnMass+
             flightgroup:log(manusAngle)-1,
           random=~phylo,scale=TRUE,data=AR_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m24 done");Sys.time()
AR_m22_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(b2.s)~log(manusAngle)+flightgroup+
             flightgroup:log(manusAngle)-1,
           random=~phylo,scale=TRUE,data=AR_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m22 done");Sys.time()
AR_m40_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(b2.s)~log(manusAngle)+flightgroup+LnMass+
             LnMass:log(manusAngle)-1,
           random=~phylo,scale=TRUE,data=AR_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m40 done");Sys.time()
AR_m08_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(b2.s)~log(manusAngle)+flightgroup+LnMass-1,
           random=~phylo,scale=TRUE,data=AR_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m08 done");Sys.time()
AR_m06_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(b2.s)~log(manusAngle)+flightgroup-1,
           random=~phylo,scale=TRUE,data=AR_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m06 done");Sys.time()
AR_m07_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(b2.s)~log(manusAngle)+LnMass,
           random=~phylo,scale=TRUE,data=AR_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m07 done");Sys.time()
AR_m05_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(log(b2.s)~log(manusAngle),
           random=~phylo,scale=TRUE,data=AR_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m05 done");Sys.time()

stopCluster(cl)
Sys.time()


#collect relevant metrics
#lambdas first
print("collecting lambda traces");Sys.time()
AR_m56_lambda_traces<-lapply(1:length(AR_m56_mods),
                             function(i){(AR_m56_mods[[i]]$VCV[,1])/(
                               AR_m56_mods[[i]]$VCV[,1]+AR_m56_mods[[i]]$VCV[,2])})
AR_m24_lambda_traces<-lapply(1:length(AR_m24_mods),
                             function(i){(AR_m24_mods[[i]]$VCV[,1])/(
                               AR_m24_mods[[i]]$VCV[,1]+AR_m24_mods[[i]]$VCV[,2])})
AR_m22_lambda_traces<-lapply(1:length(AR_m22_mods),
                             function(i){(AR_m22_mods[[i]]$VCV[,1])/(
                               AR_m22_mods[[i]]$VCV[,1]+AR_m22_mods[[i]]$VCV[,2])})
AR_m40_lambda_traces<-lapply(1:length(AR_m40_mods),
                             function(i){(AR_m40_mods[[i]]$VCV[,1])/(
                               AR_m40_mods[[i]]$VCV[,1]+AR_m40_mods[[i]]$VCV[,2])})
AR_m08_lambda_traces<-lapply(1:length(AR_m08_mods),
                             function(i){(AR_m08_mods[[i]]$VCV[,1])/(
                               AR_m08_mods[[i]]$VCV[,1]+AR_m08_mods[[i]]$VCV[,2])})
AR_m06_lambda_traces<-lapply(1:length(AR_m06_mods),
                             function(i){(AR_m06_mods[[i]]$VCV[,1])/(
                               AR_m06_mods[[i]]$VCV[,1]+AR_m06_mods[[i]]$VCV[,2])})
AR_m07_lambda_traces<-lapply(1:length(AR_m07_mods),
                             function(i){(AR_m07_mods[[i]]$VCV[,1])/(
                               AR_m07_mods[[i]]$VCV[,1]+AR_m07_mods[[i]]$VCV[,2])})
AR_m05_lambda_traces<-lapply(1:length(AR_m05_mods),
                             function(i){(AR_m05_mods[[i]]$VCV[,1])/(
                               AR_m05_mods[[i]]$VCV[,1]+AR_m05_mods[[i]]$VCV[,2])})


#"fits" = predictions of model for training data (i.e. data that were used to
# generate the model)
print("generating model fits");Sys.time()
AR_m56_fits<-lapply(AR_m56_mods,predict.MCMCglmm,marginal=NULL)
AR_m24_fits<-lapply(AR_m24_mods,predict.MCMCglmm,marginal=NULL)
AR_m22_fits<-lapply(AR_m22_mods,predict.MCMCglmm,marginal=NULL)
AR_m40_fits<-lapply(AR_m40_mods,predict.MCMCglmm,marginal=NULL)
AR_m08_fits<-lapply(AR_m08_mods,predict.MCMCglmm,marginal=NULL)
AR_m06_fits<-lapply(AR_m06_mods,predict.MCMCglmm,marginal=NULL)
AR_m07_fits<-lapply(AR_m07_mods,predict.MCMCglmm,marginal=NULL)
AR_m05_fits<-lapply(AR_m05_mods,predict.MCMCglmm,marginal=NULL)


#"preds" = predictions on test data (data that were held out)
print("generating model predictions on test data");Sys.time()
AR_m56_preds<-lapply(1:length(AR_m56_mods),
                     function(i){
                       predict(AR_m56_mods[[i]],newdata=AR_tests[[i]],
                               marginal=NULL)})
AR_m24_preds<-lapply(1:length(AR_m24_mods),
                     function(i){
                       predict(AR_m24_mods[[i]],newdata=AR_tests[[i]],
                               marginal=NULL)})
AR_m22_preds<-lapply(1:length(AR_m22_mods),
                     function(i){
                       predict(AR_m22_mods[[i]],newdata=AR_tests[[i]],
                               marginal=NULL)})
AR_m40_preds<-lapply(1:length(AR_m40_mods),
                     function(i){
                       predict(AR_m40_mods[[i]],newdata=AR_tests[[i]],
                               marginal=NULL)})
AR_m08_preds<-lapply(1:length(AR_m08_mods),
                     function(i){
                       predict(AR_m08_mods[[i]],newdata=AR_tests[[i]],
                               marginal=NULL)})
AR_m06_preds<-lapply(1:length(AR_m06_mods),
                     function(i){
                       predict(AR_m06_mods[[i]],newdata=AR_tests[[i]],
                               marginal=NULL)})
AR_m07_preds<-lapply(1:length(AR_m07_mods),
                     function(i){
                       predict(AR_m07_mods[[i]],newdata=AR_tests[[i]],
                               marginal=NULL)})
AR_m05_preds<-lapply(1:length(AR_m05_mods),
                     function(i){
                       predict(AR_m05_mods[[i]],newdata=AR_tests[[i]],
                               marginal=NULL)})

#set up a new cluster for linear model fitting and MSEs
setCores<-round(detectCores()*0.75) #use 75% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
parallel::clusterExport(cl,"AR_sps")
parallel::clusterExport(cl,"AR_dats")
parallel::clusterExport(cl,"AR_tests")
print("re-importing fits and preds");Sys.time()
parallel::clusterExport(cl,"AR_m56_fits")
parallel::clusterExport(cl,"AR_m24_fits")
parallel::clusterExport(cl,"AR_m22_fits")
parallel::clusterExport(cl,"AR_m40_fits")
parallel::clusterExport(cl,"AR_m08_fits")
parallel::clusterExport(cl,"AR_m06_fits")
parallel::clusterExport(cl,"AR_m07_fits")
parallel::clusterExport(cl,"AR_m05_fits")  
parallel::clusterExport(cl,"AR_m56_preds")
parallel::clusterExport(cl,"AR_m24_preds")
parallel::clusterExport(cl,"AR_m22_preds")
parallel::clusterExport(cl,"AR_m40_preds")
parallel::clusterExport(cl,"AR_m08_preds")
parallel::clusterExport(cl,"AR_m06_preds")
parallel::clusterExport(cl,"AR_m07_preds")
parallel::clusterExport(cl,"AR_m05_preds")

#"fitsLMs" = fit lm()s to fits~training data
print("generating LMs of fits ~ training data");Sys.time()
AR_m56_fitsLMs<-parallel::parLapply(cl=cl,1:length(AR_m56_fits),
                                    function(i){
                                      lm(AR_m56_fits[[i]]~log(AR_dats[[i]]$b2.s))
                                    })
AR_m24_fitsLMs<-parallel::parLapply(cl=cl,1:length(AR_m24_fits),
                                    function(i){
                                      lm(AR_m24_fits[[i]]~log(AR_dats[[i]]$b2.s))
                                    })
AR_m22_fitsLMs<-parallel::parLapply(cl=cl,1:length(AR_m22_fits),
                                    function(i){
                                      lm(AR_m22_fits[[i]]~log(AR_dats[[i]]$b2.s))
                                    })
AR_m40_fitsLMs<-parallel::parLapply(cl=cl,1:length(AR_m40_fits),
                                    function(i){
                                      lm(AR_m40_fits[[i]]~log(AR_dats[[i]]$b2.s))
                                    })
AR_m08_fitsLMs<-parallel::parLapply(cl=cl,1:length(AR_m08_fits),
                                    function(i){
                                      lm(AR_m08_fits[[i]]~log(AR_dats[[i]]$b2.s))
                                    })
AR_m06_fitsLMs<-parallel::parLapply(cl=cl,1:length(AR_m06_fits),
                                    function(i){
                                      lm(AR_m06_fits[[i]]~log(AR_dats[[i]]$b2.s))
                                    })
AR_m07_fitsLMs<-parallel::parLapply(cl=cl,1:length(AR_m07_fits),
                                    function(i){
                                      lm(AR_m07_fits[[i]]~log(AR_dats[[i]]$b2.s))
                                    })
AR_m05_fitsLMs<-parallel::parLapply(cl=cl,1:length(AR_m05_fits),
                                    function(i){
                                      lm(AR_m05_fits[[i]]~log(AR_dats[[i]]$b2.s))
                                    })


#"predsLMs" = fit lm()s to preds~training data
print("generating LMs of preds ~ training data");Sys.time()
AR_m56_predsLMs<-parallel::parLapply(cl=cl,1:length(AR_m56_preds),
                                     function(i){
                                       lm(AR_m56_preds[[i]]~log(AR_tests[[i]]$b2.s))
                                     })
AR_m24_predsLMs<-parallel::parLapply(cl=cl,1:length(AR_m24_preds),
                                     function(i){
                                       lm(AR_m24_preds[[i]]~log(AR_tests[[i]]$b2.s))
                                     })
AR_m22_predsLMs<-parallel::parLapply(cl=cl,1:length(AR_m22_preds),
                                     function(i){
                                       lm(AR_m22_preds[[i]]~log(AR_tests[[i]]$b2.s))
                                     })
AR_m40_predsLMs<-parallel::parLapply(cl=cl,1:length(AR_m40_preds),
                                     function(i){
                                       lm(AR_m40_preds[[i]]~log(AR_tests[[i]]$b2.s))
                                     })
AR_m08_predsLMs<-parallel::parLapply(cl=cl,1:length(AR_m08_preds),
                                     function(i){
                                       lm(AR_m08_preds[[i]]~log(AR_tests[[i]]$b2.s))
                                     })
AR_m06_predsLMs<-parallel::parLapply(cl=cl,1:length(AR_m06_preds),
                                     function(i){
                                       lm(AR_m06_preds[[i]]~log(AR_tests[[i]]$b2.s))
                                     })
AR_m07_predsLMs<-parallel::parLapply(cl=cl,1:length(AR_m07_preds),
                                     function(i){
                                       lm(AR_m07_preds[[i]]~log(AR_tests[[i]]$b2.s))
                                     })
AR_m05_predsLMs<-parallel::parLapply(cl=cl,1:length(AR_m05_preds),
                                     function(i){
                                       lm(AR_m05_preds[[i]]~log(AR_tests[[i]]$b2.s))
                                     })


#'fitsMSEs' and 'predMSEs' = mean squared error from each regression
print("computing mean squared errors of fits");Sys.time()
AR_m56_fitsMSEs<-parallel::parSapply(cl=cl,AR_m56_fitsLMs,mse)
AR_m24_fitsMSEs<-parallel::parSapply(cl=cl,AR_m24_fitsLMs,mse)
AR_m22_fitsMSEs<-parallel::parSapply(cl=cl,AR_m22_fitsLMs,mse)
AR_m40_fitsMSEs<-parallel::parSapply(cl=cl,AR_m40_fitsLMs,mse)
AR_m08_fitsMSEs<-parallel::parSapply(cl=cl,AR_m08_fitsLMs,mse)
AR_m06_fitsMSEs<-parallel::parSapply(cl=cl,AR_m06_fitsLMs,mse)
AR_m07_fitsMSEs<-parallel::parSapply(cl=cl,AR_m07_fitsLMs,mse)
AR_m05_fitsMSEs<-parallel::parSapply(cl=cl,AR_m05_fitsLMs,mse)

print("computing mean squared errors of predictions");Sys.time()
AR_m56_predsMSEs<-parallel::parSapply(cl=cl,AR_m56_predsLMs,mse)
AR_m24_predsMSEs<-parallel::parSapply(cl=cl,AR_m24_predsLMs,mse)
AR_m22_predsMSEs<-parallel::parSapply(cl=cl,AR_m22_predsLMs,mse)
AR_m40_predsMSEs<-parallel::parSapply(cl=cl,AR_m40_predsLMs,mse)
AR_m08_predsMSEs<-parallel::parSapply(cl=cl,AR_m08_predsLMs,mse)
AR_m06_predsMSEs<-parallel::parSapply(cl=cl,AR_m06_predsLMs,mse)
AR_m07_predsMSEs<-parallel::parSapply(cl=cl,AR_m07_predsLMs,mse)
AR_m05_predsMSEs<-parallel::parSapply(cl=cl,AR_m05_predsLMs,mse)

stopCluster(cl)
Sys.time()


#model complexity order: 
#m56:22df
#m24:21df
#m22:20df
#m40:14df
#m08:13df
#m06:12df
#m07:4df
#m05:3df

#collect and re-format MSEs for plotting
AR_m56_fitsMSEs_df<-AR_m56_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
AR_m24_fitsMSEs_df<-AR_m24_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
AR_m22_fitsMSEs_df<-AR_m22_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
AR_m40_fitsMSEs_df<-AR_m40_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
AR_m08_fitsMSEs_df<-AR_m08_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
AR_m06_fitsMSEs_df<-AR_m06_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
AR_m07_fitsMSEs_df<-AR_m07_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
AR_m05_fitsMSEs_df<-AR_m05_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
AR_m56_fitsMSEs_df$df<-22
AR_m24_fitsMSEs_df$df<-21
AR_m22_fitsMSEs_df$df<-20
AR_m40_fitsMSEs_df$df<-14
AR_m08_fitsMSEs_df$df<-13
AR_m06_fitsMSEs_df$df<-12
AR_m07_fitsMSEs_df$df<-4
AR_m05_fitsMSEs_df$df<-3
AR_m56_predsMSEs_df<-AR_m56_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
AR_m24_predsMSEs_df<-AR_m24_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
AR_m22_predsMSEs_df<-AR_m22_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
AR_m40_predsMSEs_df<-AR_m40_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
AR_m08_predsMSEs_df<-AR_m08_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
AR_m06_predsMSEs_df<-AR_m06_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
AR_m07_predsMSEs_df<-AR_m07_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
AR_m05_predsMSEs_df<-AR_m05_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
AR_m56_predsMSEs_df$df<-22
AR_m24_predsMSEs_df$df<-21
AR_m22_predsMSEs_df$df<-20
AR_m40_predsMSEs_df$df<-14
AR_m08_predsMSEs_df$df<-13
AR_m06_predsMSEs_df$df<-12
AR_m07_predsMSEs_df$df<-4
AR_m05_predsMSEs_df$df<-3

AR_fitsMSEs<-rbind(AR_m56_fitsMSEs_df,
                   AR_m24_fitsMSEs_df,
                   AR_m22_fitsMSEs_df,
                   AR_m40_fitsMSEs_df,
                   AR_m08_fitsMSEs_df,
                   AR_m06_fitsMSEs_df,
                   AR_m07_fitsMSEs_df,
                   AR_m05_fitsMSEs_df)
AR_predsMSEs<-rbind(AR_m56_predsMSEs_df,
                    AR_m24_predsMSEs_df,
                    AR_m22_predsMSEs_df,
                    AR_m40_predsMSEs_df,
                    AR_m08_predsMSEs_df,
                    AR_m06_predsMSEs_df,
                    AR_m07_predsMSEs_df,
                    AR_m05_predsMSEs_df)
AR_combinedMSEs<-left_join(AR_fitsMSEs,AR_predsMSEs,by='df')


p <- ggplot(AR_combinedMSEs, aes(df, predsMSEs))
p + geom_point(aes(group=df,y=predsMSEs),col='red',alpha=0.1,size=2) + 
  geom_point(aes(group=df,y=fitsMSEs),size=2,alpha=0.1) + 
  stat_summary(aes(y=predsMSEs,group=1),fun.y=mean,colour="red",
               geom="point",group=1,size=5)+ 
  theme_bw()



p <- ggplot(AR_predsMSEs, aes(df, predsMSEs))
p + geom_point(aes(group=df),col='red',alpha=0.1,size=2) + 
  geom_point(data=AR_fitsMSEs,aes(group=df,y=fitsMSEs),alpha=0.1,col='black',size=2)+
  stat_summary(aes(y=predsMSEs,group=1),fun.y=mean,colour="red",
               geom="point",group=1,size=4)+ 
  stat_summary(data=AR_fitsMSEs,aes(y=fitsMSEs,group=1),fun.y=mean,
               colour="black",geom="point",group=1,size=4)+ 
  theme_bw()

aggregate(AR_fitsMSEs$fitsMSEs,list(AR_fitsMSEs$df),mean)
aggregate(AR_predsMSEs$predsMSEs,list(AR_predsMSEs$df),mean)


mean(ldply(sapply(AR_m56_mods,summary)[1,])$V1)
mean(ldply(lapply(AR_m56_lambda_traces,mean))$V1)


AR_m05_mods[[1]]->mmF;colnames(mmF$Sol)
mVarF <- var(as.vector(apply(mmF$Sol[,1:2],2,mean) %*% t(mmF$X)))
#mVarF <- var(as.vector(mean(mmF$Sol[,1]) %*% t(mmF$X)))
# MCMCglmm - marginal
mVarF/(mVarF+sum(apply(mmF$VCV,2,mean)))
# alternative with crebile intervals
vmVarF<-numeric(dim(mmF$VCV)[1])
for(i in 1:dim(mmF$VCV)[1]){
  Var<-var(as.vector(mmF$Sol[,1:2][i,] %*% t(mmF$X)))
  #Var<-var(as.vector(mmF$Sol[,1:1][i] %*% t(mmF$X)))
  vmVarF[i]<-Var}
R2m<-vmVarF/(vmVarF+mmF$VCV[,1]+mmF$VCV[,2])
mean(R2m)
posterior.mode(R2m)
HPDinterval(R2m)
# MCMCglmm - conditional
R2c<-as.mcmc((vmVarF+mmF$VCV[,1])/(vmVarF+rowSums(mmF$VCV)))
mean(R2c)
posterior.mode(R2c)
HPDinterval(R2c)

########SECTION 2: FULL MODELS######
##the best-fit model from each of the above is re-run for a longer chain
##the model is then used to determine standardized effects and see to what 
##extent fixed effects differ

######################### eROM full mixed-models #############################
timetree->inTree
inv.phylo<-inverseA(inTree,nodes="TIPS",scale=TRUE)

prior<-list(R=list(V=diag(3)/2,nu=5e-04),G=list(G1=list(V=diag(3)/2,nu=5e-04)))

eROM_best_mod<-MCMCglmm(cbind(PC1,PC2,PC3)~flightgroup+LnMass-1,
                        random=~us(trait):phylo,scale=TRUE,
                        family=c("gaussian","gaussian","gaussian"),
                        ginverse=list(phylo=inv.phylo$Ainv),
                        data=newdat,prior=prior,
                        nitt=100000,burnin=10000,thin=10,
                        verbose=TRUE,pr=TRUE,rcov=~us(trait):units)
summary(eROM_best_mod);eROM_best_mod$DIC
plot.estimatesMCMC(eROM_best_mod$Sol[,1:10])


eROM_best_mod->mmF;colnames(eROM_best_mod$Sol)
mVarF <- var(as.vector(apply(mmF$Sol[,1:10],2,mean) %*% t(mmF$X)))
# MCMCglmm - marginal
mVarF/(mVarF+sum(apply(mmF$VCV,2,mean)))
# alternative with crebile intervals
vmVarF<-numeric(dim(mmF$VCV)[1])
for(i in 1:dim(mmF$VCV)[1]){
  Var<-var(as.vector(mmF$Sol[,1:10][i,] %*% t(mmF$X)))
  vmVarF[i]<-Var}
R2m<-vmVarF/(vmVarF+mmF$VCV[,1]+mmF$VCV[,2]+mmF$VCV[,3]+mmF$VCV[,4]+mmF$VCV[,5]
             +mmF$VCV[,6]+mmF$VCV[,7]+mmF$VCV[,8]+mmF$VCV[,9])
mean(R2m)
posterior.mode(R2m)
HPDinterval(R2m)
# MCMCglmm - conditional
R2c<-(vmVarF+mmF$VCV[,1]+mmF$VCV[,2]+mmF$VCV[,3]+mmF$VCV[,4]+mmF$VCV[,5]
      +mmF$VCV[,6]+mmF$VCV[,7]+mmF$VCV[,8]+mmF$VCV[,9])/(vmVarF
     +mmF$VCV[,1]+mmF$VCV[,2]+mmF$VCV[,3]+mmF$VCV[,4]+mmF$VCV[,5]
     +mmF$VCV[,6]+mmF$VCV[,7]+mmF$VCV[,8]+mmF$VCV[,9]+mmF$VCV[,10]
     +mmF$VCV[,11]+mmF$VCV[,12]+mmF$VCV[,13]+mmF$VCV[,14]+mmF$VCV[,15]
     +mmF$VCV[,16]+mmF$VCV[,17]+mmF$VCV[,18])
mean(R2c)
posterior.mode(R2c)
HPDinterval(R2c)

Config_lambdaAllPCs_numerator<-rowSums(eROM_best_mod$VCV[,1:9])
Config_lambdaAllPCs_denominator<-rowSums(eROM_best_mod$VCV)
Config_lambdaAllPCs<-as.mcmc(Config_lambdaAllPCs_numerator/Config_lambdaAllPCs_denominator)
plot(Config_lambdaAllPCs);mean(Config_lambdaAllPCs);HPDinterval(Config_lambdaAllPCs)

eROM_best_mod->m_glmm
get_variables(m_glmm)[1:10]

m_glmm %>% emmeans( ~ flightgroup, data = newdat) %>%
  emmeans::contrast(adjust='none',method='eff') %>%
  gather_emmeans_draws() %>%
  ggplot(aes(x = .value, y = contrast)) +
  geom_halfeyeh(.width=0.95) +
  geom_vline(xintercept=0)

m_glmm %>% emmeans( ~ flightgroup, data = newdat) %>%
  CLD(alpha=0.05) %>%
  gather_emmeans_draws() %>%
  ggplot(aes(x = .value, y = contrast)) +
  geom_halfeyeh(.width=0.95)

allChains<-as.mcmc(cbind(eROM_best_mod$Sol,eROM_best_mod$VCV))
#plotTrace(allChains,axes=TRUE,las=1)
# Least square means. Note you must specify the data
model0.rg<-ref.grid(eROM_best_mod,data=newdat)
flight.lsm<-lsmeans(model0.rg,"flightgroup")
mass.lsm<-lsmeans(model0.rg,"LnMass",by='flightgroup')
lsmeans::contrast(flight.lsm,adjust='none',method='eff')
lsmeans::test(flight.lsm)
lsmeans::cld(flight.lsm,alpha=0.05,adjust='none')
plot(contrast(flight.lsm,adjust='none'))
plot(flight.lsm,comparisons=TRUE,alpha=0.05)


############################# static wing shape ################################
timetree->inTree
inv.phylo<-inverseA(inTree,nodes="TIPS",scale=TRUE)


prior<-list(R=list(V=diag(3)/2,nu=5e-04),G=list(G1=list(V=diag(3)/2,nu=5e-04)))

STAT_best_mod<-MCMCglmm(cbind(PC1,PC2,PC3)~1,
                        random=~us(trait):phylo,scale=TRUE,
                        family=c("gaussian","gaussian","gaussian"),
                        data=statdatdat,prior=prior,
                        ginverse=list(phylo=inv.phylo$Ainv),
                        nitt=100000,burnin=10000,thin=10, 
                        verbose=TRUE,pr=TRUE,rcov = ~ us(trait):units)
summary(STAT_best_mod)
plot.estimatesMCMC(STAT_best_mod$Sol[,1:9])
STAT_lambdaAllPCs_numerator<-rowSums(STAT_best_mod$VCV[,1:9])
STAT_lambdaAllPCs_denominator<-rowSums(STAT_best_mod$VCV)
STAT_lambdaAllPCs<-as.mcmc(STAT_lambdaAllPCs_numerator/STAT_lambdaAllPCs_denominator)
plot(STAT_lambdaAllPCs);mean(STAT_lambdaAllPCs);HPDinterval(STAT_lambdaAllPCs)


STAT_best_mod->mmF;colnames(eROM_best_mod$Sol)
mVarF <- var(as.vector(mean(mmF$Sol[,1]) %*% t(mmF$X)))
# MCMCglmm - marginal
mVarF/(mVarF+sum(apply(mmF$VCV,2,mean)))
# alternative with crebile intervals
vmVarF<-numeric(dim(mmF$VCV)[1])
for(i in 1:dim(mmF$VCV)[1]){
  Var<-var(as.vector(mmF$Sol[,1:1][i] %*% t(mmF$X)))
  vmVarF[i]<-Var}
R2m<-vmVarF/(vmVarF+rowSums(mmF$VCV[,1:9]))
mean(R2m)
posterior.mode(R2m)
HPDinterval(R2m)
# MCMCglmm - conditional
R2c<-as.mcmc((vmVarF+rowSums(mmF$VCV[,1:9]))/(vmVarF+rowSums(mmF$VCV)))
mean(R2c)
posterior.mode(R2c)
HPDinterval(R2c)


########################### linkage trajectories ###############################
#Use this model (model 22)
prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))
LT_fg_phyloMass_simple1<-MCMCglmm(log(manusAngle)~log(elbowAngle)+flightgroup+flightgroup:log(elbowAngle)-1,
                                  random=~phylo,scale=TRUE,data=dat,
                                  ginverse=list(phylo=inv.phylo$Ainv),
                                  prior=prior,verbose=TRUE,pr=TRUE,pl=TRUE,
                                  nitt=100000,burnin=10000,thin=10)
summary(LT_fg_phyloMass_simple1)
plot.estimatesMCMC(LT_fg_phyloMass_simple1$Sol[,1:18])
plot(LT_fg_phyloMass_simple1)
LT_fg_phyloMass_simple1_lambda<-(LT_fg_phyloMass_simple1$VCV[,1])/(LT_fg_phyloMass_simple1$VCV[,1]+LT_fg_phyloMass_simple1$VCV[,2])
plot(LT_fg_phyloMass_simple1_lambda);mean(LT_fg_phyloMass_simple1_lambda)
HPDinterval(LT_fg_phyloMass_simple1_lambda)

LT_fg_phyloMass_simple1->mmF;colnames(LT_fg_phyloMass_simple1$Sol)
mVarF <- var(as.vector(apply(mmF$Sol[,1:18],2,mean) %*% t(mmF$X)))
#mVarF <- var(as.vector(mean(mmF$Sol[,1]) %*% t(mmF$X)))
# MCMCglmm - marginal
mVarF/(mVarF+sum(apply(mmF$VCV,2,mean)))
# alternative with crebile intervals
vmVarF<-numeric(dim(mmF$VCV)[1])
for(i in 1:dim(mmF$VCV)[1]){
  Var<-var(as.vector(mmF$Sol[,1:18][i,] %*% t(mmF$X)))
  #Var<-var(as.vector(mmF$Sol[,1:1][i] %*% t(mmF$X)))
  vmVarF[i]<-Var}
R2m<-vmVarF/(vmVarF+mmF$VCV[,1]+mmF$VCV[,2])
mean(R2m)
posterior.mode(R2m)
HPDinterval(R2m)
# MCMCglmm - conditional
R2c<-as.mcmc((vmVarF+mmF$VCV[,1])/(vmVarF+rowSums(mmF$VCV)))
mean(R2c)
posterior.mode(R2c)
HPDinterval(R2c)

allChainsLT<-as.mcmc(cbind(LT_fg_phyloMass_simple1$Sol,LT_fg_phyloMass_simple1$VCV))
#plotTrace(allChainsAR,axes=TRUE,las=1)
# Least square means. Note you must specify the data
model0LT.rg<-ref.grid(LT_fg_phyloMass_simple1,data=dat)
flightLT.lsm<-lsmeans(model0LT.rg,specs=c("flightgroup","elbowAngle"))
#massLT.lsm<-lsmeans(model0AR.rg,"LnMass",by='flightgroup')
contrast(flightLT.lsm,adjust='none',interaction=TRUE)
test(flightLT.lsm)
plot(contrast(flightLT.lsm,adjust='none'))
LT.lstrends<-lstrends(LT_fg_phyloMass_simple1,~flightgroup,var="log(elbowAngle)",data=dat)
contrast(LT.lstrends)
test(LT.lstrends)
plot(contrast(LT.lstrends))
cld(LT.lstrends,alpha=0.05)
plot(summary(LT.lstrends)[,2],summary(flightLT.lsm)$lsmean,pch=19)


LTeffects<-data.frame(flightgroup=summary(flightLT.lsm)[,1],
                      slopes=summary(LT.lstrends)[,2],
                      slopesSE=summary(LT.lstrends)[,3],
                      slopesLCL=summary(LT.lstrends)[,5],
                      slopesUCL=summary(LT.lstrends)[,6],
                      intercepts=summary(flightLT.lsm)[,3],
                      interceptsSE=summary(flightLT.lsm)[,4],
                      interceptsLCL=summary(flightLT.lsm)[,6],
                      interceptsUCL=summary(flightLT.lsm)[,7])

ggplot(LTeffects, aes(x=slopes, y=intercepts, 
                      colour=flightgroup, group=flightgroup)) + 
  geom_errorbar(aes(ymin=intercepts-interceptsSE,
                    ymax=intercepts+interceptsSE),
                colour="black",width=0,size=0.5) +
  geom_errorbarh(aes(xmin=slopes-slopesSE,xmax=slopes+slopesSE),
                 colour="black",size=0.5,height=0) +
  coord_fixed(ratio=1/1) +
  geom_point(size=3)+
  scale_color_manual(values=flightptls)+
  theme_ridges()


################################# AR ######################################
prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))

#AR best model
AR_best_mod<-MCMCglmm(log(b2.s)~log(manusAngle),
                      random=~phylo,scale=TRUE,data=dat,
                      ginverse=list(phylo=inv.phylo$Ainv),
                      prior=prior,verbose=TRUE,pr=TRUE,#pl=TRUE,
                      nitt=1000000,burnin=100000,thin=100)
summary(AR_best_mod)
plot.estimatesMCMC(AR_best_mod$Sol[,1:18])
AR_best_mod_lambda<-(AR_best_mod$VCV[,1])/(AR_best_mod$VCV[,1]+AR_best_mod$VCV[,2])
plot(AR_best_mod_lambda);mean(AR_best_mod_lambda);HPDinterval(AR_best_mod_lambda)


#what happens if flight and mass are included
AR_fg_phyloMass_simple1<-MCMCglmm(log(b2.s)~log(manusAngle)+LnMass+flightgroup-1,
                                  random=~phylo,scale=TRUE,data=dat,
                                  ginverse=list(phylo=inv.phylo$Ainv),
                                  prior=prior,verbose=TRUE,pr=TRUE,pl=TRUE,
                                  nitt=100000,burnin=10000,thin=10)
summary(AR_fg_phyloMass_simple1)
plot.estimatesMCMC(AR_fg_phyloMass_simple1$Sol[,1:18])
plot(AR_fg_phyloMass_simple1)
AR_fg_phyloMass_simple1_lambda<-(AR_fg_phyloMass_simple1$VCV[,1])/(AR_fg_phyloMass_simple1$VCV[,1]+AR_fg_phyloMass_simple1$VCV[,2])
plot(AR_fg_phyloMass_simple1_lambda);mean(AR_fg_phyloMass_simple1_lambda)


allChainsAR<-as.mcmc(cbind(AR_fg_phyloMass_simple1$Sol,
                           AR_fg_phyloMass_simple1$VCV))
#plotTrace(allChainsAR,axes=TRUE,las=1)
# Least square means. Note you must specify the data
model0AR.rg<-ref.grid(AR_fg_phyloMass_simple1,data=dat)
flightAR.lsm<-lsmeans(model0AR.rg,specs=c("flightgroup","manusAngle"))
massAR.lsm<-lsmeans(model0AR.rg,"LnMass",by='flightgroup')
contrast(flightAR.lsm,adjust='none',interaction=TRUE)
test(flightAR.lsm)
plot(contrast(flightAR.lsm,adjust='none'))
AR.lstrends<-lstrends(AR_fg_phyloMass_simple1,~flightgroup,
                      var="log(manusAngle)",data=dat)
contrast(AR.lstrends)
test(AR.lstrends)
plot(contrast(AR.lstrends))
cld(AR.lstrends,alpha=0.05)
plot(summary(AR.lstrends)[,2],summary(flightAR.lsm)$lsmean,pch=19)


AReffects<-data.frame(flightgroup=summary(flightAR.lsm)[,1],
                      slopes=summary(AR.lstrends)[,2],
                      slopesSE=summary(AR.lstrends)[,3],
                      slopesLCL=summary(AR.lstrends)[,5],
                      slopesUCL=summary(AR.lstrends)[,6],
                      intercepts=summary(flightAR.lsm)[,3],
                      interceptsSE=summary(flightAR.lsm)[,4],
                      interceptsLCL=summary(flightAR.lsm)[,6],
                      interceptsUCL=summary(flightAR.lsm)[,7])

ggplot(AReffects, aes(x=slopes, y=intercepts, 
                      colour=flightgroup, group=flightgroup)) + 
  geom_errorbar(aes(ymin=intercepts-interceptsSE,
                    ymax=intercepts+interceptsSE),
                colour="black",width=0,size=0.5) +
  geom_errorbarh(aes(xmin=slopes-slopesSE,xmax=slopes+slopesSE), 
                 colour="black",size=0.5,height=0) +
  coord_fixed(ratio=1/1) +
  coord_cartesian(xlim=c(1.675,1.775)) +
  geom_point(size=3)+
  scale_color_manual(values=flightptls)+
  theme_ridges()


