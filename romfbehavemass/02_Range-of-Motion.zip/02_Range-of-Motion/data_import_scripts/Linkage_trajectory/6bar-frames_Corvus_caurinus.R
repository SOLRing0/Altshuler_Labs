path<-"./data/Corvus_caurinus/Linkage_Trajectory/"

####data import####
#source individual analyses
#all of these files will have "6bar" in the title
cholist<-list.files(path=path,pattern="6bar-ind",full.names=TRUE,recursive=TRUE)
for(i in 1:length(cholist)){
  source(cholist[i])
}

#plot all extensions with loess
#dat<-rbind(.Cho_min_18_1L_ext,.Cho_min_18_2R_ext,.Cho_min_18_3R_ext)
#ggplot(dat, aes(x = elbowAngle, y = manusAngle, colour = factor(filename))) + geom_point() +
#  geom_smooth(method = "loess", size = 1.5,level=0.99,span=0.2) #+ theme(legend.position="none")
  
Cor_cau.linkage.ext<-rbind(.Cor_cau_17_1L.ext)
Cor_cau.linkage.flx<-rbind(.Cor_cau_17_1L.flx)
