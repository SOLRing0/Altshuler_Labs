path<-"./data/Anas_platyrhynchos/Linkage_Trajectory/"

####data import####
#source individual analyses
#all of these files will have "6bar" in the title
analist<-list.files(path=path,pattern="6bar-ind",full.names=TRUE,recursive=TRUE)
for(i in 1:length(analist)){
  source(analist[i])
}

#plot all extensions with loess
#dat<-rbind(.Cho_min_18_1L_ext,.Cho_min_18_2R_ext,.Cho_min_18_3R_ext)
#ggplot(dat, aes(x = elbowAngle, y = manusAngle, colour = factor(filename))) + geom_point() +
#  geom_smooth(method = "loess", size = 1.5,level=0.99,span=0.2) #+ theme(legend.position="none")
  
Ana_pla.linkage.ext<-rbind(.Ana_pla_18_1L.ext)
Ana_pla.linkage.flx<-rbind(.Ana_pla_18_1L.flx)
