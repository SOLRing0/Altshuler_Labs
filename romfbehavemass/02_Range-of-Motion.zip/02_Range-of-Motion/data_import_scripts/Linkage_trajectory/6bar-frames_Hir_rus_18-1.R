path<-"./MiroM120_digitization/2018-04-12_Hir_rus_andFriends/2018-04-12_Hir_rus_18-1_6BarDors"

####data import####
#data will be imported from the "...xyzpts.csv" DLTdv6 file
#point 1 - head of the humerus
#point 2 - elbow
#point 3 - wrist
#point 4 - distal point on carpometacarpus
filelist.xyz   <- list.files(path=path,pattern = paste('*',"xyzpts.csv",sep=""),
                             full.names=TRUE)
sixbar.xyz<-NULL
for (i in 1:length(filelist.xyz)){
  filename = filelist.xyz[i] 
  sixbar.xyz[[i]]<-read.csv(filename,stringsAsFactors=FALSE)
  sixbar.xyz[[i]]<-sixbar.xyz[[i]][,c(1:12)]
  sixbar.xyz[[i]]$frame <- seq.int(nrow(sixbar.xyz[[i]]))
  sixbar.xyz[[i]]<-cbind(filelist.xyz[i],sixbar.xyz[[i]][complete.cases(sixbar.xyz[[i]]), ])
  #names(sixbar.xyz[[i]])<-filelist.xyz[i]
}
sixbar.xyz<-ldply(sixbar.xyz)

####calculate angles and store in a common data frame####
#angles are calculated from 3D data
#elbowAngle - uses points 1, 2, 3
#manusAngle - uses points 2, 3, 4
angle.data.three.d <-data.frame(sixbar.xyz[,1],
                                xyzangles(sixbar.xyz[,2],sixbar.xyz[,3],sixbar.xyz[,4],
                                          sixbar.xyz[,5],sixbar.xyz[,6],sixbar.xyz[,7],
                                          sixbar.xyz[,8],sixbar.xyz[,9],sixbar.xyz[,10]),
                                xyzangles(sixbar.xyz[,5],sixbar.xyz[,6],sixbar.xyz[,7],
                                          sixbar.xyz[,8],sixbar.xyz[,9],sixbar.xyz[,10],
                                          sixbar.xyz[,11],sixbar.xyz[,12],sixbar.xyz[,13]),
                                sixbar.xyz$frame)
colnames(angle.data.three.d)<-c("filename","elbowAngle","manusAngle","frame")

plot(angle.data.three.d[,c(2,3)],pch=19,col=as.factor(angle.data.three.d[,1]),
     xlim=c(0,180),ylim=c(0,180))
#identify(angle.data.three.d$elbowAngle,angle.data.three.d$manusAngle,labels = angle.data.three.d$frame, plot=TRUE)

#####select frames#####
#use plotting and visual inspection of the videos to determine the best cycles
#quick plot of all the cycles
#plot(angle.data.three.d$elbowAngle,ylim=c(0,180),pch=19,col="black")
#points(angle.data.three.d$manusAngle,pch=19,col="red")
#identify(1:nrow(angle.data.three.d),angle.data.three.d$elbowAngle,labels = angle.data.three.d$frame, plot=TRUE)

#plot(angle.data.three.d[245:382,c(2,3)],pch=19,col=as.factor(angle.data.three.d[,1]),xlim=c(0,180),ylim=c(0,180))
#plot(angle.data.three.d[383:525,c(2,3)],pch=19,col=as.factor(angle.data.three.d[,1]),xlim=c(0,180),ylim=c(0,180))
#plot(angle.data.three.d[526:668,c(2,3)],pch=19,col=as.factor(angle.data.three.d[,1]),xlim=c(0,180),ylim=c(0,180))

#extensions:
EXTframes_Hir_rus_18_1<-c(31:50,129:143,167:184,212:230,254:263,267:279,302:323,343:364)
Hir_rus_18_1.ext<-cbind(angle.data.three.d[EXTframes_Hir_rus_18_1,],
                        sixbar.xyz[EXTframes_Hir_rus_18_1,])
plot(Hir_rus_18_1.ext[,c(2,3)],pch=19,col=as.factor(angle.data.three.d[,1]),
     xlim=c(0,180),ylim=c(0,180))

#flexions:
FLXframes_Hir_rus_18_1<-c(99:128,150:166,192:203,205:211,231:253,280:301,329:342)
Hir_rus_18_1.flx<-cbind(angle.data.three.d[FLXframes_Hir_rus_18_1,],
                        sixbar.xyz[FLXframes_Hir_rus_18_1,])
plot(Hir_rus_18_1.flx[,c(2,3)],pch=19,col=as.factor(angle.data.three.d[,1]),
     xlim=c(0,180),ylim=c(0,180))

#verification
#plot(Hir_rus_18_1.ext$elbowAngle,ylim=c(0,180),pch=19,col="black")
#points(Hir_rus_18_1.ext$manusAngle,pch=19,col="red")