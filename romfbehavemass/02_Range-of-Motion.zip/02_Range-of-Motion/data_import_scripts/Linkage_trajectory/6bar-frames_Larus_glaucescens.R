path<-"./data/Larus_glaucescens/Linkage_Trajectory/"

####data import####
#source individual analyses
#all of these files will have "6bar" in the title
larlist<-list.files(path=path,pattern="6bar-ind",full.names=TRUE,recursive=TRUE)
for(i in 1:length(larlist)){
  source(larlist[i])
}

#plot all extensions with loess
#dat<-rbind(.GULL_16_0048.ext,.GULL_17_0243.ext,.GULL_17_0285.ext)
#ggplot(dat, aes(x = elbowAngle, y = manusAngle, colour = factor(filename))) + geom_point() +
#  geom_smooth(method = "loess", size = 1.5,level=0.99,span=0.2) #+ theme(legend.position="none")
  
Lar_gla.linkage.ext<-rbind(.GULL_16_0048.ext,.GULL_17_0243.ext,.GULL_17_0285.ext)
Lar_gla.linkage.flx<-rbind(.GULL_16_0048.flx,.GULL_17_0243.flx,.GULL_17_0285.flx)