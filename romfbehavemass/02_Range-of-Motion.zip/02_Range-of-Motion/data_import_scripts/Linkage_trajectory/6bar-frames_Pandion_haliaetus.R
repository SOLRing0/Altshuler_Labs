path<-"./data_import_scripts/Linkage_trajectory/"

####data import####
#source individual analyses
#all of these files will have "6bar" in the title
pnnlist<-list.files(path=path,pattern="6bar-ind_Pan_hal",full.names=TRUE,recursive=TRUE)
for(i in 1:length(pnnlist)){
  source(pnnlist[i])
}

#plot all extensions with loess
#dat<-rbind(.Pan_hal_18_1L.ext,.Pan_hal_18_1L.flx,.Pan_hal_18_2L_ext)
#ggplot(dat, aes(x = elbowAngle, y = manusAngle, colour = factor(filename))) + geom_point() +
#  geom_smooth(method = "loess", size = 1.5,level=0.999,span=0.2) #+ theme(legend.position="none")
  
Pan_hal.linkage.ext<-rbind(.Pan_hal_18_2L_ext)
Pan_hal.linkage.flx<-rbind(.Pan_hal_18_1L.flx,.Pan_hal_18_2L_flx)