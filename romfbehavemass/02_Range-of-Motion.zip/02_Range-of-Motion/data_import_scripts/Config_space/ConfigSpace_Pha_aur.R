path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
nanlist<-list.files(path=path,pattern="Config-ind_Pha_aur_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(nanlist)){
  source(nanlist[i])
}


############################### organize data ##################################
.Pha_aur.ROMS.list<-list(.Pha_aur_18_1.configSpace,
                         .Pha_aur_18_2L.configSpace)
names(.Pha_aur.ROMS.list)<-c(".Pha_aur_18_1.configSpace",
                             ".Pha_aur_18_2L.configSpace")

################################# bind data ####################################
Pha_aur.configSpace<-rbind(.Pha_aur_18_1.configSpace,
                           .Pha_aur_18_2L.configSpace)

print("Nannopterum_auritus imported")
