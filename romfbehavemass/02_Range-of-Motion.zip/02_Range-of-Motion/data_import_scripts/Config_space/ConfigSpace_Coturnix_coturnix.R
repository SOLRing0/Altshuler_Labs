path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
cotlist<-list.files(path=path,pattern="Config-ind_Cot_cot_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(cotlist)){
  source(cotlist[i])
}


############################### organize data ##################################
.Cot_cot.ROMS.list<-list(.Cot_cot_18_1R.configSpace)
names(.Cot_cot.ROMS.list)<-c(".Cot_cot_18_1R.configSpace")

################################# bind data ####################################
Cot_cot.configSpace<-rbind(.Cot_cot_18_1R.configSpace)
print("Coturnix_coturnix imported")	
