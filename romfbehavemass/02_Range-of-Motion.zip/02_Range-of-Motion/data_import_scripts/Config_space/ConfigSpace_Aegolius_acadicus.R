path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
aeglist<-list.files(path=path,pattern="Config-ind_Aeg_aca_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(aeglist)){
  source(aeglist[i])
}


############################### organize data ##################################
.Aeg_aca.ROMS.list<-list(.Aeg_aca_18_1L.configSpace,
                         .Aeg_aca_18_2.configSpace,
                         .Aeg_aca_18_3.configSpace)
names(.Aeg_aca.ROMS.list)<-c(".Aeg_aca_18_1L.configSpace",
                             ".Aeg_aca_18_2.configSpace",
                             ".Aeg_aca_18_3.configSpace")

################################# bind data ####################################
Aeg_aca.configSpace<-rbind(.Aeg_aca_18_1L.configSpace,
                           .Aeg_aca_18_2.configSpace,
                           .Aeg_aca_18_3.configSpace)

print("Aegolius_acadicus imported")
