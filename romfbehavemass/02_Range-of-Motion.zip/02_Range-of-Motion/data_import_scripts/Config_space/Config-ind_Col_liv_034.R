path<-"./MiroM120_digitization/2018-01-16_Ana_ame_18-1_and_friends/2018-01-16_COLLI-034_DorsROM-pooled/"

####data import####
#data will be imported from the "...xyzpts.csv" DLTdv6 file
#point 1 - head of the humerus
#point 2 - elbow
#point 3 - wrist
#point 4 - distal point on carpometacarpus
filelist.xyz   <- list.files(path=path,pattern = paste('*',"xyzpts.csv",sep=""),
                             full.names=TRUE)
sixbar.xyz<-NULL
for (i in 1:length(filelist.xyz)){
  filename = filelist.xyz[i] 
  sixbar.xyz[[i]]<-read.csv(filename,stringsAsFactors=FALSE)
  sixbar.xyz[[i]]<-sixbar.xyz[[i]][,c(1:12)]
  sixbar.xyz[[i]]$frame <- seq.int(nrow(sixbar.xyz[[i]]))
  sixbar.xyz[[i]]<-cbind(filelist.xyz[i],sixbar.xyz[[i]][complete.cases(sixbar.xyz[[i]]), ])
  #names(sixbar.xyz[[i]])<-filelist.xyz[i]
}
sixbar.xyz<-ldply(sixbar.xyz)

####calculate angles and store in a common data frame####
#angles are calculated from 3D data
#elbowAngle - uses points 1, 2, 3
#manusAngle - uses points 2, 3, 4
angle.data.three.d <-data.frame(sixbar.xyz[,1],
                                xyzangles(sixbar.xyz[,2],sixbar.xyz[,3],sixbar.xyz[,4],
                                          sixbar.xyz[,5],sixbar.xyz[,6],sixbar.xyz[,7],
                                          sixbar.xyz[,8],sixbar.xyz[,9],sixbar.xyz[,10]),
                                xyzangles(sixbar.xyz[,5],sixbar.xyz[,6],sixbar.xyz[,7],
                                          sixbar.xyz[,8],sixbar.xyz[,9],sixbar.xyz[,10],
                                          sixbar.xyz[,11],sixbar.xyz[,12],sixbar.xyz[,13]),
                                sixbar.xyz$frame)
colnames(angle.data.three.d)<-c("filename","elbowAngle","manusAngle","frame")

.Col_liv_034.configSpace<-cbind(angle.data.three.d,sixbar.xyz)
