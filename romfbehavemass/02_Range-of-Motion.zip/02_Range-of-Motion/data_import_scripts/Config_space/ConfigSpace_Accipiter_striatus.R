path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
acstlist<-list.files(path=path,pattern="Config-ind_Acc_str_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(acstlist)){
  source(acstlist[i])
}


############################### organize data ##################################
.Acc_str.ROMS.list<-list(.Acc_str_17_1L.configSpace,
                         .Acc_str_17_2.configSpace,
                         .Acc_str_17_3.configSpace)
names(.Acc_str.ROMS.list)<-c(".Acc_str_17_1L.configSpace",
                             ".Acc_str_17_2.configSpace",
                             ".Acc_str_17_3.configSpace")

################################# bind data ####################################
Acc_str.configSpace<-rbind(.Acc_str_17_1L.configSpace,
                           .Acc_str_17_2.configSpace,
                           .Acc_str_17_3.configSpace)
print("Acc_str imported")	