path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
neblist<-list.files(path=path,pattern="Config-ind_Str_neb_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(neblist)){
  source(neblist[i])
}


############################### organize data ##################################
.Str_neb.ROMS.list<-list(.Str_neb_18_1.configSpace,
                         .Str_neb_18_2.configSpace,
                         .Str_neb_18_3.configSpace,
                         .Str_neb_18_4.configSpace)
names(.Str_neb.ROMS.list)<-c(".Str_neb_18_1.configSpace",
                             ".Str_neb_18_2.configSpace",
                             ".Str_neb_18_3.configSpace",
                             ".Str_neb_18_4.configSpace")

################################# bind data ####################################
Str_neb.configSpace<-rbind(.Str_neb_18_1.configSpace,
                           .Str_neb_18_2.configSpace,
                           .Str_neb_18_3.configSpace,
                           .Str_neb_18_4.configSpace)

print("Strix_nebulosa imported")
