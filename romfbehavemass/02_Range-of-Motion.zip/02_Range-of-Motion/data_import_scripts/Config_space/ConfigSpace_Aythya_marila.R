path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
ayttlist<-list.files(path=path,pattern="Config-ind_Ayt_mar_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(ayttlist)){
  source(ayttlist[i])
}


############################### organize data ##################################
.Ayt_mar.ROMS.list<-list(.Ayt_mar_17_1.configSpace,
                         .Ayt_mar_17_2.configSpace)
names(.Ayt_mar.ROMS.list)<-c(".Ayt_mar_17_1.configSpace",
                             ".Ayt_mar_17_2.configSpace")

################################# bind data ####################################
Ayt_mar.configSpace<-rbind(.Ayt_mar_17_1.configSpace,
                           .Ayt_mar_17_2.configSpace)

print("Ayt_mar imported")	