path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
hirro<-list.files(path=path,pattern="Config-ind_Hir_rus_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(hirro)){
  source(hirro[i])
}


############################### organize data ##################################
.Hir_rus.ROMS.list<-list(.Hir_rus_18_1.configSpace,
                         .Hir_rus_18_2.configSpace)
names(.Hir_rus.ROMS.list)<-c(".Hir_rus_18_1.configSpace",
                             ".Hir_rus_18_2.configSpace")

################################# bind data ####################################
Hir_rus.configSpace<-rbind(.Hir_rus_18_1.configSpace,
                           .Hir_rus_18_2.configSpace)

print("Hirundo_rustica imported")
