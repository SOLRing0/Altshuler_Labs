path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
anplist<-list.files(path=path,pattern="Config-ind_Ana_pla_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(anplist)){
  source(anplist[i])
}


############################### organize data ##################################
.Ana_pla.ROMS.list<-list(.Ana_pla_18_1L.configSpace)
names(.Ana_pla.ROMS.list)<-c(".Ana_pla_18_1L.configSpace")

################################# bind data ####################################
Ana_pla.configSpace<-rbind(.Ana_pla_18_1L.configSpace)
