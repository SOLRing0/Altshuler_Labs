path<-"./MiroM120_digitization/2018-04-26_Stu_vul_andFriends/2018-04-26_Tac_tha_18-1L_DorsROM-pooled"

####data import####
#data will be imported from the "...xyzpts.csv" DLTdv6 file
#point 1 - head of the humerus
#point 2 - elbow
#point 3 - wrist
#point 4 - distal point on carpometacarpus
filelist.xyz   <- list.files(path=path,pattern = paste('*',"xyzpts.csv",sep=""),
                             full.names=TRUE)
dorsrom.xyz<-NULL
for (i in 1:length(filelist.xyz)){
  filename = filelist.xyz[i] 
  dorsrom.xyz[[i]]<-read.csv(filename,stringsAsFactors=FALSE)
  dorsrom.xyz[[i]]<-dorsrom.xyz[[i]][,c(1:12)]
  dorsrom.xyz[[i]]$frame <- seq.int(nrow(dorsrom.xyz[[i]]))
  dorsrom.xyz[[i]]<-cbind(filelist.xyz[i],dorsrom.xyz[[i]][complete.cases(dorsrom.xyz[[i]]), ])
  #names(dorsrom.xyz[[i]])<-filelist.xyz[i]
}
dorsrom.xyz<-ldply(dorsrom.xyz)

####calculate angles and store in a common data frame####
#angles are calculated from 3D data
#elbowAngle - uses points 1, 2, 3
#manusAngle - uses points 2, 3, 4
angle.data.three.d <-data.frame(dorsrom.xyz[,1],
                  xyzangles(dorsrom.xyz[,2],dorsrom.xyz[,3],dorsrom.xyz[,4],
                            dorsrom.xyz[,5],dorsrom.xyz[,6],dorsrom.xyz[,7],
                            dorsrom.xyz[,8],dorsrom.xyz[,9],dorsrom.xyz[,10]),
                  xyzangles(dorsrom.xyz[,5],dorsrom.xyz[,6],dorsrom.xyz[,7],
                            dorsrom.xyz[,8],dorsrom.xyz[,9],dorsrom.xyz[,10],
                            dorsrom.xyz[,11],dorsrom.xyz[,12],dorsrom.xyz[,13]),
                  dorsrom.xyz$frame)
colnames(angle.data.three.d)<-c("filename","elbowAngle","manusAngle","frame")

#configuration space
Tac_tha_18_1L.configSpace<-cbind(angle.data.three.d,dorsrom.xyz[,2:13])

print("Tac_tha imported")	
