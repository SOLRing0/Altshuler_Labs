path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
cotlist<-list.files(path=path,pattern="Config-ind_Cor_cau_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(cotlist)){
  source(cotlist[i])
}


############################### organize data ##################################
.Cor_cau.ROMS.list<-list(.Cor_cau_17_1L.configSpace,
                         .Cor_cau_18_2.configSpace)
names(.Cor_cau.ROMS.list)<-c(".Cor_cau_17_1L.configSpace",
                             ".Cor_cau_18_2.configSpace")

################################# bind data ####################################
Cor_cau.configSpace<-rbind(.Cor_cau_17_1L.configSpace,
                           .Cor_cau_18_2.configSpace)

print("Corvus_caurinus imported")	