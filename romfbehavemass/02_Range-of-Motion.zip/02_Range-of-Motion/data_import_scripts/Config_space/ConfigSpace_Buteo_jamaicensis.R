path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
bjlist<-list.files(path=path,pattern="Config-ind_But_jam_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(bjlist)){
  source(bjlist[i])
}


############################### organize data ##################################
.But_jam.ROMS.list<-list(.But_jam_18_1.configSpace,
                         .But_jam_18_R.configSpace,
                         .But_jam_18_2.configSpace,
                         .But_jam_18_3.configSpace)
names(.But_jam.ROMS.list)<-c(".But_jam_18_1.configSpace",
                             ".But_jam_18_R.configSpace",
                             ".But_jam_18_2.configSpace",
                             ".But_jam_18_3.configSpace")

################################# bind data ####################################
But_jam.configSpace<-rbind(.But_jam_18_1.configSpace,
                         .But_jam_18_R.configSpace,
                         .But_jam_18_2.configSpace,
                         .But_jam_18_3.configSpace)
						 
print("But_jam imported")	
