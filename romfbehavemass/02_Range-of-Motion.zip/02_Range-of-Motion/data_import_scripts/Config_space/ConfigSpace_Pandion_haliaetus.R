path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
stuvulist<-list.files(path=path,pattern="Config-ind_Pan_hal_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(stuvulist)){
  source(stuvulist[i])
}


############################### organize data ##################################
.Pan_hal.ROMS.list<-list(.Pan_hal_18_1L.configSpace,
                         .Pan_hal_18_3.configSpace,
                         .Pan_hal_18_4.configSpace,
                         .Pan_hal_18_5.configSpace)
names(.Pan_hal.ROMS.list)<-c(".Pan_hal_18_1L.configSpace",
                             ".Pan_hal_18_2.configSpace",
                             ".Pan_hal_18_3.configSpace")

################################# bind data ####################################
Pan_hal.configSpace<-rbind(.Pan_hal_18_1L.configSpace,
                           .Pan_hal_18_3.configSpace,
                           .Pan_hal_18_4.configSpace,
                           .Pan_hal_18_5.configSpace)

print("Pandion_haliaetus imported")
