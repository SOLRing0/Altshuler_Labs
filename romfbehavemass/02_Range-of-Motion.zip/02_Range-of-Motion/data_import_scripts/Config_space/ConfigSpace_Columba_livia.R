path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
colitlist<-list.files(path=path,pattern="Config-ind_Col_liv_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(colitlist)){
  source(colitlist[i])
}


############################### organize data ##################################
.Col_liv.ROMS.list<-list(.Col_liv_033.configSpace,
                         .Col_liv_034.configSpace)
names(.Col_liv.ROMS.list)<-c(".Col_liv_033.configSpace",
                             ".Col_liv_034.configSpace")

################################# bind data ####################################
Col_liv.configSpace<-rbind(.Col_liv_033.configSpace,
                           .Col_liv_034.configSpace)

print("Col_liv imported")	