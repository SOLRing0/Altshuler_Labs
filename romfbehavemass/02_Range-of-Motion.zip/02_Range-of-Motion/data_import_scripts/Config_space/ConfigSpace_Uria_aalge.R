path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
urilist<-list.files(path=path,pattern="Config-ind_Uri_aal_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(urilist)){
  source(urilist[i])
}


############################### organize data ##################################
.Uri_aal.ROMS.list<-list(.Uri_aal_18_1L.configSpace,
                         .Uri_aal_18_2.configSpace)
names(.Uri_aal.ROMS.list)<-c(".Uri_aal_18_1L.configSpace",
                             ".Uri_aal_18_2.configSpace")

################################# bind data ####################################
Uri_aal.configSpace<-rbind(.Uri_aal_18_1L.configSpace,
                           .Uri_aal_18_2.configSpace)

print("Uri_aal imported")	