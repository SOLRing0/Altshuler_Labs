path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
catar<-list.files(path=path,pattern="Config-ind_Cat_aur_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(catar)){
  source(catar[i])
}


############################### organize data ##################################
.Cat_aur.ROMS.list<-list(.Cat_aur_18_1L.configSpace,
                         .Cat_aur_18_2L.configSpace,
                         .Cat_aur_18_3.configSpace)
names(.Cat_aur.ROMS.list)<-c(".Cat_aur_18_1L.configSpace",
                             ".Cat_aur_18_2L.configSpace",
                             ".Cat_aur_18_3.configSpace")

################################# bind data ####################################
Cat_aur.configSpace<-rbind(.Cat_aur_18_1L.configSpace,
                           .Cat_aur_18_3.configSpace)

print("Cathartes_aura imported")
