path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
crrlist<-list.files(path=path,pattern="Config-ind_Cor_cor_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(crrlist)){
  source(crrlist[i])
}


############################### organize data ##################################
.Cor_cor.ROMS.list<-list(.Cor_cor_18_1.configSpace,
                         .Cor_cor_18_2R.configSpace)
names(.Cor_cor.ROMS.list)<-c(".Cor_cor_18_1.configSpace",
                             ".Cor_cor_18_2R.configSpace")

################################# bind data ####################################
Cor_cor.configSpace<-rbind(.Cor_cor_18_1.configSpace,
                           .Cor_cor_18_2R.configSpace)
						   
print("Corvus_corax imported")	
