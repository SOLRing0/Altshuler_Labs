path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
cotlist<-list.files(path=path,pattern="Config-ind_Ral_lim_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(cotlist)){
  source(cotlist[i])
}


############################### organize data ##################################
.Ral_lim.ROMS.list<-list(.Ral_lim_18_1L.configSpace)
names(.Ral_lim.ROMS.list)<-c(".Ral_lim_18_1L.configSpace")

################################# bind data ####################################
Ral_lim.configSpace<-rbind(.Ral_lim_18_1L.configSpace)

print("Rallus_limicola imported")
