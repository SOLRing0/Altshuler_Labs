path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
antylist<-list.files(path=path,pattern="Config-ind_Ant_rub_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(antylist)){
  source(antylist[i])
}


############################### organize data ##################################
.Ant_rub.ROMS.list<-list(.Ant_rub_17_1.configSpace,
                         .Ant_rub_17_2.configSpace,
                         .Ant_rub_18_1.configSpace,
                         .Ant_rub_18_2.configSpace)
names(.Ant_rub.ROMS.list)<-c(".Ant_rub_17_1.configSpace",
                             ".Ant_rub_17_2.configSpace",
                             ".Ant_rub_18_1.configSpace",
                             ".Ant_rub_18_2.configSpace")

################################# bind data ####################################
Ant_rub.configSpace<-rbind(.Ant_rub_17_1.configSpace,
                           .Ant_rub_17_2.configSpace,
                           .Ant_rub_18_1.configSpace,
                           .Ant_rub_18_2.configSpace)

print("Anthus_rubescens imported")
