path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
ixxytlist<-list.files(path=path,pattern="Config-ind_Ixo_nae",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(ixxytlist)){
  source(ixxytlist[i])
}


############################### organize data ##################################
.Ixo_nae.ROMS.list<-list(.Ixo_nae_17_1.configSpace,
                         .Ixo_nae_17_2.configSpace,
                         .Ixo_nae_2017_08_11L.configSpace)
names(.Ixo_nae.ROMS.list)<-c(".Ixo_nae_17_1.configSpace",
                             ".Ixo_nae_17_2.configSpace",
                             ".Ixo_nae_2017_08_11L.configSpace")


################################# bind data ####################################
Ixo_nae.configSpace<-rbind(.Ixo_nae_17_2.configSpace,
                           .Ixo_nae_2017_08_11L.configSpace)
print("Ixoreus_naevius imported")						   