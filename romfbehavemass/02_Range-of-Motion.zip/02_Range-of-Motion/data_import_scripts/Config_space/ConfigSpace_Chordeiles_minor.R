path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
cotlist<-list.files(path=path,pattern="Config-ind_Cho_min",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(cotlist)){
  source(cotlist[i])
}


############################### organize data ##################################
.Cho_min.ROMS.list<-list(.Cho_min_18_1L.configSpace,
                         .Cho_min_18_2R.configSpace,
                         .Cho_min_18_3R.configSpace)
names(.Cho_min.ROMS.list)<-c(".Cho_min_18_1L.configSpace",
                             ".Cho_min_18_2R.configSpace",
                             ".Cho_min_18_3R.configSpace")

################################# bind data ####################################
Cho_min.configSpace<-rbind(.Cho_min_18_1L.configSpace,
                           .Cho_min_18_2R.configSpace,
                           .Cho_min_18_3R.configSpace)

print("Chordeilies_minor imported")	