path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
regstalist<-list.files(path=path,pattern="Config-ind_Reg_sat_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(regstalist)){
  source(regstalist[i])
}


############################### organize data ##################################
.Reg_sat.ROMS.list<-list(.Reg_sat_17_1L.configSpace,
                         .Reg_sat_17_2.configSpace,
                         .Reg_sat_17_3.configSpace,
                         .Reg_sat_17_4.configSpace)
names(.Reg_sat.ROMS.list)<-c(".Reg_sat_17_1L.configSpace",
                             ".Reg_sat_17_2.configSpace",
                             ".Reg_sat_17_3.configSpace",
                             ".Reg_sat_17_4.configSpace")

################################# bind data ####################################
Reg_sat.configSpace<-rbind(.Reg_sat_17_1L.configSpace,
                           .Reg_sat_17_2.configSpace,
                           .Reg_sat_17_3.configSpace,
                           .Reg_sat_17_4.configSpace)

print("Regulus_satrapa imported")
