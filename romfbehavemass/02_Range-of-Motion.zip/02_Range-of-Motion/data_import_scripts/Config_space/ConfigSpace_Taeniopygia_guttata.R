path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
ctoglist<-list.files(path=path,pattern="Config-ind_Tae_gut_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(ctoglist)){
  source(ctoglist[i])
}


############################### organize data ##################################
.Tae_gut.ROMS.list<-list(.Tae_gut_361.configSpace,
                         .Tae_gut_16_13.configSpace)
names(.Tae_gut.ROMS.list)<-c(".Tae_gut_361.configSpace",
                             ".Tae_gut_16_13.configSpace")

################################# bind data ####################################
Tae_gut.configSpace<-rbind(.Tae_gut_361.configSpace,
                           .Tae_gut_16_13.configSpace)
print("Tae_gut imported")	