path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
aectlist<-list.files(path=path,pattern="Config-ind_Aec_occ_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(aectlist)){
  source(aectlist[i])
}


############################### organize data ##################################
.Aec_occ.ROMS.list<-list(.Aec_occ_18_1L.configSpace,
                         .Aec_occ_18_2R.configSpace)
names(.Aec_occ.ROMS.list)<-c(".Aec_occ_18_1L.configSpace",
                             ".Aec_occ_18_2R.configSpace")

################################# bind data ####################################
Aec_occ.configSpace<-rbind(.Aec_occ_18_1L.configSpace,
                           .Aec_occ_18_2R.configSpace)

print("Aec_occ imported")	