path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
asilist<-list.files(path=path,pattern="Config-ind_Asi_fla_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(asilist)){
  source(asilist[i])
}


############################### organize data ##################################
.Asi_fla.ROMS.list<-list(.Asi_fla_18_1.configSpace)
names(.Asi_fla.ROMS.list)<-c(".Asi_fla_18_1.configSpace")

################################# bind data ####################################
Asi_fla.configSpace<-rbind(.Asi_fla_18_1.configSpace)

print("Asio_flammeus imported")	
