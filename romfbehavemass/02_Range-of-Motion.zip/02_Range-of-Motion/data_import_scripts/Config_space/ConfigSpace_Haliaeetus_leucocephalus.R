path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
hallielist<-list.files(path=path,pattern="Config-ind_Hal_leu_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(hallielist)){
  source(hallielist[i])
}


############################### organize data ##################################
.Hal_leu.ROMS.list<-list(.Hal_leu_2017_113.configSpace,
                         .Hal_leu_2017_193.configSpace,
                         .Hal_leu_14_0324.configSpace)
names(.Hal_leu.ROMS.list)<-c(".Hal_leu_2017_113.configSpace",
                             ".Hal_leu_2017_193.configSpace",
                             ".Hal_leu_14_0324.configSpace")

################################# bind data ####################################
Hal_leu.configSpace<-rbind(.Hal_leu_2017_113.configSpace,
                           .Hal_leu_2017_193.configSpace,
                           .Hal_leu_14_0324.configSpace)
print("Hal_leu imported")	