path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
canlist<-list.files(path=path,pattern="Config-ind_Cal_ann_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(canlist)){
  source(canlist[i])
}


############################### organize data ##################################
.Cal_ann.ROMS.list<-list(.Cal_ann_137.configSpace,
                         .Cal_ann_226.configSpace)
names(.Cal_ann.ROMS.list)<-c(".Cal_ann_137.configSpace",
                             ".Cal_ann_226.configSpace")


################################# bind data ####################################
Cal_ann.configSpace<-rbind(.Cal_ann_137.configSpace)

print("Calypte_anna imported")	
