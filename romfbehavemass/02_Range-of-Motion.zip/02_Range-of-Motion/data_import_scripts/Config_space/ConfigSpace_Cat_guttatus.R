path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
stuvulist<-list.files(path=path,pattern="Config-ind_Cat_gut_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(stuvulist)){
  source(stuvulist[i])
}


############################### organize data ##################################
.Cat_gut.ROMS.list<-list(.Cat_gut_17_1L.configSpace,
                         .Cat_gut_17_2.configSpace)
names(.Cat_gut.ROMS.list)<-c(".Cat_gut_17_1L.configSpace",
                             ".Cat_gut_17_2.configSpace")

################################# bind data ####################################
Cat_gut.configSpace<-rbind(.Cat_gut_17_1L.configSpace)

print("Catharus_guttatus imported")
