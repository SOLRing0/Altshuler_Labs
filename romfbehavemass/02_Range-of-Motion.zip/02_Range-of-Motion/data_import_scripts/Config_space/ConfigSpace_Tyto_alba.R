path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
alblist<-list.files(path=path,pattern="Config-ind_Tyt_alb_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(alblist)){
  source(alblist[i])
}


############################### organize data ##################################
.Tyt_alb.ROMS.list<-list(.Tyt_alb_18_1.configSpace,
                         .Tyt_alb_18_2.configSpace,
                         .Tyt_alb_18_3.configSpace)
names(.Tyt_alb.ROMS.list)<-c(".Tyt_alb_18_1.configSpace",
                             ".Tyt_alb_18_2.configSpace",
                             ".Tyt_alb_18_3.configSpace")

################################# bind data ####################################
Tyt_alb.configSpace<-rbind(.Tyt_alb_18_1.configSpace,
                           .Tyt_alb_18_2.configSpace,
                           .Tyt_alb_18_3.configSpace)

print("Tyt_alb imported")	