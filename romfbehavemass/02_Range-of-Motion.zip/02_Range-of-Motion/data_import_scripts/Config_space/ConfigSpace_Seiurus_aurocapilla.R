path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
seriouslist<-list.files(path=path,pattern="Config-ind_Sei_aur",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(seriouslist)){
  source(seriouslist[i])
}


############################### organize data ##################################
.Sei_aur.ROMS.list<-list(.Sei_aur_17_1.configSpace,
                         .Sei_aur_18_2.configSpace)
names(.Sei_aur.ROMS.list)<-c(".Sei_aur_17_1.configSpace",
                             ".Sei_aur_18_2.configSpace")


################################# bind data ####################################
Sei_aur.configSpace<-rbind(.Sei_aur_17_1.configSpace,
                           .Sei_aur_18_2.configSpace)

print("Sei_aur imported")	