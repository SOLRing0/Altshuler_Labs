path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
fallist<-list.files(path=path,pattern="Config-ind_Fal_col_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(fallist)){
  source(fallist[i])
}


############################### organize data ##################################
.Fal_col.ROMS.list<-list(.Fal_col_18_1L.configSpace,
                         .Fal_col_18_2.configSpace)
names(.Fal_col.ROMS.list)<-c(".Fal_col_18_1L.configSpace",
                             ".Fal_col_18_2.configSpace")

################################# bind data ####################################
Fal_col.configSpace<-rbind(.Fal_col_18_1L.configSpace,
                           .Fal_col_18_2.configSpace)

print("Falco_columbarius imported")
