path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
calima<-list.files(path=path,pattern="Config-ind_Cal_mau_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(calima)){
  source(calima[i])
}


############################### organize data ##################################
.Cal_mau.ROMS.list<-list(.Cal_mau_18_1L.configSpace,
                         .Cal_mau_18_2.configSpace,
                         .Cal_mau_18_3.configSpace,
                         .Cal_mau_18_4.configSpace)
names(.Cal_mau.ROMS.list)<-c(".Cal_mau_18_1L.configSpace",
                             ".Cal_mau_18_2.configSpace",
                             ".Cal_mau_18_3.configSpace",
                             ".Cal_mau_18_4.configSpace")

################################# bind data ####################################
Cal_mau.configSpace<-rbind(.Cal_mau_18_1L.configSpace,
                           .Cal_mau_18_2.configSpace,
                           .Cal_mau_18_3.configSpace,
                           .Cal_mau_18_4.configSpace)

print("Calidris_mauri imported")
