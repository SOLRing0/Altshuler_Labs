path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
larlist<-list.files(path=path,pattern="Config-ind_Lar_gla_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(larlist)){
  source(larlist[i])
}


############################### organize data ##################################
.Lar_gla.ROMS.list<-list(.Lar_gla_16_0048.configSpace,
                         .Lar_gla_17_0243.configSpace,
                         .Lar_gla_17_0285.configSpace)
names(.Lar_gla.ROMS.list)<-c(".Lar_gla_16_0048.configSpace",
                             ".Lar_gla_17_0243.configSpace",
                             ".Lar_gla_17_0285.configSpace")


################################# bind data ####################################
Lar_gla.configSpace<-rbind(.Lar_gla_16_0048.configSpace,
                           .Lar_gla_17_0243.configSpace,
                           .Lar_gla_17_0285.configSpace)

print("Lar_gla imported")	