path<-"./data_import_scripts/Config_space/"

################################ import data ###################################
#source individual analyses
#all of these files will have "Config-ind" in the title
consolist<-list.files(path=path,pattern="Config-ind_Con_sor_",
                    full.names=TRUE,recursive=TRUE)
for(i in 1:length(consolist)){
  source(consolist[i])
}


############################### organize data ##################################
.Con_sor.ROMS.list<-list(.Con_sor_18_1L.configSpace,
                         .Con_sor_18_2.configSpace)
names(.Con_sor.ROMS.list)<-c(".Con_sor_18_1L.configSpace",
                             ".Con_sor_18_2.configSpace")

################################# bind data ####################################
Con_sor.configSpace<-rbind(.Con_sor_18_1L.configSpace,
                           .Con_sor_18_2.configSpace)

print("Contopus_sordidulus imported")
