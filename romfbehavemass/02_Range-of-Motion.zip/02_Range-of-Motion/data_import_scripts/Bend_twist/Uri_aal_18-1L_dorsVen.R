source('./data_import_scripts/Config_space/ConfigSpace_Uria_aalge.R')
path<-"./MiroM120_digitization/2018-05-01_Pha_aur_andFriends/2018-05-01_Uri_aal_18-1L_pdsv/"

################################ import data ###################################
#data will be imported from the "...xyzpts.csv" DLTdv6 file
#point 1 - head of the humerus
#point 2 - elbow
#point 3 - wrist
#point 4 - distal point on carpometacarpus
filelist.xyz<-list.files(path=path,pattern=paste('*',"xyzpts.csv",sep=""),
                             full.names=TRUE)
dorsVen.xyz<-NULL
for (i in 1:length(filelist.xyz)){
  filename = filelist.xyz[i] 
  dorsVen.xyz[[i]]<-read.csv(filename,stringsAsFactors=FALSE)
  dorsVen.xyz[[i]]<-dorsVen.xyz[[i]][,c(1:12)]
  dorsVen.xyz[[i]]$frame <- seq.int(nrow(dorsVen.xyz[[i]]))
  dorsVen.xyz[[i]]<-cbind(filelist.xyz[i],
                          dorsVen.xyz[[i]][complete.cases(dorsVen.xyz[[i]]),])
  #names(dorsVen.xyz[[i]])<-filelist.xyz[i]
}
dorsVen.xyz<-ldply(dorsVen.xyz)

############################### compute angles #################################
#calculate the 3D elbow and manus angles
#calculate the 2D elbow and manus angles
#calculate the xyz plane angles between the hand-wing and arm-wing
dorsVen.three.d.angles<-data.frame(dorsVen.xyz[,1],
                  xyzangles(dorsVen.xyz[,2],dorsVen.xyz[,3],dorsVen.xyz[,4],
                            dorsVen.xyz[,5],dorsVen.xyz[,6],dorsVen.xyz[,7],
                            dorsVen.xyz[,8],dorsVen.xyz[,9],dorsVen.xyz[,10]),
                  xyzangles(dorsVen.xyz[,5],dorsVen.xyz[,6],dorsVen.xyz[,7],
                            dorsVen.xyz[,8],dorsVen.xyz[,9],dorsVen.xyz[,10],
                            dorsVen.xyz[,11],dorsVen.xyz[,12],dorsVen.xyz[,13]),
                  dorsVen.xyz$frame)
colnames(dorsVen.three.d.angles)<-c("filename","elbowAngle","manusAngle",
                                    "frame")

dorsVen.twod.angles<-matrix(nrow=nrow(dorsVen.xyz),ncol=2)
for (i in 1:nrow(dorsVen.xyz)){
  dorsVen.twod.angles[i,1]<-xyangles(dorsVen.xyz[i,2],dorsVen.xyz[i,3],
                                     dorsVen.xyz[i,5],dorsVen.xyz[i,6],
                                     dorsVen.xyz[i,8],dorsVen.xyz[i,9])
  dorsVen.twod.angles[i,2]<-xyangles(dorsVen.xyz[i,5],dorsVen.xyz[i,6],
                                     dorsVen.xyz[i,8],dorsVen.xyz[i,9],
                                     dorsVen.xyz[i,11],dorsVen.xyz[i,12])
}
as.data.frame(dorsVen.twod.angles)->dorsVen.twod.angles
colnames(dorsVen.twod.angles)<-c("elbowAngle2d","manusAngle2d")

dorsVen.planeAngles<-data.frame()
for (i in 1:nrow(dorsVen.xyz)){
  dorsVen.planeAngles[i,1]<-xyzplaneangles(dorsVen.xyz[i,2],
                                           dorsVen.xyz[i,3],
                                           dorsVen.xyz[i,4],
                                           dorsVen.xyz[i,5],
                                           dorsVen.xyz[i,6],
                                           dorsVen.xyz[i,7],
                                           dorsVen.xyz[i,8],
                                           dorsVen.xyz[i,9],
                                           dorsVen.xyz[i,10],
                                           dorsVen.xyz[i,5],
                                           dorsVen.xyz[i,6],
                                           dorsVen.xyz[i,7],
                                           dorsVen.xyz[i,8],
                                           dorsVen.xyz[i,9],
                                           dorsVen.xyz[i,10],
                                           dorsVen.xyz[i,11],
                                           dorsVen.xyz[i,12],
                                           dorsVen.xyz[i,13]
                                           )
}

#sin(theta)= ((point4-Z)-(point3-Z)) / (dist from 3 to 4)
dorsVen.angle.rad<-asin(((dorsVen.xyz$pt4_Z)-(dorsVen.xyz$pt3_Z))/
                          (sqrt(((dorsVen.xyz$pt3_X-dorsVen.xyz$pt4_X)^2)+
                                ((dorsVen.xyz$pt3_Y-dorsVen.xyz$pt4_Y)^2)+
                                ((dorsVen.xyz$pt3_Z-dorsVen.xyz$pt4_Z)^2))))
dorsVen.angle.deg<-rad2deg(dorsVen.angle.rad)+2.348477

#collect everything
.dorsVenAngleData.Uri_aal_18_1L<-data.frame(dorsVen.three.d.angles,
                                            dorsVen.twod.angles,
                                            dorsVen.planeAngles,
                                            dorsVen.angle.deg)
colnames(.dorsVenAngleData.Uri_aal_18_1L)[7]<-"planeAngles"
colnames(.dorsVenAngleData.Uri_aal_18_1L)[8]<-"elevDepAngle"

#make convex hulls for elbow ang vs eledep and manusangl vs eledep
#elbowAngle2d vs elevDepAngle
.dorsVenElbowHull.Uri_aal_18_1L<-convexhull.xy(.dorsVenAngleData.Uri_aal_18_1L$elbowAngle2d,
                                               .dorsVenAngleData.Uri_aal_18_1L$elevDepAngle)


#elbowAngle2d vs elevDepAngle
.dorsVenManusHull.Uri_aal_18_1L<-convexhull.xy(.dorsVenAngleData.Uri_aal_18_1L$manusAngle2d,
                                               .dorsVenAngleData.Uri_aal_18_1L$elevDepAngle)


#alphahulls
bemb<-matrix(nrow=nrow(.dorsVenAngleData.Uri_aal_18_1L),ncol=3)
bemb[,1]<-.dorsVenAngleData.Uri_aal_18_1L$elbowAngle
bemb[,2]<-.dorsVenAngleData.Uri_aal_18_1L$manusAngle
bemb[,3]<-.dorsVenAngleData.Uri_aal_18_1L$elevDepAngle
colnames(bemb)<-c("elbowAngle","manusAngle","elevDepAngle")

.dorsVenAlphaHull.Uri_aal_18_1L<-ashape3d(bemb,alpha=100)
#plot(.dorsVenAlphaHull.Uri_aal_18_1L)
#axes3d(labels = T)
#title3d(xlab='elbowAngle',ylab='manusAngle',zlab='elevDepAngle')

data.frame(.dorsVenAlphaHull.Uri_aal_18_1L$triang)->tri
trifilt<-dplyr::filter(tri,on.ch>0)

k<-unique(
  unique(.dorsVenAlphaHull.Uri_aal_18_1L$triang[,1]),
  unique(.dorsVenAlphaHull.Uri_aal_18_1L$triang[,2]),
  unique(.dorsVenAlphaHull.Uri_aal_18_1L$triang[,3]))
g<-data.frame(.dorsVenAlphaHull.Uri_aal_18_1L$x)[k,]
g[1453,]<-c(25,105,1);
g[1454,]<-c(18,43,0.001);g[1455,]<-c(18,43,-0.001);g[1456,]<-c(129,162,1)
g[1457,]<-c(95,150,2.5);g[1458,]<-c(105,155,2.5);
ele<-dplyr::filter(g,elevDepAngle>=0)
dep<-dplyr::filter(g,elevDepAngle<=0)

#p<-ggplot(ele,aes(elbowAngle,manusAngle))
#p+geom_point(size=4,aes(colour=elevDepAngle)) +
#  coord_fixed(ratio=1/1) +
#  coord_cartesian(xlim=c(0,200),ylim=c(0,200)) +
#  scale_color_viridis(discrete=FALSE) +
#  theme_bw()

testhull<-convexhull.xy(x=Uri_aal.configSpace$elbowAngle,
                        y=Uri_aal.configSpace$manusAngle)
chull2d<-cbind(testhull$bdry[[1]][[1]],testhull$bdry[[1]][[2]])

loes.elev<-loess.as(x=ele[,c(1,2)],y=ele[,3],degree=1,#user.span=0.75,
                    criterion="gcv",plot=TRUE)
x1<-seq(ceiling(min(chull2d[,1])),floor(max(chull2d[,1])),by=4)
x2<-seq(ceiling(min(chull2d[,2])),floor(max(chull2d[,2])),by=4)
d1<-expand.grid(x1,x2);colnames(d1)<-c("x1","x2")
elev.preds<-predict(loes.elev,newdata=data.frame(d1))
elev.plotdat<-data.frame(d1,elev.preds)
colnames(ele)->colnames(elev.plotdat)
#hist(ele$elevDepAngle);hist(elev.plotdat$elevDepAngle)


loes.depr<-loess.as(x=dep[,c(1,2)],y=dep[,3],degree=1,#user.span=0.03,
                    criterion="gcv",plot=TRUE)
x1<-seq(ceiling(min(chull2d[,1])),floor(max(chull2d[,1])),by=4)
x2<-seq(ceiling(min(chull2d[,2])),floor(max(chull2d[,2])),by=4)
d1<-expand.grid(x1,x2);colnames(d1)<-c("x1","x2")
depr.preds<-predict(loes.depr,newdata=data.frame(d1))
depr.plotdat<-data.frame(d1,depr.preds)
colnames(dep)->colnames(depr.plotdat)
#hist(dep$elevDepAngle);hist(depr.plotdat$elevDepAngle)

elev.plotdat$elevDepAngle[elev.plotdat$elevDepAngle<0]<-0
elev.plotdat$elevDepAngle[elev.plotdat$elevDepAngle=='NA']<-0
elev.plotdat<-dplyr::filter(elev.plotdat,elevDepAngle<=1.3*max(ele$elevDepAngle))
depr.plotdat$elevDepAngle[depr.plotdat$elevDepAngle>0]<-0
depr.plotdat$elevDepAngle[depr.plotdat$elevDepAngle=='NA']<-0
depr.plotdat<-dplyr::filter(depr.plotdat,elevDepAngle>=1.3*min(dep$elevDepAngle))


#p<-ggplot(elev.plotdat,aes(elbowAngle,manusAngle))
#p+geom_point(size=4,aes(colour=elevDepAngle)) +
#  coord_fixed(ratio=1/1) +
#  coord_cartesian(xlim=c(0,200),ylim=c(0,200)) +
#  scale_color_viridis(discrete=FALSE) +
#  theme_bw()

filtele<-pip2d(as.matrix(chull2d),as.matrix(elev.plotdat[,1:2]))
a<-elev.plotdat[filtele==1,]
colnames(a)<-c("elbowAngle","manusAngle","maxElevation")
.maxElevation.Uri_aal_18_1L<-dplyr::filter(a,maxElevation>=0)

filtdep<-pip2d(as.matrix(chull2d),as.matrix(depr.plotdat[,1:2]))
a<-depr.plotdat[filtdep==1,]
colnames(a)<-c("elbowAngle","manusAngle","maxDepression")
.maxDepression.Uri_aal_18_1L<-dplyr::filter(a,maxDepression<=0)

p<-ggplot(.maxElevation.Uri_aal_18_1L,aes(elbowAngle,manusAngle))
p+geom_point(size=4,aes(colour=maxElevation)) +
  coord_fixed(ratio=1/1) +
  coord_cartesian(xlim=c(0,200),ylim=c(0,200)) +
  scale_color_viridis(discrete=FALSE) +
  theme_bw()

p<-ggplot(.maxDepression.Uri_aal_18_1L,aes(elbowAngle,manusAngle))
p+geom_point(size=4,aes(colour=maxDepression)) +
  coord_fixed(ratio=1/1) +
  coord_cartesian(xlim=c(0,200),ylim=c(0,200)) +
  scale_color_viridis(discrete=FALSE,direction=-1,option="B") +
  theme_bw()

o<-inner_join(.maxDepression.Uri_aal_18_1L,.maxElevation.Uri_aal_18_1L)
o[,"eleDepCapability"]<-o$maxElevation+abs(o$maxDepression)
o[,"id"]<-"Uria_aalge"
o->rangeElevDep.Uri_aal_18_1L
p<-ggplot(rangeElevDep.Uri_aal_18_1L,aes(elbowAngle,manusAngle))
p+geom_point(size=4,aes(colour=eleDepCapability)) +
  coord_fixed(ratio=1/1) +
  coord_cartesian(xlim=c(0,200),ylim=c(0,200)) +
  scale_color_viridis(discrete=FALSE,option="A") +
  theme_bw()

