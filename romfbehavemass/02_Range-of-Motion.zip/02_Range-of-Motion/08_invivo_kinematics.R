############################# import pigeon data ##############################

# import pigeon data as pigeondat
pigeondat<-read.csv("./in_vivo_data/2019_06_28_COLLI_055_allFlights.csv")

# filter data that has missing values
pigeoncleaned <-
  pigeondat %>%
  na.omit()

######################### pigeon extension flextion ############################
# compute elbow and manus angles of extension
Col_liv.invivothreed<-data.frame(
  pigeoncleaned$video,
  xyzangles(pigeoncleaned[,3],pigeoncleaned[,4],pigeoncleaned[,5],
            pigeoncleaned[,6],pigeoncleaned[,7],pigeoncleaned[,8],
            pigeoncleaned[,9],pigeoncleaned[,10],pigeoncleaned[,11]),
  xyzangles(pigeoncleaned[,6],pigeoncleaned[,7],pigeoncleaned[,8],
            pigeoncleaned[,9],pigeoncleaned[,10],pigeoncleaned[,11],
            pigeoncleaned[,12],pigeoncleaned[,13],pigeoncleaned[,14])
)
colnames(Col_liv.invivothreed)<-c("video","elbowAngle","manusAngle")
# add 9.8 deg to elbowAngle due to offset from placing marker on distal inner
# edge of humerus instead of humeral head
Col_liv.invivothreed$elbowAngle<-Col_liv.invivothreed$elbowAngle+9.8


plot(Col_liv.invivothreed$elbowAngle,Col_liv.invivothreed$manusAngle,
     pch=19,xlim=c(0,200),ylim=c(0,200),yaxt='n',xaxt='n',bty="n",asp=1)
axis(side=1,at=c(0,90,180),tck=0.02)
axis(side=2,at=c(0,90,180),tck=0.02)
lines(chull.stack$Columba_livia,pch=19,col='orange')
lines(ordered.extensions.data$Col_liv.linkage.ext$elbowAngle,
       loess.extensions.predicts$Col_liv.linkage.ext,
       pch=19,col='grey')

################################ pigeon twist #################################

# compute plane angles from cadaver
Col_liv.cadaverplane<-data.frame(Col_liv.linkage.ext$elbowAngle,
                                 Col_liv.linkage.ext$manusAngle,
   xyzplaneangles(Col_liv.linkage.ext[,6],Col_liv.linkage.ext[,7],
                  Col_liv.linkage.ext[,8],
                  Col_liv.linkage.ext[,9],Col_liv.linkage.ext[,10],
                  Col_liv.linkage.ext[,11],
                  Col_liv.linkage.ext[,12],Col_liv.linkage.ext[,13],
                  Col_liv.linkage.ext[,14],
                  Col_liv.linkage.ext[,9],Col_liv.linkage.ext[,10],
                  Col_liv.linkage.ext[,11],
                  Col_liv.linkage.ext[,12],Col_liv.linkage.ext[,13],
                  Col_liv.linkage.ext[,14],
                  Col_liv.linkage.ext[,15],Col_liv.linkage.ext[,16],
                  Col_liv.linkage.ext[,17]))
colnames(Col_liv.cadaverplane)<-c("elbowAngle","manusAngle","planeAngle")

# use Loess to predict the plane angles over the in vivo range
Col_liv.ext.loess<-loess.as(Col_liv.cadaverplane$elbowAngle,
                            Col_liv.cadaverplane$planeAngle)
Col_liv.predictedPlane<-predict(Col_liv.ext.loess,
                                newdat=Col_liv.invivothreed$elbowAngle)

# compute in vivo pronation & supination
Col_liv.invivoproSup<-xyzplaneangles(
   pigeoncleaned[,6],pigeoncleaned[,7],pigeoncleaned[,8],
   pigeoncleaned[,9],pigeoncleaned[,10],pigeoncleaned[,11],
   pigeoncleaned[,12],pigeoncleaned[,13],pigeoncleaned[,14],
   pigeoncleaned[,9],pigeoncleaned[,10],pigeoncleaned[,11],
   pigeoncleaned[,12],pigeoncleaned[,13],pigeoncleaned[,14],
   pigeoncleaned[,15],pigeoncleaned[,16],pigeoncleaned[,17])
# subtract predicted plane angles to correct for inherent twist of cmc 
# relative to elbow
Col_liv.invivoproSup<--1*(Col_liv.invivoproSup-(180-Col_liv.predictedPlane))

# quick plot
# Cadaver pro/supination vs. in vivo pro/supination
plot(rangepronsup.Col_liv_034$elbowAngle,
     rangepronsup.Col_liv_034$maxpronation,
     pch=19,xlim=c(0,200),ylim=c(-90,90),yaxt='n',xaxt='n',bty="n",asp=1)
axis(side=1,at=c(0,90,180),tck=0.02)
axis(side=2,at=c(-90,0,90),tck=0.02)
points(rangepronsup.Col_liv_034$elbowAngle,
       rangepronsup.Col_liv_034$maxsupination,
       pch=19)
points(Col_liv.invivothreed$elbowAngle,Col_liv.invivoproSup,
       pch=19,col='orange')

# check if points are inside alpha hull
# first re-format data
Col_liv.proSup_testdf<-data.frame(elbowAngle=Col_liv.invivothreed$elbowAngle,
                    manusAngle=Col_liv.invivothreed$manusAngle,
                    proSupAngles=Col_liv.invivoproSup)
Col_liv.proSup_testmat<-as.matrix(Col_liv.proSup_testdf)

# second, re-format the alpha hull to allow for testing over
# full range of values; i.e. list elbow and manus angles twice, each with
# corresponding supination and pronation capability
Col_liv.proSup_hull<-matrix(nrow=2*nrow(rangepronsup.Col_liv_034),ncol=3)
Col_liv.proSup_hull[,1]<-c(rangepronsup.Col_liv_034$elbowAngle,
            rangepronsup.Col_liv_034$elbowAngle)
Col_liv.proSup_hull[,2]<-c(rangepronsup.Col_liv_034$manusAngle,
            rangepronsup.Col_liv_034$manusAngle)
Col_liv.proSup_hull[,3]<-c(rangepronsup.Col_liv_034$maxsupination,
            rangepronsup.Col_liv_034$maxpronation)
colnames(Col_liv.proSup_hull)<-c("elbowAngle","manusAngle","proSupAngles")
Col_liv.proSup_rehull<-ashape3d(Col_liv.proSup_hull,alpha=100)

# use inashape3d() to test
# if any FALSE appears, the point is outside the hull
Col_liv.proSup_test<-inashape3d(Col_liv.proSup_rehull,
                 indexAlpha='all',
                 points=Col_liv.proSup_testmat)
# are any found outside the hull?
if(any(Col_liv.proSup_test==FALSE))
  print("point(s) outside hull found")
if(!any(Col_liv.proSup_test==FALSE))
  print("all points inside hull")

############################### pigeon bending ################################

# define arm-wing planes
Col_liv.plane_coefs<-matrix(nrow=dim(pigeoncleaned)[1],ncol=4)
for (i in 1:dim(pigeoncleaned)[1]){
  Col_liv.plane_coefs[i,]<-as.numeric(define_plane(pigeoncleaned[i,3],
                                           pigeoncleaned[i,4],
                                           pigeoncleaned[i,5],
                                           pigeoncleaned[i,6],
                                           pigeoncleaned[i,7],
                                           pigeoncleaned[i,8],
                                           pigeoncleaned[i,9],
                                           pigeoncleaned[i,10],
                                           pigeoncleaned[i,11]))
}

# get distances from cmc to plane
Col_liv.cmc_dists <- matrix(nrow=dim(pigeoncleaned)[1],ncol=1)
for (i in 1:dim(pigeoncleaned)[1]){
  Col_liv.cmc_dists[i,]<-dist_point2plane(Col_liv.plane_coefs[i,1],
                                  Col_liv.plane_coefs[i,2],
                                  Col_liv.plane_coefs[i,3],
                                  Col_liv.plane_coefs[i,4],
                                  pigeoncleaned[i,12],
                                  pigeoncleaned[i,13],
                                  pigeoncleaned[i,14])
}

# get lengths of cmc
Col_liv.cmc_lengths<-matrix(nrow=dim(pigeoncleaned)[1],ncol=1)
for (i in 1:dim(pigeoncleaned)[1]){
  Col_liv.cmc_lengths[i,]<-euc_dist(x1=c(pigeoncleaned[i,9],
                                         pigeoncleaned[i,10],
                                         pigeoncleaned[i,11]),
                                    x2=c(pigeoncleaned[i,12],
                                         pigeoncleaned[i,13],
                                         pigeoncleaned[i,14]))
}

# get angles
Col_liv.invivoelevDep<-matrix(nrow=dim(pigeoncleaned)[1],ncol=1)
for (i in 1:dim(pigeoncleaned)[1]){
  Col_liv.invivoelevDep[i,]<-asin(Col_liv.cmc_dists[i,]/
                                  Col_liv.cmc_lengths[i,])
}
# convert back to degrees and flip the sign so that
# elevation is positive and depression is negative
-1*rad2deg(as.numeric(Col_liv.invivoelevDep))->Col_liv.invivoelevDep


# quick plot
# Cadaver elev/depression vs. in vivo elev/depression
plot(rangeElevDep.Col_liv_034$elbowAngle,
     rangeElevDep.Col_liv_034$maxElevation,
     pch=19,xlim=c(0,200),ylim=c(-90,90),yaxt='n',xaxt='n',bty="n",asp=1)
axis(side=1,at=c(0,90,180),tck=0.02)
axis(side=2,at=c(-90,0,90),tck=0.02)
points(rangeElevDep.Col_liv_034$elbowAngle,
       rangeElevDep.Col_liv_034$maxDepression,
       pch=19)
points(Col_liv.invivothreed$elbowAngle,
       Col_liv.invivoelevDep,pch=19,col='orange')


# check if points are inside alpha hull
# first re-format data
Col_liv.elevDep_testdf<-data.frame(elbowAngle=Col_liv.invivothreed$elbowAngle,
                                   manusAngle=Col_liv.invivothreed$manusAngle,
                                   elevDepAngles=Col_liv.invivoelevDep)
Col_liv.elevDep_testmat<-as.matrix(Col_liv.elevDep_testdf)

# second, re-format the alpha hull to allow for testing over
# full range of values; i.e. list elbow and manus angles twice, each with
# corresponding elevation and depression capability
Col_liv.elevDep_hull<-matrix(nrow=2*nrow(rangeElevDep.Col_liv_034),ncol=3)
Col_liv.elevDep_hull[,1]<-c(rangeElevDep.Col_liv_034$elbowAngle,
                            rangeElevDep.Col_liv_034$elbowAngle)
Col_liv.elevDep_hull[,2]<-c(rangeElevDep.Col_liv_034$manusAngle,
                            rangeElevDep.Col_liv_034$manusAngle)
Col_liv.elevDep_hull[,3]<-c(rangeElevDep.Col_liv_034$maxDepression,
                            rangeElevDep.Col_liv_034$maxElevation)
colnames(Col_liv.elevDep_hull)<-c("elbowAngle","manusAngle","elevDepAngles")
# need to add pert=TRUE to ashape3d because of singularities
# perturbations are very minor (1e-09*SD(data))
Col_liv.elevDep_rehull<-ashape3d(Col_liv.elevDep_hull,alpha=100,pert=TRUE)

# use inashape3d() to test
# if any FALSE appears, the point is outside the hull
Col_liv.elevDep_test<-inashape3d(Col_liv.elevDep_rehull,
                                 indexAlpha='all',
                                 points=Col_liv.elevDep_testmat)
# are any found outside the hull?
if(any(Col_liv.elevDep_test==FALSE))
  print("point(s) outside hull found")
if(!any(Col_liv.elevDep_test==FALSE))
  print("all points inside hull")

########################### import zebra finch data ###########################

# import zeebie data as zeebiedat
zeebiedat<-read.csv("./in_vivo_data/2019_07_02_Tae_gut_allFlights.csv")

# filter data that has missing values
zeebiecleaned <-
  zeebiedat %>%
  na.omit()

######################### zeebie extension flextion ############################
# compute elbow and manus angles of extension
Tae_gut.invivothreed<-data.frame(
  zeebiecleaned$video,
  xyzangles(zeebiecleaned[,3],zeebiecleaned[,4],zeebiecleaned[,5],
            zeebiecleaned[,6],zeebiecleaned[,7],zeebiecleaned[,8],
            zeebiecleaned[,9],zeebiecleaned[,10],zeebiecleaned[,11]),
  xyzangles(zeebiecleaned[,6],zeebiecleaned[,7],zeebiecleaned[,8],
            zeebiecleaned[,9],zeebiecleaned[,10],zeebiecleaned[,11],
            zeebiecleaned[,12],zeebiecleaned[,13],zeebiecleaned[,14])
)
colnames(Tae_gut.invivothreed)<-c("video","elbowAngle","manusAngle")
# no need to correct elbow angle for offset as we did with the pigeon data;
# zeebie marker placements were more directly in line with humeral head
# 

plot(Tae_gut.invivothreed$elbowAngle,Tae_gut.invivothreed$manusAngle,
     pch=19,xlim=c(0,200),ylim=c(0,200),yaxt='n',xaxt='n',bty="n",asp=1)
axis(side=1,at=c(0,90,180),tck=0.02)
axis(side=2,at=c(0,90,180),tck=0.02)
lines(chull.stack$Taeniopygia_guttata,pch=19,col='orange')
lines(ordered.extensions.data$Tae_gut.linkage.ext$elbowAngle,
      loess.extensions.predicts$Tae_gut.linkage.ext,
      pch=19,col='grey')


############################### zeebie bending ################################

# define arm-wing planes
Tae_gut.plane_coefs<-matrix(nrow=dim(zeebiecleaned)[1],ncol=4)
for (i in 1:dim(zeebiecleaned)[1]){
  Tae_gut.plane_coefs[i,]<-as.numeric(define_plane(zeebiecleaned[i,3],
                                                   zeebiecleaned[i,4],
                                                   zeebiecleaned[i,5],
                                                   zeebiecleaned[i,6],
                                                   zeebiecleaned[i,7],
                                                   zeebiecleaned[i,8],
                                                   zeebiecleaned[i,9],
                                                   zeebiecleaned[i,10],
                                                   zeebiecleaned[i,11]))
}

# get distances from cmc to plane
Tae_gut.cmc_dists <- matrix(nrow=dim(zeebiecleaned)[1],ncol=1)
for (i in 1:dim(zeebiecleaned)[1]){
  Tae_gut.cmc_dists[i,]<-dist_point2plane(Tae_gut.plane_coefs[i,1],
                                          Tae_gut.plane_coefs[i,2],
                                          Tae_gut.plane_coefs[i,3],
                                          Tae_gut.plane_coefs[i,4],
                                          zeebiecleaned[i,12],
                                          zeebiecleaned[i,13],
                                          zeebiecleaned[i,14])
}

# get lengths of cmc
Tae_gut.cmc_lengths<-matrix(nrow=dim(zeebiecleaned)[1],ncol=1)
for (i in 1:dim(zeebiecleaned)[1]){
  Tae_gut.cmc_lengths[i,]<-euc_dist(x1=c(zeebiecleaned[i,9],
                                         zeebiecleaned[i,10],
                                         zeebiecleaned[i,11]),
                                    x2=c(zeebiecleaned[i,12],
                                         zeebiecleaned[i,13],
                                         zeebiecleaned[i,14]))
}

# get angles
Tae_gut.invivoelevDep<-matrix(nrow=dim(zeebiecleaned)[1],ncol=1)
for (i in 1:dim(zeebiecleaned)[1]){
  Tae_gut.invivoelevDep[i,]<-asin(Tae_gut.cmc_dists[i,]/
                                  Tae_gut.cmc_lengths[i,])
}
# convert back to degrees and flip the sign so that
# elevation is positive and depression is negative
-1*rad2deg(as.numeric(Tae_gut.invivoelevDep))->Tae_gut.invivoelevDep

# quick plot
# Cadaver elev/depression vs. in vivo elev/depression
plot(rangeElevDep.Tae_gut_361$elbowAngle,
     rangeElevDep.Tae_gut_361$maxElevation,
     pch=19,xlim=c(0,200),ylim=c(-90,90),yaxt='n',xaxt='n',bty="n",asp=1)
axis(side=1,at=c(0,90,180),tck=0.02)
axis(side=2,at=c(-90,0,90),tck=0.02)
points(rangeElevDep.Tae_gut_361$elbowAngle,
       rangeElevDep.Tae_gut_361$maxDepression,
       pch=19)
points(Tae_gut.invivothreed$elbowAngle,
       Tae_gut.invivoelevDep,pch=19,col='orange')

# check if points are inside alpha hull
# first re-format data
Tae_gut.elevDep_testdf<-data.frame(elbowAngle=Tae_gut.invivothreed$elbowAngle,
                                   manusAngle=Tae_gut.invivothreed$manusAngle,
                                   elevDepAngles=Tae_gut.invivoelevDep)
Tae_gut.elevDep_testmat<-as.matrix(Tae_gut.elevDep_testdf)

# second, re-format the alpha hull to allow for testing over
# full range of values; i.e. list elbow and manus angles twice, each with
# corresponding elevation and depression capability
Tae_gut.elevDep_hull<-matrix(nrow=2*nrow(rangeElevDep.Tae_gut_361),ncol=3)
Tae_gut.elevDep_hull[,1]<-c(rangeElevDep.Tae_gut_361$elbowAngle,
                            rangeElevDep.Tae_gut_361$elbowAngle)
Tae_gut.elevDep_hull[,2]<-c(rangeElevDep.Tae_gut_361$manusAngle,
                            rangeElevDep.Tae_gut_361$manusAngle)
Tae_gut.elevDep_hull[,3]<-c(rangeElevDep.Tae_gut_361$maxDepression,
                            rangeElevDep.Tae_gut_361$maxElevation)
colnames(Tae_gut.elevDep_hull)<-c("elbowAngle","manusAngle","elevDepAngles")
# need to add pert=TRUE to ashape3d because of singularities
# perturbations are very minor (1e-09*SD(data))
Tae_gut.elevDep_rehull<-ashape3d(Tae_gut.elevDep_hull,alpha=100)

# use inashape3d() to test
# if any FALSE appears, the point is outside the hull
Tae_gut.elevDep_test<-inashape3d(Tae_gut.elevDep_rehull,
                                 indexAlpha='all',
                                 points=Tae_gut.elevDep_testmat)
# are any found outside the hull?
if(any(Tae_gut.elevDep_test==FALSE))
  print("point(s) outside hull found")
if(!any(Tae_gut.elevDep_test==FALSE))
  print("all points inside hull")


########################### import gull in vivo data ###########################

# import zeebie data as zeebiedat
gullinvivodat<-read.csv("./in_vivo_data/harveyetal_jrsi2019_invivo_gulls.csv")

########################## gull extension flextion ############################

plot(gullinvivodat$elbow.angle,gullinvivodat$manus.angle,
     pch=19,xlim=c(0,200),ylim=c(0,200),yaxt='n',xaxt='n',bty="n",asp=1)
axis(side=1,at=c(0,90,180),tck=0.02)
axis(side=2,at=c(0,90,180),tck=0.02)
lines(chull.stack$Larus_glaucescens,pch=19,col='orange')
lines(ordered.extensions.data$Lar_gla.linkage.ext$elbowAngle,
      loess.extensions.predicts$Lar_gla.linkage.ext,
      pch=19,col='grey')
