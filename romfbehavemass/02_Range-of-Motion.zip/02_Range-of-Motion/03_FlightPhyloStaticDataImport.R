##this script imports flight behavior information, computes flight groups,
##brings in phylogeny, conducts phylogenetic PCA on extension ROM data,
##imports static data, and then conducts pPCA on static data

########################### tree import and pruning ############################
#rename the dataset according to phylogeny
configSpace.PCA$x->cS.PCA.scores

#read in tree and then match to data
tree.full<-read.nexus("./trees/v02b2_MCCtree.tre")
#match data and phylogeny
cS.PCA.matched<-treedata(tree.full,cS.PCA.scores,sort=TRUE)
ladderize(cS.PCA.matched$phy)->timetree
plot(timetree);axisPhylo(side=1,root.time=NULL,backward=TRUE)
configSpace.eFourier[[1]]->cS.eFourier.forPCA
rownames(cS.eFourier.forPCA)<-rownames(cS.PCA.scores)

############################### flight styles ##################################
#import the flight matrix
peet<-"./avian_metadata/"
psk<-list.files(path=peet,pattern="2018-12-13_61sp_",full.names=TRUE,
                recursive=TRUE)
flightstyles<-read.xlsx(psk[1],sheetIndex=1)
rownames(flightstyles)<-flightstyles[,1]
flightmat<-flightstyles[,c(3:14)]
rownames(flightmat)<-flightstyles[,1]
# create data frames to be used later for measuring phylogenetic signal
flightmat_binary<-ifelse(flightmat=="Yes", 1,0) 
flightmat_binaryDF<-as.data.frame(flightmat_binary)
#weights according to relative frequency
freqs<-1-colSums(flightmat_binary)/nrow(flightmat_binary)
# compute Gower distance matrix
gowerOne<-daisy(flightmat,metric='gower',stand=TRUE,
                weights=c(scale(freqs,center=FALSE)))
# re-format as matrix & df for later use
as.matrix(gowerOne)->gowerMat
data.frame(gowerMat)->gowerDF
# hierarchical clustering using Ward's D2
hc<-hclust(gowerOne,method='ward.D2')
d<-ladderize(as.dendrogram(hc))
# use the Gap statistic to determine the best # of clusters to use
set.seed(1) # for reproducibility 
gap_stat<-clusGap(as.matrix(gowerOne),FUN=kmeans,
                  K.max=10,B=500)
print(gap_stat,method="globalSEmax")
plot(gap_stat,frame=FALSE,xlab="Number of clusters k")


# so we'll use 9 groups
k=9
flightgroup<-cutree(hc,k=k)
flightletters<-sapply(flightgroup, function(i) letters[i])
a <- order(names(flightgroup))
flightgroup[a]->flightalpha
flightcols<-viridis(k)
cols.fg<-colorFactor(c("#343433","#F9A31A","#0BB6EA","#069F77","#F4E539",
                       "#989897","#F16622","#E07CAA","#0077B7"),
                     domain=flightgroup)
as.character(flightgroup)->b
names(b)<-names(flightgroup)
flightptls<-setNames(c("#343433","#F9A31A","#0BB6EA","#069F77","#F4E539",
                       "#989897","#F16622","#E07CAA","#0077B7"),
                     c("a","b","c","d","e","f","g","h","i"))
d<-d%>%color_branches(k=k,col=flightptls)%>%color_labels(k=k,col=flightptls)
par(mar=c(3,1,1,10))
plot(d,horiz=TRUE);par(mar=c(c(5,4,4,2)))

##the code below is commented out as it is not truly necessary to proceed with 
##analyses:
#phyloPCA of flight behaviors
#this helps identify the flight behaviors that best describe each group
#flight_pPCA<-phyl.pca(timetree,flightmat_binaryDF,method="lambda")
#a <- order(names(flightgroup))
#flightgroup[a]->flightalpha
#flighttip.cols<-cols.fg(flightalpha)
#names(flighttip.cols)<-timetree$tip.label
#flight.pmscols<-c(flighttip.cols[timetree$tip.label],rep("black",timetree$Nnode))
#names(flight.pmscols)<-1:(length(timetree$tip)+timetree$Nnode)
#phylomorphospace(timetree,flight_pPCA$S[,1:2],label="horizontal",
#                 node.size=c(0,2),control=list(col.node=flight.pmscols))
#plot(hclust(dist(flight_pPCA$L)))
#plot(flight_pPCA$L[,1],flight_pPCA$L[,2],pch=19,asp=1)
#text(flight_pPCA$L[,1],flight_pPCA$L[,2],labels=rownames(flight_pPCA$L),cex=0.7)

#alternatively, with phylogenetic FDA (same results)
#gA<-newdat$flightgroup;g<-newdat$flightgroup
#XA<-flightmat_binaryDF;X<-flightmat_binaryDF
#tretre<-timetree;tre<-timetree
#treetrans=lambdaTree
#ol1<-optLambda(X,g,tre,idc=filename_stem) #Identifying optimal lambda
#pri<-c(rep(1/9,9)) # The prior probabilities: uniform
#optl<-ol1$optlambda  # Use the optimal lambda value from above.
#f_pfda<-phylo.fda(XA,gA,tretre,val=optl,priin=pri) # FDA
#f_pfda$fit$coefficients
#f_propCor.emp<-sum(diag(f_pfda$confusion))/sum(
#  colSums(f_pfda$confusion))


#incorporate flight group into PCA object as factor
configSpace.proc$fac<-data.frame(as.character(flightgroup))
configSpace.eFourier<-efourier(configSpace.proc,nb.h=5,verbose=TRUE,norm=FALSE)
configSpace.PCA<-Momocs::PCA(configSpace.eFourier,scale.=FALSE,
                     center=TRUE,fac='as.character.flightgroup.')
#plot
plot(configSpace.PCA,fac='as.character.flightgroup.',cex=3,xax=1,yax=2,
     pos.shp="range_axes",labelspoints=TRUE,abbreviate.labelspoints=FALSE,
     box=FALSE,chull.filled.alpha=0.66,chull.lty=0,col=cols.fg(flightgroup))


############################# phylo ordination #################################
# phylogenetic PCA of configSpace
configSpace.pPCA<-phyl.pca(timetree,cS.eFourier.forPCA,method='lambda')
tip.cols<-cols.fg(flightalpha)
names(tip.cols)<-timetree$tip.label
cS.pmscols<-c(tip.cols[timetree$tip.label],rep("black",timetree$Nnode))
names(cS.pmscols)<-1:(length(timetree$tip)+timetree$Nnode)
# phylogenetic PCA plot
phylomorphospace(timetree,configSpace.pPCA$S[,1:2],label="horizontal",
                 node.size=c(0,2),control=list(col.node=cS.pmscols))
# for comparison, the original PCA
phylomorphospace(timetree,configSpace.PCA$x[,1:2],label="horizontal",
                 node.size=c(0,2),control=list(col.node=cS.pmscols))
# both are the same (with axes flipped, which is arbitrary). lambda is 0


################### import and/or re-organize static data ######################
#body mass
flightstyles$Mass->bodyMasses
names(bodyMasses)<-rownames(cS.eFourier.forPCA)

# log body mass
flightstyles$LnMass->bodyMassesLN
names(bodyMassesLN)<-rownames(cS.eFourier.forPCA)

# areas of config space
areas->CSareas
names(CSareas)<-rownames(cS.eFourier.forPCA)

# length of linkage trajectory
linkageshapes.lengths->LTlengths
names(LTlengths)<-names(dorsalROMs)

# data frame for extension ROM analyses
flightletters<-sapply(flightgroup, function(i) letters[i])
data.frame(flightletters,bodyMasses,bodyMassesLN,CSareas,
           configSpace.PCA$x)->newdat
rownames(newdat)->newdat[,25]
colnames(newdat)[1]<-"flightgroup"
colnames(newdat)[2]<-"RawMass"
colnames(newdat)[3]<-"LnMass"
colnames(newdat)[25]<-"phylo"

# import linkage trajectory & wing aspect ratio data, then re-organize
AR_Area<-read.csv("./AR-area/20181106_AR-Area.csv",
                  stringsAsFactors=F)

flightletters<-sapply(flightgroup, function(i) letters[i])
data.frame(flightletters)->flightdf
flightdf[,2]<-rownames(flightdf)
colnames(flightdf)<-c("flightgroup","phylo")

ROMmaxExtensionInfo[,c(2,3,5)]->ROMmaxExtension
colnames(ROMmaxExtension)<-c("maxElbow","maxManus","phylo")
AR_Area<-left_join(AR_Area,ROMmaxExtension)
AR_Area$elbowStand<-(AR_Area$elbowAngle/AR_Area$maxElbow)
AR_Area$manusStand<-(AR_Area$manusAngle/AR_Area$maxManus)
AR_Area<-dplyr::filter(AR_Area,elbowStand<=1.0)
AR_Area<-dplyr::filter(AR_Area,manusStand<=1.0)

data.frame(AR_Area$phylo,AR_Area$b2.s,
           AR_Area$WingArea_mmsq,AR_Area$WingLength_mm,
           AR_Area$elbowAngle,AR_Area$manusAngle,
           AR_Area$elbowStand,AR_Area$manusStand)->dat
colnames(dat)<-c("phylo","b2.s","wingArea","wingLength",
                 "elbowAngle","manusAngle",
                 "elbowStand","manusStand")

massdf<-data.frame(flightstyles$Binomial_name,flightstyles$Mass,
                   flightstyles$LnMass)
colnames(massdf)<-c("phylo","RawMass","LnMass")
dat<-left_join(dat,massdf,by="phylo")
dat<-left_join(dat,flightdf,by="phylo")
dat$phylo<-as.factor(dat$phylo)
dat$flightgroup<-as.factor(dat$flightgroup)
#max ARs
maxARs_LT<-tapply(dat$b2.s, dat$phylo, max)

# import static wing shape data and perform phylogenetic PCA
peet<-"./avian_metadata/"
met<-list.files(path=peet,pattern="2018-07-20_",full.names=TRUE,
                recursive=TRUE)
staticdat<-read.xlsx(met[1],sheetIndex=1)
rownames(staticdat)<-staticdat$phylo
sortedstatic<-comparative.data(timetree,staticdat,'phylo')
sortedstatic$data->staticmorph
ladderize(sortedstatic$phy)->stattree
#import coordinate data
shapespath<-"./max_extension_shapes/"
sps<-list.files(path=shapespath,pattern="*.txt",full.names=TRUE,
                recursive=TRUE)
staticshapes<-list()
for (i in 1:length(sps)){
  staticshapes[[i]]<-read.table(sps[i])
}
names(staticshapes)<-rownames(staticmorph)

#for use with the Momocs package to achieve elliptical Fourier analysis
Out(staticshapes)->staticshapes.Out

#the following functions place the 'principal point' on the distal wing tip
#this makes standardization of orientation easier
obj<-list()
minpts<-NULL
for (i in 1:length(staticshapes.Out)){
  obj[[i]]<-matrix(nrow=dim(staticshapes[[i]])[1])
}
for (i in 1:length(configSpace.Out)){
  for (j in 1:dim(staticshapes[[i]])[1]){
    obj[[i]][j,]<-sum(staticshapes[[i]][j,1],staticshapes[[i]][j,2])
  }
  minpts<-c(minpts,which.min(obj[[i]]))
}
staticshapes.slid<-coo_slide(staticshapes.Out,id=minpts)

#generalized procrustes analysis, followed by PCA
fgProcrustes(coo_interpolate(staticshapes.slid,500),
             tol=1e-10)->staticshapes.proc
stack(staticshapes.proc)
staticshapes.eFourier<-efourier(staticshapes.proc,nb.h=6,verbose=TRUE,
                                norm=FALSE)
a <- order(names(flightgroup))
flightgroup[a]->flightalpha
staticshapes.proc$fac<-data.frame(as.character(flightalpha))
staticshapes.eFourier<-efourier(staticshapes.proc,nb.h=6,verbose=TRUE,
                                norm=FALSE)
staticshapes.PCA<-PCA(staticshapes.eFourier,scale.=FALSE,
                      center=TRUE,fac='as.character.flightalpha.')
staticshapes.pPCA<-phyl.pca(timetree,staticshapes.eFourier[[1]],method='BM')
plot(staticshapes.PCA,fac='as.character.flightalpha.',cex=3,xax=1,yax=2,
     pos.shp="range_axes",labelspoints=TRUE,abbreviate.labelspoints=FALSE,
     box=FALSE,chull.filled.alpha=0.66,chull.lty=0,col=cols.fg(flightalpha))
tip.cols<-cols.fg(flightalpha)
names(tip.cols)<-timetree$tip.label
pmscols<-c(tip.cols[timetree$tip.label],rep("black",timetree$Nnode))
names(pmscols)<-1:(length(timetree$tip)+timetree$Nnode)
phylomorphospace(timetree,staticshapes.PCA$x[,1:2],label="horizontal",
                 node.size=c(0,2),control=list(col.node=pmscols))
phylomorphospace(timetree,staticshapes.pPCA$S[,1:2],label="horizontal",
                 node.size=c(0,2),control=list(col.node=pmscols))

# number of PCs to keep
input<-staticshapes.pPCA
staticshapes.varExpl<-rbind(
  SD = sqrt(rowSums(input$Eval)),
  Proportion = rowSums(input$Eval)/sum(rowSums(input$Eval)),
  Cumulative = cumsum(rowSums(input$Eval))/sum(rowSums(input$Eval)))
plot(1:ncol(staticshapes.varExpl),
     staticshapes.varExpl[2,],pch=19);abline(h=mean(staticshapes.varExpl[2,]))
plot(1:ncol(staticshapes.varExpl),staticshapes.varExpl[3,],
     pch=19,ylim=c(0,1));abline(h=0.95)


# organize for mcmcglmm
z <- as.data.frame(staticshapes.pPCA$S)
tt <- as.data.frame(staticmorph)
statdat<-merge(tt,z,by="row.names",all.x=TRUE)
flightdf->flightdff;colnames(flightdff)<-c("flightgroup","Row.names")
statdatdat<-left_join(statdat,flightdff,by="Row.names")
colnames(statdatdat)[1]<-"phylo"

