##to determine how well each data set predicts flight behavior, we used pFDA
##please remember to obtain the code for pFDA from Motani & Schmitz 2011
##each data set is analyzed separately


#################### extension ROM pFDA with CV #####################
nreps=61
CS_sps<-list()
CS_dats<-list()
CS_tests<-list()
CS_trees<-list()
for (i in 1:61){
  CS_sps[[i]]<-flightdf[i,]
  CS_dats[[i]]<-newdat[!newdat$phylo %in% CS_sps[[i]]$phylo,]
  CS_tests[[i]]<-newdat[newdat$phylo %in% CS_sps[[i]]$phylo,]
  CS_trees[[i]]<-drop.tip(timetree,CS_tests[[i]]$phylo)
}
CS_propCor.empir<-NULL
CS_propCor.rando<-NULL
CS_Cohens_K_reps<-NULL
for(i in 1:nreps){
  #empirical data
  gA<-CS_dats[[i]]$flightgroup;g<-CS_dats[[i]]$flightgroup;
  XA<-CS_dats[[i]][,c(5:9)];X<-CS_dats[[i]][,c(5:9)];
  tretre<-CS_trees[[i]];tre<-CS_trees[[i]]
  treetrans=lambdaTree
  ol1<-optLambda(X,g,tre,idc=filename_stem) #Identifying optimal lambda
  pri<-c(rep(1/9,9)) # The prior probabilities: uniform
  optl<-ol1$optlambda  # Use the optimal lambda value from above.
  c_pfda<-phylo.fda(XA,gA,tretre,val=optl,priin=pri) #data,grp,tretre
  CS_propCor.empir[[i]]<-sum(diag(c_pfda$confusion))/sum(
    colSums(c_pfda$confusion))
  
  #now randomized
  gA<-sample(CS_dats[[i]]$flightgroup)
  g<-sample(CS_dats[[i]]$flightgroup);
  XA<-sample_n(CS_dats[[i]][,c(5:9)],dim(CS_dats[[i]][,c(5:9)])[1])     
  X<-sample_n(CS_dats[[i]][,c(5:9)],dim(CS_dats[[i]][,c(5:9)])[1]) 
  rownames(XA)<-rownames(CS_dats[[1]][,c(5:9)])
  rownames(X)<-rownames(CS_dats[[1]][,c(5:9)])
  tretre<-CS_trees[[i]];tre<-CS_trees[[i]]    
  treetrans=lambdaTree
  ol1<-optLambda(X,g,tre,idc=filename_stem) #Identifying optimal lambda
  pri<-c(rep(1/9,9)) # The prior probabilities: uniform
  optl<-ol1$optlambda  # Use the optimal lambda value from above.
  rand_pfda<-phylo.fda(XA,gA,tretre,val=optl,priin=pri) #randomized
  CS_propCor.rando[[i]]<-sum(diag(rand_pfda$confusion))/sum(
    colSums(rand_pfda$confusion))
  
  #compute cohen's k
  CS_Cohens_K_reps[[i]]<-(CS_propCor.empir[[i]]-
                            CS_propCor.rando[[i]])/(1-CS_propCor.rando[[i]])
  print(i)
}
ldply(CS_propCor.empir)->CS_propCor.empirical
colnames(CS_propCor.empirical)<-"propCorrect";summary(CS_propCor.empirical)
ldply(CS_propCor.rando)->CS_propCor.random
colnames(CS_propCor.random)<-"propCorrect";summary(CS_propCor.random)
ldply(CS_Cohens_K_reps)->CS_Cohens_K_reps;
summary(CS_Cohens_K_reps);#hist(CS_Cohens_K_reps$V1)
CS_pfda_randTest<-data.frame(empirical=CS_propCor.empirical[,1],
                             random=CS_propCor.random[,1],
                             Cohens_Kreps=CS_Cohens_K_reps[,1])

#cohen's K
CS_Cohens_K<-(mean(CS_propCor.empirical[,1])-
                mean(CS_propCor.random[,1]))/(1-mean(CS_propCor.random[,1]))


CS_pdfaplot<-ggplot(CS_pfda_randTest) + 
  coord_cartesian(xlim=c(-0.25,0.75),ylim=c(0,40)) +
  geom_density(aes(x=random,y=..density..,fill='random'))+
  geom_density(aes(x=empirical,y=..density..,fill='empirical'))+
  geom_density(aes(x=Cohens_Kreps,y=..density..,fill='Cohens_Kreps'))+
  theme_ridges()
CS_pdfaplot


#################### static wing shape pFDA with CV #####################

nreps=61
ST_sps<-list()
ST_dats<-list()
ST_tests<-list()
ST_trees<-list()
for (i in 1:61){
  ST_sps[[i]]<-flightdf[i,]
  ST_dats[[i]]<-statdatdat[!statdatdat$phylo %in% ST_sps[[i]]$phylo,]
  ST_tests[[i]]<-statdatdat[statdatdat$phylo %in% ST_sps[[i]]$phylo,]
  ST_trees[[i]]<-drop.tip(timetree,ST_tests[[i]]$phylo)
}
ST_propCor.empir<-NULL
ST_propCor.rando<-NULL
ST_Cohens_K_reps<-NULL
ST_optl_empir<-NULL
ST_optl_rando<-NULL
for(i in 1:nreps){
  #empirical data
  gA<-ST_dats[[i]]$flightgroup;g<-ST_dats[[i]]$flightgroup;
  XA<-ST_dats[[i]][,c(25:29)];X<-ST_dats[[i]][,c(25:29)];
  tretre<-ST_trees[[i]];tre<-ST_trees[[i]]
  treetrans=lambdaTree
  ol1<-optLambda(X,g,tre,idc=filename_stem) #Identifying optimal lambda
  pri<-c(rep(1/9,9)) # The prior probabilities: uniform
  ST_optl_empir[[i]]<-ol1$optlambda  # Use the optimal lambda value from above.
  s_pfda<-phylo.fda(XA,gA,tretre,val=ST_optl_empir[[i]],priin=pri) #data,grp,tretre
  ST_propCor.empir[[i]]<-sum(diag(s_pfda$confusion))/sum(
    colSums(s_pfda$confusion))
  
  #now randomized
  gA<-sample(ST_dats[[i]]$flightgroup)
  g<-sample(ST_dats[[i]]$flightgroup);
  XA<-sample_n(ST_dats[[i]][,c(25:29)],dim(ST_dats[[i]][,c(25:29)])[1])     
  X<-sample_n(ST_dats[[i]][,c(25:29)],dim(ST_dats[[i]][,c(25:29)])[1]) 
  rownames(XA)<-rownames(ST_dats[[1]][,c(25:29)])
  rownames(X)<-rownames(ST_dats[[1]][,c(25:29)])
  tretre<-ST_trees[[i]];tre<-ST_trees[[i]]    
  treetrans=lambdaTree
  ol1<-optLambda(X,g,tre,idc=filename_stem) #Identifying optimal lambda
  pri<-c(rep(1/9,9)) # The prior probabilities: uniform
  ST_optl_rando[[i]]<-ol1$optlambda  # Use the optimal lambda value from above.
  rand_pfda<-phylo.fda(XA,gA,tretre,val=ST_optl_rando[[i]],priin=pri) #randomized
  ST_propCor.rando[[i]]<-sum(diag(rand_pfda$confusion))/sum(
    colSums(rand_pfda$confusion))
  
  #compute cohen's k
  ST_Cohens_K_reps[[i]]<-(ST_propCor.empir[[i]]-
                            ST_propCor.rando[[i]])/(1-ST_propCor.rando[[i]])
  print(i)
}
ldply(ST_propCor.empir)->ST_propCor.empirical
colnames(ST_propCor.empirical)<-"propCorrect";summary(ST_propCor.empirical)
ldply(ST_propCor.rando)->ST_propCor.random
colnames(ST_propCor.random)<-"propCorrect";summary(ST_propCor.random)
ldply(ST_Cohens_K_reps)->ST_Cohens_K_reps;
summary(ST_Cohens_K_reps);#hist(ST_Cohens_K_reps$V1)
ST_pfda_randTest<-data.frame(empirical=ST_propCor.empirical[,1],
                             random=ST_propCor.random[,1],
                             Cohens_Kreps=ST_Cohens_K_reps[,1])
melt(ST_pfda_randTest)->ST_pfda_randtidy

#cohen's K
ST_Cohens_K<-(mean(ST_propCor.empirical[,1])-
                mean(ST_propCor.random[,1]))/(1-mean(ST_propCor.random[,1]))


ST_pdfaplot<-ggplot(ST_pfda_randTest) + 
  coord_cartesian(xlim=c(-0.25,0.75),ylim=c(0,40)) +
  geom_density(aes(x=random,y=..density..,fill='random'))+
  geom_density(aes(x=empirical,y=..density..,fill='empirical'))+
  geom_density(aes(x=Cohens_Kreps,y=..density..,fill='Cohens_Kreps'))+
  theme_ridges()
ST_pdfaplot


#################### mass only pFDA with CV #####################


nreps=61
MS_sps<-list()
MS_dats<-list()
MS_tests<-list()
MS_trees<-list()
for (i in 1:61){
  MS_sps[[i]]<-flightdf[i,]
  MS_dats[[i]]<-newdat[!newdat$phylo %in% MS_sps[[i]]$phylo,]
  MS_tests[[i]]<-newdat[newdat$phylo %in% MS_sps[[i]]$phylo,]
  MS_trees[[i]]<-drop.tip(timetree,MS_tests[[i]]$phylo)
}
MS_propCor.empir<-NULL
MS_propCor.rando<-NULL
MS_Cohens_K_reps<-NULL
for(i in 1:nreps){
  #empirical data
  gA<-MS_dats[[i]]$flightgroup;g<-MS_dats[[i]]$flightgroup;
  XA<-data.frame(LnMass=MS_dats[[i]]$LnMass);
  X<-data.frame(LnMass=MS_dats[[i]]$LnMass);
  rownames(XA)<-MS_dats[[i]]$phylo;rownames(X)<-MS_dats[[i]]$phylo;
  tretre<-MS_trees[[i]];tre<-MS_trees[[i]]
  treetrans=lambdaTree
  ol1<-optLambda(X,g,tre,idc=filename_stem) #Identifying optimal lambda
  pri<-c(rep(1/9,9)) # The prior probabilities: uniform
  optl<-ol1$optlambda  # Use the optimal lambda value from above.
  c_pfda<-phylo.fda(XA,gA,tretre,val=optl,priin=pri) #data,grp,tretre
  MS_propCor.empir[[i]]<-sum(diag(c_pfda$confusion))/sum(
    colSums(c_pfda$confusion))
  
  #now randomized
  gA<-sample(MS_dats[[i]]$flightgroup)
  g<-sample(MS_dats[[i]]$flightgroup);
  XA<-data.frame(LnMass=sample_n(MS_dats[[i]],dim(MS_dats[[1]])[1])$LnMass) 
  X<-data.frame(LnMass=sample_n(MS_dats[[i]],dim(MS_dats[[1]])[1])$LnMass)
  rownames(XA)<-MS_dats[[i]]$phylo
  rownames(X)<-MS_dats[[i]]$phylo
  tretre<-MS_trees[[i]];tre<-MS_trees[[i]]    
  treetrans=lambdaTree
  ol1<-optLambda(X,g,tre,idc=filename_stem) #Identifying optimal lambda
  pri<-c(rep(1/9,9)) # The prior probabilities: uniform
  optl<-ol1$optlambda  # Use the optimal lambda value from above.
  rand_pfda<-phylo.fda(XA,gA,tretre,val=optl,priin=pri) #randomized
  MS_propCor.rando[[i]]<-sum(diag(rand_pfda$confusion))/sum(
    colSums(rand_pfda$confusion))
  
  #compute cohen's k
  MS_Cohens_K_reps[[i]]<-(MS_propCor.empir[[i]]-
                            MS_propCor.rando[[i]])/(1-MS_propCor.rando[[i]])
  print(i)
}
ldply(MS_propCor.empir)->MS_propCor.empirical
colnames(MS_propCor.empirical)<-"propCorrect";summary(MS_propCor.empirical)
ldply(MS_propCor.rando)->MS_propCor.random
colnames(MS_propCor.random)<-"propCorrect";summary(MS_propCor.random)
ldply(MS_Cohens_K_reps)->MS_Cohens_K_reps;
summary(MS_Cohens_K_reps);#hist(MS_Cohens_K_reps$V1)
MS_pfda_randTest<-data.frame(empirical=MS_propCor.empirical[,1],
                             random=MS_propCor.random[,1],
                             Cohens_Kreps=MS_Cohens_K_reps[,1])

#cohen's K
MS_Cohens_K<-(mean(MS_propCor.empirical[,1])-
                mean(MS_propCor.random[,1]))/(1-mean(MS_propCor.random[,1]))


MS_pdfaplot<-ggplot(MS_pfda_randTest) + 
  coord_cartesian(xlim=c(-0.25,0.75),ylim=c(0,40)) +
  geom_density(aes(x=random,y=..density..,fill='random'))+
  geom_density(aes(x=empirical,y=..density..,fill='empirical'))+
  geom_density(aes(x=Cohens_Kreps,y=..density..,fill='Cohens_Kreps'))+
  theme_ridges()
MS_pdfaplot



