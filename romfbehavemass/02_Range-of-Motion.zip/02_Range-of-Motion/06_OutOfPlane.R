##this script imports and then analyzes out-of-plane patterns. bending is 
##analyzed first, followed by twisting. for each data set, models are first 
##compared via DIC and cross-validation. effect sizes are then computed after
##phylogeny is varied.


############################### pre-processing #################################
as.character(staticdat$phylo)->staticdat$phylo
as.character(staticdat$common)->staticdat$common

fl<-(data.frame(phylo=(newdat$phylo),flightletters))
fl$phylo<-as.character(fl$phylo)
fl$flightletters<-as.character(fl$flightletters)
########################## BENDING: data sourcing ##############################
#source individual species analyses
#all of these files will have "6bar-frames" in the title
edpath<-"./data_import_scripts/Bend_twist/"
edlist<-list.files(path=edpath,pattern="*_dorsVen.R",
                   full.names=TRUE,recursive=TRUE)
for(i in 1:length(edlist)){
  source(edlist[i])
}

############################## organize elevDep ################################
eleDepList<-ls(pattern='rangeElevDep')
eleDepList.list<-rbind(mget(eleDepList))
names(eleDepList.list)<-eleDepList

ldply(eleDepList.list)->eleDepMat

p<-ggplot(eleDepMat,aes(elbowAngle,manusAngle))
p+geom_point(size=4,aes(colour=eleDepCapability)) +
  coord_fixed(ratio=1/1) +
  coord_cartesian(xlim=c(0,200),ylim=c(0,200)) +
  scale_color_viridis(discrete=FALSE,option="A") +
  facet_wrap(~id,ncol=5)+
  theme_bw()

maxEDcaps<-ddply(eleDepMat,~id,summarise,
                 maxEDcap=max(eleDepCapability),
                 maxDepr=abs(min(maxDepression)),
                 maxElev=max(maxElevation))
colnames(maxEDcaps)<-c("phylo","EDcap","Depr","Elev")
maxEDcaps->ED.tableA
ED.tableA$fac<-"Maximum value"
ED.tableA<-left_join(ED.tableA,staticdat[,2:12],by="phylo")
ED.tableA<-left_join(ED.tableA,fl,by="phylo")

obj<-list()
eleDepStatFrames<-NULL
for (i in 1:length(eleDepList.list)){
  obj[[i]]<-matrix(nrow=dim(eleDepList.list[[i]])[1])
}
for (i in 1:length(eleDepList.list)){
  for (j in 1:dim(eleDepList.list[[i]])[1]){
    obj[[i]][j,]<-sum(eleDepList.list[[i]][j,1],eleDepList.list[[i]][j,2])
  }
  eleDepStatFrames<-c(eleDepStatFrames,which.max(obj[[i]]))
}
odb<-list()
for (i in 1:length(eleDepList.list)){
  odb[[i]]<-eleDepList.list[[i]][eleDepStatFrames[i],]
}
ldply(odb)->statED
colnames(statED)<-c("maxElbow","maxManus","statDepr","statElev","statEDcap","phylo")
statED$statDepr<-abs(statED$statDepr);statED->ED.tableB;
ED.tableB$fac<-"Value at full wing extension"
colnames(ED.tableB)<-c("maxElbow","maxManus","Depr","Elev","EDcap","phylo","fac")
ED.tableB<-dplyr::select(ED.tableB,c("phylo","EDcap","Depr","Elev","fac"))
ED.tableB<-left_join(ED.tableB,staticdat[,2:12],by="phylo")
ED.tableB<-left_join(ED.tableB,fl,by="phylo")

eleDepSummary<-left_join(maxEDcaps,statED,by="phylo")
eleDepSummary<-left_join(eleDepSummary,fl,by="phylo")
eleDepPlotting<-rbind(ED.tableA,ED.tableB)
eleDepModeling<-eleDepSummary
eleDepModeling$statEDcap - eleDepModeling$EDcap->eleDepModeling$diffs
eleDepModeling<-left_join(eleDepModeling,staticdat[,2:12],by="phylo")


#groups A, C, D, and G are well-represented (5+ species) and will be used
#for analyses involving flight behavior as a fixed effect
eleDepPlotting_ACDG<-dplyr::filter(eleDepPlotting,flightletters=='c'|
                                     flightletters=='g'|
                                     flightletters=='a'|
                                     flightletters=='d')

eleDepModeling_ACDG<-dplyr::filter(eleDepModeling,flightletters=='c'|
                                     flightletters=='g'|
                                     flightletters=='a'|
                                     flightletters=='d')

ED.tableB_ACDG<-dplyr::filter(ED.tableB,flightletters=='c'|
                                flightletters=='g'|
                                flightletters=='a'|
                                flightletters=='d')

###############################  elevDep MCMC ##################################
OOPtrimmed<-comparative.data(timetree,ED.tableB,names.col='phylo')
ladderize(OOPtrimmed$phy)->oopTree
inv.phylo<-inverseA(oopTree,nodes="TIPS",scale=TRUE)
prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))

EDcap_30spMass<-MCMCglmm(EDcap~fac+LnMass-1,random=~phylo,
                     data=eleDepPlotting,ginverse=list(phylo=inv.phylo$Ainv),
                     verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
                     nitt=15000,burnin=1500,thin=13,
                     saveX=TRUE,saveZ=TRUE,saveXL=TRUE)
summary(EDcap_30spMass)
plot.estimatesMCMC(EDcap_30spMass$Sol)
EDcap_mcmc_lambda<-(EDcap_30spMass$VCV[,1])/(EDcap_30spMass$VCV[,1]+EDcap_30spMass$VCV[,2])
plot(EDcap_mcmc_lambda);mean(EDcap_mcmc_lambda);HPDinterval(EDcap_mcmc_lambda)

OOPtrimmed_ACDG<-comparative.data(timetree,ED.tableB_ACDG,names.col='phylo')
ladderize(OOPtrimmed_ACDG$phy)->oopTree_ACDG
inv.phylo<-inverseA(oopTree_ACDG,nodes="TIPS",scale=TRUE)
prior<-list(G=list(G1=list(V=1,nu=0.2)),R=list(V=1,nu=0.2))

EDcapACDG_mcmc<-MCMCglmm(EDcap~LnMass+flightletters+fac-1,random=~phylo,
                     data=eleDepPlotting_ACDG,ginverse=list(phylo=inv.phylo$Ainv),
                     verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
                     nitt=15000,burnin=1500,thin=13,
                     saveX=TRUE,saveZ=TRUE,saveXL=TRUE)
summary(EDcapACDG_mcmc)
plot.estimatesMCMC(EDcapACDG_mcmc$Sol[,1:6])
EDcapACDG_mcmc_lambda<-(EDcapACDG_mcmc$VCV[,1])/(EDcapACDG_mcmc$VCV[,1]+EDcapACDG_mcmc$VCV[,2])
plot(EDcapACDG_mcmc_lambda);mean(EDcapACDG_mcmc_lambda)


EDcapACDG_mcmc->m_glmm
get_variables(m_glmm)

m_glmm %>% emmeans( ~ flightletters, data = eleDepPlotting_ACDG) %>%
  emmeans::contrast(adjust='none',method='eff') %>%
  gather_emmeans_draws() %>%
  ggplot(aes(x = .value, y = contrast)) +
  geom_halfeyeh(.width=0.95) +
  geom_vline(xintercept=0) + theme_ridges()

m_glmm %>% emmeans( ~ flightletters, data = eleDepPlotting_ACDG) %>%
  emmeans::contrast(adjust='none',method='pairwise') %>%
  gather_emmeans_draws() %>%
  ggplot(aes(x = .value, y = contrast)) +
  geom_halfeyeh(.width=0.95) +
  geom_vline(xintercept=0)

EDallChains<-as.mcmc(cbind(EDcapACDG_mcmc$Sol,EDcapACDG_mcmc$VCV))
model0ED.rg<-ref.grid(EDcapACDG_mcmc,data=eleDepPlotting_ACDG)
flightED.lsm<-lsmeans(model0ED.rg,"flightletters",by="LnMass")
massED.lsm<-lsmeans(model0ED.rg,"LnMass",by='flightletters')
lsmeans::contrast(flightED.lsm,adjust='none',method='eff')
lsmeans::test(flightED.lsm)
lsmeans::cld(flightED.lsm,alpha=0.05,adjust='none')
plot(lsmeans::contrast(flightED.lsm,adjust='none'))
plot(flightED.lsm,comparisons=TRUE,alpha=0.05)

EDallChains<-as.mcmc(cbind(EDcapACDG_mcmc$Sol,EDcapACDG_mcmc$VCV))
#plotTrace(allChains,axes=TRUE,las=1)
# Least square means. Note you must specify the data
model0ED.rg<-ref.grid(EDcapACDG_mcmc,data=eleDepPlotting_ACDG)
flightED.lsm<-lsmeans(model0ED.rg,"flightletters")
contrast(flightED.lsm,adjust='none',method='eff')
contrast(flightED.lsm,adjust='none',method='pairwise')
test(flightED.lsm)
cld(flightED.lsm,alpha=0.05,adjust='none')
plot(contrast(flightED.lsm,adjust='none'))
plot(flightED.lsm,comparisons=TRUE,alpha=0.05)


#################### eledep cross-validation ######################

## define folds
vec<-1:21
set.seed(100)
samp<-sample(vec)
OOP_foldsList<-split(samp,ceiling(seq_along(samp)/3))
OOP_foldsListdupes<-lapply(OOP_foldsList, '+',21)
OOP_foldscomb<-NULL
for (i in 1:length(OOP_foldsList)){
  OOP_foldscomb[[i]]<-c(OOP_foldsList[[i]],OOP_foldsListdupes[[i]])
}

OOP_folds<-NULL
EDcv_dats<-list()
EDcv_tests<-list()
for (i in 1:(length(OOP_foldsList))){
  OOP_folds[[i]]<-eleDepPlotting_ACDG[OOP_foldscomb[[i]],]
  EDcv_tests[[i]]<-eleDepPlotting_ACDG[eleDepPlotting_ACDG$phylo %in% OOP_folds[[i]]$phylo,]
  EDcv_dats[[i]]<-eleDepPlotting_ACDG[!eleDepPlotting_ACDG$phylo %in% OOP_folds[[i]]$phylo,]
}

library(parallel)
Sys.time()
oopTree_ACDG->inTree
inv.phylo<-inverseA(inTree,nodes="TIPS",scale=TRUE)
prior<-list(G=list(G1=list(V=1,nu=0.002)),R=list(V=1,nu=0.002))
setCores<-round(detectCores()*0.66) #use 75% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
parallel::clusterExport(cl,"EDcv_dats")
parallel::clusterExport(cl,"EDcv_tests")
parallel::clusterExport(cl,"inv.phylo")
parallel::clusterExport(cl,"prior")

NREPS<-length(EDcv_dats)
EDcv_m04_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(EDcap~LnMass+flightletters+fac-1,
           random=~phylo,scale=TRUE,data=EDcv_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m04 done");Sys.time()
EDcv_m02_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(EDcap~flightletters+fac-1,
           random=~phylo,scale=TRUE,data=EDcv_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m02 done");Sys.time()
EDcv_m03_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(EDcap~LnMass+fac-1,
           random=~phylo,scale=TRUE,data=EDcv_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m03 done");Sys.time()
EDcv_m01_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(EDcap~fac-1,
           random=~phylo,scale=TRUE,data=EDcv_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m01 done");Sys.time()
stopCluster(cl)
Sys.time()

#collect relevant metrics
#lambdas first, only for PC1 for simplicity
print("collecting PC1 lambda traces");Sys.time()
EDcv_m04_lambda_traces<-lapply(1:length(EDcv_m04_mods),
                               function(i){(EDcv_m04_mods[[i]]$VCV[,1])/(
                                 EDcv_m04_mods[[i]]$VCV[,1]+EDcv_m04_mods[[i]]$VCV[,2])})
EDcv_m02_lambda_traces<-lapply(1:length(EDcv_m02_mods),
                               function(i){(EDcv_m02_mods[[i]]$VCV[,1])/(
                                 EDcv_m02_mods[[i]]$VCV[,1]+EDcv_m02_mods[[i]]$VCV[,2])})
EDcv_m03_lambda_traces<-lapply(1:length(EDcv_m03_mods),
                               function(i){(EDcv_m03_mods[[i]]$VCV[,1])/(
                                 EDcv_m03_mods[[i]]$VCV[,1]+EDcv_m03_mods[[i]]$VCV[,2])})
EDcv_m01_lambda_traces<-lapply(1:length(EDcv_m01_mods),
                               function(i){(EDcv_m01_mods[[i]]$VCV[,1])/(
                                 EDcv_m01_mods[[i]]$VCV[,1]+EDcv_m01_mods[[i]]$VCV[,2])})


#"fits" = predictions of model for training data (i.e. data that were used to
# generate the model)
print("generating model fits");Sys.time()
EDcv_m04_fits<-lapply(EDcv_m04_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                      verbose=TRUE)
EDcv_m02_fits<-lapply(EDcv_m02_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                      verbose=TRUE)
EDcv_m03_fits<-lapply(EDcv_m03_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                      verbose=TRUE)
EDcv_m01_fits<-lapply(EDcv_m01_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                      verbose=TRUE)


#"preds" = predictions on test data (data that were held out)
print("generating model predictions on test data");Sys.time()
EDcv_m04_preds<-lapply(1:length(EDcv_m04_mods),
                       function(i){
                         predict(EDcv_m04_mods[[i]],newdata=EDcv_tests[[i]],
                                 marginal=NULL,posterior="all",verbose=TRUE)})
EDcv_m02_preds<-lapply(1:length(EDcv_m02_mods),
                       function(i){
                         predict(EDcv_m02_mods[[i]],newdata=EDcv_tests[[i]],
                                 marginal=NULL,posterior="all",verbose=TRUE)})
EDcv_m03_preds<-lapply(1:length(EDcv_m03_mods),
                       function(i){
                         predict(EDcv_m03_mods[[i]],newdata=EDcv_tests[[i]],
                                 marginal=NULL,posterior="all",verbose=TRUE)})
EDcv_m01_preds<-lapply(1:length(EDcv_m01_mods),
                       function(i){
                         predict(EDcv_m01_mods[[i]],newdata=EDcv_tests[[i]],
                                 marginal=NULL,posterior="all",verbose=TRUE)})


#set up a new cluster for linear model fitting and MSEs
setCores<-round(detectCores()*0.75) #use 75% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
parallel::clusterExport(cl,"EDcv_dats")
parallel::clusterExport(cl,"EDcv_tests")
print("re-importing fits and preds");Sys.time()
parallel::clusterExport(cl,"EDcv_m04_fits")
parallel::clusterExport(cl,"EDcv_m02_fits")
parallel::clusterExport(cl,"EDcv_m03_fits")
parallel::clusterExport(cl,"EDcv_m01_fits")
parallel::clusterExport(cl,"EDcv_m04_preds")
parallel::clusterExport(cl,"EDcv_m02_preds")
parallel::clusterExport(cl,"EDcv_m03_preds")
parallel::clusterExport(cl,"EDcv_m01_preds")

#"fitsLMs" = fit lm()s to fits~training data
print("generating LMs of fits ~ training data");Sys.time()
EDcv_m04_fitsLMs<-parallel::parLapply(cl=cl,1:length(EDcv_m04_fits),
                                      function(i){
                                        lm(EDcv_m04_fits[[i]]~(EDcv_dats[[i]]$EDcap))
                                      })
EDcv_m02_fitsLMs<-parallel::parLapply(cl=cl,1:length(EDcv_m02_fits),
                                      function(i){
                                        lm(EDcv_m02_fits[[i]]~(EDcv_dats[[i]]$EDcap))
                                      })
EDcv_m03_fitsLMs<-parallel::parLapply(cl=cl,1:length(EDcv_m03_fits),
                                      function(i){
                                        lm(EDcv_m03_fits[[i]]~(EDcv_dats[[i]]$EDcap))
                                      })
EDcv_m01_fitsLMs<-parallel::parLapply(cl=cl,1:length(EDcv_m01_fits),
                                      function(i){
                                        lm(EDcv_m01_fits[[i]]~(EDcv_dats[[i]]$EDcap))
                                      })


#"predsLMs" = fit lm()s to preds~training data
print("generating LMs of preds ~ training data");Sys.time()
EDcv_m04_predsLMs<-parallel::parLapply(cl=cl,1:length(EDcv_m04_preds),
                                       function(i){
                                         lm(EDcv_m04_preds[[i]]~(EDcv_tests[[i]]$EDcap))
                                       })
EDcv_m02_predsLMs<-parallel::parLapply(cl=cl,1:length(EDcv_m02_preds),
                                       function(i){
                                         lm(EDcv_m02_preds[[i]]~(EDcv_tests[[i]]$EDcap))
                                       })
EDcv_m03_predsLMs<-parallel::parLapply(cl=cl,1:length(EDcv_m03_preds),
                                       function(i){
                                         lm(EDcv_m03_preds[[i]]~(EDcv_tests[[i]]$EDcap))
                                       })
EDcv_m01_predsLMs<-parallel::parLapply(cl=cl,1:length(EDcv_m01_preds),
                                       function(i){
                                         lm(EDcv_m01_preds[[i]]~(EDcv_tests[[i]]$EDcap))
                                       })


#'fitsMSEs' and 'predMSEs' = mean squared error from each regression
print("computing mean squared errors of fits");Sys.time()
EDcv_m04_fitsMSEs<-parallel::parSapply(cl=cl,EDcv_m04_fitsLMs,mse)
EDcv_m02_fitsMSEs<-parallel::parSapply(cl=cl,EDcv_m02_fitsLMs,mse)
EDcv_m03_fitsMSEs<-parallel::parSapply(cl=cl,EDcv_m03_fitsLMs,mse)
EDcv_m01_fitsMSEs<-parallel::parSapply(cl=cl,EDcv_m01_fitsLMs,mse)

print("computing mean squared errors of predictions");Sys.time()
EDcv_m04_predsMSEs<-parallel::parSapply(cl=cl,EDcv_m04_predsLMs,mse)
EDcv_m02_predsMSEs<-parallel::parSapply(cl=cl,EDcv_m02_predsLMs,mse)
EDcv_m03_predsMSEs<-parallel::parSapply(cl=cl,EDcv_m03_predsLMs,mse)
EDcv_m01_predsMSEs<-parallel::parSapply(cl=cl,EDcv_m01_predsLMs,mse)

stopCluster(cl)
Sys.time()


#collect and re-format MSEs for plotting
EDcv_m04_fitsMSEs_df<-EDcv_m04_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
EDcv_m02_fitsMSEs_df<-EDcv_m02_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
EDcv_m03_fitsMSEs_df<-EDcv_m03_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
EDcv_m01_fitsMSEs_df<-EDcv_m01_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
EDcv_m04_fitsMSEs_df$df<-12
EDcv_m02_fitsMSEs_df$df<-11
EDcv_m03_fitsMSEs_df$df<-3
EDcv_m01_fitsMSEs_df$df<-1
EDcv_m04_predsMSEs_df<-EDcv_m04_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
EDcv_m02_predsMSEs_df<-EDcv_m02_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
EDcv_m03_predsMSEs_df<-EDcv_m03_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
EDcv_m01_predsMSEs_df<-EDcv_m01_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
EDcv_m04_predsMSEs_df$df<-12
EDcv_m02_predsMSEs_df$df<-11
EDcv_m03_predsMSEs_df$df<-3
EDcv_m01_predsMSEs_df$df<-1

EDcv_fitsMSEs<-rbind(EDcv_m04_fitsMSEs_df,
                     EDcv_m02_fitsMSEs_df,
                     EDcv_m03_fitsMSEs_df,
                     EDcv_m01_fitsMSEs_df)
EDcv_predsMSEs<-rbind(EDcv_m04_predsMSEs_df,
                      EDcv_m02_predsMSEs_df,
                      EDcv_m03_predsMSEs_df,
                      EDcv_m01_predsMSEs_df)
EDcv_combinedMSEs<-left_join(EDcv_fitsMSEs,EDcv_predsMSEs,by='df')


p <- ggplot(EDcv_predsMSEs, aes(df, predsMSEs))
p + geom_point(aes(group=df),col='red',alpha=0.1,size=2) + 
  geom_point(data=EDcv_fitsMSEs,aes(group=df,y=fitsMSEs),alpha=0.1,col='black',size=2)+
  stat_summary(aes(y=predsMSEs,group=1),fun.y=mean,colour="red",
               geom="point",group=1,size=4)+ 
  stat_summary(data=EDcv_fitsMSEs,aes(y=fitsMSEs,group=1),fun.y=mean,
               colour="black",geom="point",group=1,size=4)+ 
  theme_bw()

aggregate(EDcv_fitsMSEs$fitsMSEs,list(EDcv_fitsMSEs$df),mean) 
aggregate(EDcv_predsMSEs$predsMSEs,list(EDcv_predsMSEs$df),mean)

mean(ldply(sapply(EDcv_m04_mods,summary)[1,])$V1)
mean(ldply(lapply(EDcv_m04_lambda_traces,mean))$V1)

EDcv_m04_mods[[1]]->mmF;colnames(EDcv_m04_mods[[1]]$Sol)
mVarF <- var(as.vector(apply(mmF$Sol[,1:6],2,mean) %*% t(mmF$X)))
#mVarF <- var(as.vector(mean(mmF$Sol[,1]) %*% t(mmF$X)))
# MCMCglmm - marginal
mVarF/(mVarF+sum(apply(mmF$VCV,2,mean)))
# alternative with crebile intervals
vmVarF<-numeric(dim(mmF$VCV)[1])
for(i in 1:dim(mmF$VCV)[1]){
  Var<-var(as.vector(mmF$Sol[,1:6][i,] %*% t(mmF$X)))
  #Var<-var(as.vector(mmF$Sol[,1:1][i] %*% t(mmF$X)))
  vmVarF[i]<-Var}
R2m<-vmVarF/(vmVarF+mmF$VCV[,1]+mmF$VCV[,2])
mean(R2m)
posterior.mode(R2m)
HPDinterval(R2m)
# MCMCglmm - conditional
R2c<-as.mcmc((vmVarF+(mmF$VCV))/(vmVarF+rowSums(mmF$VCV)))
mean(R2c)
posterior.mode(R2c)
HPDinterval(R2c)

#################### effect sizes for bending ROM MCMCs ######################
# effect sizes measured via cohen's f2

# first prune the pruned trees to ACDGs
drops<-name.check(timetree,eleDepModeling_ACDG,
                  data.names=eleDepModeling_ACDG$phylo)
PDpruned_ACDG<-lapply(PDpruned,drop.tip,drops$tree_not_data)


library(parallel)
Sys.time()
prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))
setCores<-round(detectCores()*0.66) #use 66% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
parallel::clusterExport(cl,"eleDepPlotting_ACDG")
parallel::clusterExport(cl,"prior")
parallel::clusterExport(cl,"PDpruned_ACDG")
NREPS<-length(PDpruned_ACDG)
  ED_mfg_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(EDcap~LnMass+flightletters+fac-1,random=~phylo,
             data=eleDepPlotting_ACDG,
             ginverse=list(phylo=inverseA(PDpruned_ACDG[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
             nitt=450000,burnin=45000,thin=39)})
    print("ED_mfg_Mods done");Sys.time()
  ED_m_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(EDcap~LnMass+fac-1,random=~phylo,
             data=eleDepPlotting_ACDG,
             ginverse=list(phylo=inverseA(PDpruned_ACDG[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
             nitt=450000,burnin=45000,thin=39)})
    print("ED_m_Mods done");Sys.time()
  ED_fg_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(EDcap~flightletters+fac-1,random=~phylo,
             data=eleDepPlotting_ACDG,
             ginverse=list(phylo=inverseA(PDpruned_ACDG[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
             nitt=450000,burnin=45000,thin=39)})
    print("m03 done");Sys.time()
  ED_null_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(EDcap~fac-1,random=~phylo,
             data=eleDepPlotting_ACDG,
             ginverse=list(phylo=inverseA(PDpruned_ACDG[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
             nitt=450000,burnin=45000,thin=39)})
    print("m01 done");Sys.time()
stopCluster(cl)
Sys.time()

#combine results
ED_mfg_VCV<-do.call(mcmc.list,lapply(ED_mfg_Mods,function(m) m$VCV[,2]))
ED_m_VCV<-do.call(mcmc.list,lapply(ED_m_Mods,function(m) m$VCV[,2]))
ED_fg_VCV<-do.call(mcmc.list,lapply(ED_fg_Mods,function(m) m$VCV[,2]))
ED_null_VCV<-do.call(mcmc.list,lapply(ED_null_Mods,function(m) m$VCV[,2]))

# Cohen's F2, computed via residual variance
ED_v_null_mods<-lapply(ED_null_VCV,mean)
ED_v_all_mods<-lapply(ED_mfg_VCV,mean)
ED_v_nofg_mods<-lapply(ED_m_VCV,mean)
ED_v_nomass_mods<-lapply(ED_fg_VCV,mean)

ED_f2_fg<-NULL
ED_f2_mass<-NULL
for (i in 1:length(ED_v_all_mods)){
  ED_f2_fg[[i]]<-mean((((ED_v_null_mods[[i]]-ED_v_all_mods[[i]])/ED_v_null_mods[[i]])-((ED_v_null_mods[[i]]-ED_v_nofg_mods[[i]])/ED_v_null_mods[[i]]))/(1-(ED_v_null_mods[[i]]-ED_v_all_mods[[i]])/ED_v_null_mods[[i]]))
  ED_f2_mass[[i]]<-mean((((ED_v_null_mods[[i]]-ED_v_all_mods[[i]])/ED_v_null_mods[[i]])-((ED_v_null_mods[[i]]-ED_v_nomass_mods[[i]])/ED_v_null_mods[[i]]))/(1-(ED_v_null_mods[[i]]-ED_v_all_mods[[i]])/ED_v_null_mods[[i]]))
}

ED_f2s<-data.frame(flightBehavior=ED_f2_fg,
                   mass=ED_f2_mass)
quantile(ED_f2s$flightBehavior,c(0.05,0.5,0.95))
quantile(ED_f2s$mass,c(0.05,0.5,0.95))


ED_f2s_plot<-ggplot(ED_f2s) + 
  geom_density(aes(x=ED_f2_fg,y=..density..,fill='ED_f2_fg'))+
  geom_density(aes(x=ED_f2_mass,y=..density..,fill='ED_f2_mass'))+
  theme_ridges()
ED_f2s_plot


#lambda
quantile(melt(ED_m04_lambda_traces)[,1],c(0.05,0.5,0.95))
mean_hdi(melt(ED_m04_lambda_traces)$value)
median_hdi(melt(ED_m04_lambda_traces)$value)
mode_hdi(melt(ED_m04_lambda_traces)$value)


#################### effect sizes for bending ROM MASS MCMCs ######################
# first prune the pruned trees to ACDGs
drops2<-name.check(timetree,eleDepModeling,
                  data.names=eleDepModeling$phylo)
PDprunEDm<-lapply(PDpruned,drop.tip,drops2$tree_not_data)


library(parallel)
Sys.time()
prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))
setCores<-round(detectCores()*0.66) #use 66% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
parallel::clusterExport(cl,"eleDepPlotting")
parallel::clusterExport(cl,"prior")
parallel::clusterExport(cl,"PDprunEDm")
NREPS<-length(PDprunEDm)
#EDm_mfg_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
#  MCMCglmm(EDcap~LnMass+flightletters+fac-1,random=~phylo,
#           data=eleDepPlotting,
#           ginverse=list(phylo=inverseA(PDprunEDm[[i]],
#                                        nodes="TIPS",scale=TRUE)$Ainv),
#           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
#           nitt=450000,burnin=45000,thin=39)})
#print("EDm_mfg_Mods done");Sys.time()
EDm_m_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(EDcap~LnMass+fac-1,random=~phylo,
           data=eleDepPlotting,
           ginverse=list(phylo=inverseA(PDprunEDm[[i]],
                                        nodes="TIPS",scale=TRUE)$Ainv),
           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
           nitt=15000,burnin=1500,thin=13)})
print("EDm_m_Mods done");Sys.time()
#EDm_fg_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
#  MCMCglmm(EDcap~flightletters+fac-1,random=~phylo,
#           data=eleDepPlotting,
#           ginverse=list(phylo=inverseA(PDprunEDm[[i]],
#                                        nodes="TIPS",scale=TRUE)$Ainv),
#           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
#           nitt=450000,burnin=45000,thin=39)})
#print("m03 done");Sys.time()
EDm_null_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(EDcap~fac-1,random=~phylo,
           data=eleDepPlotting,
           ginverse=list(phylo=inverseA(PDprunEDm[[i]],
                                        nodes="TIPS",scale=TRUE)$Ainv),
           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
           nitt=15000,burnin=1500,thin=13)})
print("m01 done");Sys.time()
stopCluster(cl)
Sys.time()

#combine results
EDm_mfg_VCV<-do.call(mcmc.list,lapply(EDm_m_Mods,function(m) m$VCV[,2]))
EDm_m_VCV<-do.call(mcmc.list,lapply(EDm_m_Mods,function(m) m$VCV[,2]))
EDm_null_VCV<-do.call(mcmc.list,lapply(EDm_null_Mods,function(m) m$VCV[,2]))

# Cohen's F2, computed via residual variance
EDm_v_null_mods<-lapply(EDm_null_VCV,mean)
EDm_v_all_mods<-lapply(EDm_m_VCV,mean)
EDm_v_nomass_mods<-lapply(EDm_null_VCV,mean)

#via means
EDm_f2_mass<-NULL
for (i in 1:length(EDm_v_all_mods)){
  EDm_f2_mass[[i]]<-mean((((EDm_v_null_mods[[i]]-EDm_v_all_mods[[i]])/EDm_v_null_mods[[i]])-((EDm_v_null_mods[[i]]-EDm_v_nomass_mods[[i]])/EDm_v_null_mods[[i]]))/(1-(EDm_v_null_mods[[i]]-EDm_v_all_mods[[i]])/EDm_v_null_mods[[i]]))
}

EDm_f2s<-data.frame(mass=EDm_f2_mass)
quantile(EDm_f2s$mass,c(0.05,0.5,0.95))


EDm_f2s_plot<-ggplot(EDm_f2s) + 
  geom_density(aes(x=EDm_f2_mass,y=..density..,fill='EDm_f2_mass'))+
  theme_ridges()
EDm_f2s_plot


#lambda
quantile(melt(EDm_m04_lambda_traces)[,1],c(0.05,0.5,0.95))
mean_hdi(melt(EDm_m04_lambda_traces)$value)
median_hdi(melt(EDm_m04_lambda_traces)$value)
mode_hdi(melt(EDm_m04_lambda_traces)$value)


#################### effect sizes for bending ROM FG MCMCs ######################
# first prune the pruned trees to ACDGs
drops2<-name.check(timetree,eleDepModeling,
                   data.names=eleDepModeling$phylo)
PDprunEDm<-lapply(PDpruned,drop.tip,drops2$tree_not_data)


library(parallel)
Sys.time()
prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))
setCores<-round(detectCores()*0.66) #use 66% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
parallel::clusterExport(cl,"eleDepPlotting_ACDG")
parallel::clusterExport(cl,"prior")
parallel::clusterExport(cl,"PDprunEDm")
NREPS<-length(PDprunEDm)
EDf_mfg_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(EDcap~LnMass+flightletters+fac-1,random=~phylo,
           data=eleDepPlotting_ACDG,
           ginverse=list(phylo=inverseA(PDprunEDm[[i]],
                                        nodes="TIPS",scale=TRUE)$Ainv),
           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
           nitt=15000,burnin=1500,thin=13)})
print("EDf_mfg_Mods done");Sys.time()
EDf_m_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(EDcap~LnMass+fac-1,random=~phylo,
           data=eleDepPlotting_ACDG,
           ginverse=list(phylo=inverseA(PDprunEDm[[i]],
                                        nodes="TIPS",scale=TRUE)$Ainv),
           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
           nitt=15000,burnin=1500,thin=13)})
print("EDf_m_Mods done");Sys.time()
EDf_fg_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(EDcap~flightletters+fac-1,random=~phylo,
           data=eleDepPlotting_ACDG,
           ginverse=list(phylo=inverseA(PDprunEDm[[i]],
                                        nodes="TIPS",scale=TRUE)$Ainv),
           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
           nitt=15000,burnin=1500,thin=13)})
print("m03 done");Sys.time()
EDf_null_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(EDcap~fac-1,random=~phylo,
           data=eleDepPlotting_ACDG,
           ginverse=list(phylo=inverseA(PDprunEDm[[i]],
                                        nodes="TIPS",scale=TRUE)$Ainv),
           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
           nitt=15000,burnin=1500,thin=13)})
print("m01 done");Sys.time()
stopCluster(cl)
Sys.time()

#combine results
EDf_mfg_VCV<-do.call(mcmc.list,lapply(EDf_mfg_Mods,function(m) m$VCV[,2]))
EDf_m_VCV<-do.call(mcmc.list,lapply(EDf_fg_Mods,function(m) m$VCV[,2]))
EDf_fg_VCV<-do.call(mcmc.list,lapply(EDf_m_Mods,function(m) m$VCV[,2]))
EDf_null_VCV<-do.call(mcmc.list,lapply(EDf_null_Mods,function(m) m$VCV[,2]))

# Cohen's F2, computed via residual variance
EDf_v_null_mods<-lapply(EDf_null_VCV,mean)
EDf_v_all_mods<-lapply(EDf_mfg_VCV,mean)
EDf_v_nofg_mods<-lapply(EDf_m_VCV,mean)
EDf_v_nomass_mods<-lapply(EDf_fg_VCV,mean)

#via means
EDf_f2_fg<-NULL
EDf_f2_ms<-NULL
for (i in 1:length(EDf_v_all_mods)){
  EDf_f2_fg[[i]]<-mean((((EDf_v_null_mods[[i]]-EDf_v_all_mods[[i]])/EDf_v_null_mods[[i]])-((EDf_v_null_mods[[i]]-EDf_v_nomass_mods[[i]])/EDf_v_null_mods[[i]]))/(1-(EDf_v_null_mods[[i]]-EDf_v_all_mods[[i]])/EDf_v_null_mods[[i]]))
  EDf_f2_ms[[i]]<-mean((((EDf_v_null_mods[[i]]-EDf_v_all_mods[[i]])/EDf_v_null_mods[[i]])-((EDf_v_null_mods[[i]]-EDf_v_nofg_mods[[i]])/EDf_v_null_mods[[i]]))/(1-(EDf_v_null_mods[[i]]-EDf_v_all_mods[[i]])/EDf_v_null_mods[[i]]))
  }

EDf_f2s<-data.frame(mass=EDf_f2_ms,
                    flightgroup=EDf_f2_fg)
quantile(EDf_f2s$flightgroup,c(0.05,0.5,0.95))


EDf_f2s_plot<-ggplot(EDf_f2s) + 
  geom_density(aes(x=flightgroup,y=..density..,fill='EDf_f2_mass'))+
  geom_density(aes(x=mass,y=..density..,fill='EDf_f2_fg'))+
  theme_ridges()
EDf_f2s_plot


#lambda
quantile(melt(EDf_m04_lambda_traces)[,1],c(0.025,0.5,0.975))
mean_hdi(melt(EDf_m04_lambda_traces)$value)
median_hdi(melt(EDf_m04_lambda_traces)$value)
mode_hdi(melt(EDf_m04_lambda_traces)$value)


########################### TWISTING: data sourcing ############################
#source individual species analyses
#all of these files will have "6bar-frames" in the title
pspath<-"./data_import_scripts/Bend_twist/"
pslist<-list.files(path=pspath,pattern="*_proSup.R",
                   full.names=TRUE,recursive=TRUE)
for(i in 1:length(pslist)){
  source(pslist[i])
}
############################## organize proSup #################################
proSupList<-ls(pattern='rangepronsup')
proSupList.list<-rbind(mget(proSupList))
names(proSupList.list)<-proSupList

ldply(proSupList.list)->proSupMat

p<-ggplot(proSupMat,aes(elbowAngle,manusAngle))
p+geom_point(size=4,aes(colour=prosupCapability)) +
  coord_fixed(ratio=1/1) +
  coord_cartesian(xlim=c(0,200),ylim=c(0,200)) +
  scale_color_viridis(discrete=FALSE,option="A") +
  facet_wrap(~id,ncol=5)+
  theme_bw()

maxPScaps<-ddply(proSupMat,~id,summarise,
                 maxPScap=max(prosupCapability),
                 maxSupn=abs(min(maxsupination)),
                 maxPron=max(maxpronation))
colnames(maxPScaps)<-c("phylo","PScap","Supn","Pron")
maxPScaps->PS.tableA
PS.tableA$fac<-"Maximum value"
PS.tableA<-left_join(PS.tableA,staticdat[,2:12],by="phylo")
PS.tableA<-left_join(PS.tableA,fl,by="phylo")

obo<-list()
proSupStatFrames<-NULL
for (i in 1:length(proSupList.list)){
  obo[[i]]<-matrix(nrow=dim(proSupList.list[[i]])[1])
}
for (i in 1:length(proSupList.list)){
  for (j in 1:dim(proSupList.list[[i]])[1]){
    obo[[i]][j,]<-sum(proSupList.list[[i]][j,1],proSupList.list[[i]][j,2])
  }
  proSupStatFrames<-c(proSupStatFrames,which.max(obo[[i]]))
}
odp<-list()
for (i in 1:length(proSupList.list)){
  odp[[i]]<-proSupList.list[[i]][proSupStatFrames[i],]
}
ldply(odp)->statPS
colnames(statPS)<-c("maxElbow","maxManus","statSupn","statPron","statPScap","phylo")
statPS$statSupn<-abs(statPS$statSupn);statPS->PS.tableB;
PS.tableB$fac<-"Value at full wing extension"
colnames(PS.tableB)<-c("maxElbow","maxManus","Supn","Pron","PScap","phylo","fac")
PS.tableB<-dplyr::select(PS.tableB,c("phylo","PScap","Supn","Pron","fac"))
PS.tableB<-left_join(PS.tableB,staticdat[,2:12],by="phylo")
PS.tableB<-left_join(PS.tableB,fl,by="phylo")

proSupSummary<-left_join(maxPScaps,statPS,by='phylo')
proSupSummary<-left_join(proSupSummary,fl,by="phylo")
proSupPlotting<-rbind(PS.tableA,PS.tableB)
proSupModeling<-proSupSummary
proSupModeling$statPScap - proSupModeling$PScap->proSupModeling$diffs
proSupModeling<-left_join(proSupModeling,staticdat[,2:12],by="phylo")

proSupPlotting_ACDG<-dplyr::filter(proSupPlotting,flightletters=='c'|
                                     flightletters=='g'|
                                     flightletters=='a'|
                                     flightletters=='d')

proSupModeling_ACDG<-dplyr::filter(proSupModeling,flightletters=='c'|
                                     flightletters=='g'|
                                     flightletters=='a'|
                                     flightletters=='d')


###############################  proSup MCMC  ##################################
OOPtrimmed<-comparative.data(timetree,PS.tableB,names.col='phylo')
ladderize(OOPtrimmed$phy)->oopTree
inv.phylo<-inverseA(oopTree,nodes="TIPS",scale=TRUE)
prior<-list(G=list(G1=list(V=1,nu=0.2)),R=list(V=1,nu=0.2))


PScap_mcmc<-MCMCglmm(PScap~fac+LnMass-1,random=~phylo,
                     data=proSupPlotting,ginverse=list(phylo=inv.phylo$Ainv),
                     verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
                     nitt=15000,burnin=1500,thin=13,
                     saveX=TRUE,saveZ=TRUE,saveXL=TRUE)
summary(PScap_mcmc)
plot.estimatesMCMC(PScap_mcmc$Sol)
plot(PScap_mcmc)
PScap_mcmc_lambda<-(PScap_mcmc$VCV[,1])/(PScap_mcmc$VCV[,1]+PScap_mcmc$VCV[,2])
plot(PScap_mcmc_lambda);mean(PScap_mcmc_lambda);HPDinterval(PScap_mcmc_lambda)

OOPtrimmed_ACDG<-comparative.data(timetree,proSupModeling_ACDG,names.col='phylo')
ladderize(OOPtrimmed_ACDG$phy)->oopTree_ACDG
inv.phylo<-inverseA(oopTree_ACDG,nodes="TIPS",scale=TRUE)
prior<-list(G=list(G1=list(V=1,nu=0.2)),R=list(V=1,nu=0.2))

PScapACDG_mcmc<-MCMCglmm(PScap~LnMass+flightletters+fac-1,random=~phylo,
                         data=proSupPlotting_ACDG,ginverse=list(phylo=inv.phylo$Ainv),
                         verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
                         nitt=15000,burnin=1500,thin=13,
                         saveX=TRUE,saveZ=TRUE,saveXL=TRUE)
summary(PScapACDG_mcmc)
plot.estimatesMCMC(PScapACDG_mcmc$Sol)
plot(PScapACDG_mcmc)
PScapACDG_mcmc_lambda<-(PScapACDG_mcmc$VCV[,1])/(PScapACDG_mcmc$VCV[,1]+PScapACDG_mcmc$VCV[,2])
plot(PScapACDG_mcmc_lambda);mean(PScapACDG_mcmc_lambda)

PScapACDG_mcmc->m_glmm
get_variables(m_glmm)

m_glmm %>% emmeans( ~ flightletters, data = proSupPlotting_ACDG) %>%
  emmeans::contrast(adjust='none',method='eff') %>%
  gather_emmeans_draws() %>%
  ggplot(aes(x = .value, y = contrast)) +
  geom_halfeyeh(.width=0.95) +
  geom_vline(xintercept=0) + theme_ridges()

m_glmm %>% emmeans( ~ flightletters, data = proSupPlotting_ACDG) %>%
  emmeans::contrast(adjust='none',method='pairwise') %>%
  gather_emmeans_draws() %>%
  ggplot(aes(x = .value, y = contrast)) +
  geom_halfeyeh(.width=0.95) +
  geom_vline(xintercept=0) + theme_ridges()

PSallChains<-as.mcmc(cbind(PScapACDG_mcmc$Sol,PScapACDG_mcmc$VCV))
#plotTrace(PSallChains,axes=TRUE,las=1)
# Least square means. Note you must specify the data
model0PS.rg<-ref.grid(PScapACDG_mcmc,data=proSupPlotting_ACDG)
flightPS.lsm<-lsmeans(model0PS.rg,"flightletters")
contrast(flightPS.lsm,adjust='none',method='eff')
contrast(flightPS.lsm,adjust='none',method='pairwise')
test(flightPS.lsm)
cld(flightPS.lsm,alpha=0.05,adjust='none')
plot(contrast(flightPS.lsm,adjust='none'))
plot(flightPS.lsm,comparisons=TRUE,alpha=0.05)


p<-ggplot(data=proSupPlotting_ACDG, aes(x=fac, y=PScap, group=phylo)) 
p+geom_line(aes(colour=flightletters, group=phylo),size=2) +    
  geom_point(aes(colour=flightletters, group=phylo),size=3) +      
  scale_color_viridis(discrete=TRUE,direction=-1)+
  xlab("")+ ylim(0,160)+
  ylab("Twisting Capability") +
  ggtitle("") +   
  theme_bw()

PSallChains<-as.mcmc(cbind(EDcapACDG_mcmc$Sol,EDcapACDG_mcmc$VCV))
model0PS.rg<-ref.grid(EDcapACDG_mcmc,data=proSupPlotting_ACDG)
flightPS.lsm<-lsmeans(model0PS.rg,"flightletters",by="LnMass")
massPS.lsm<-lsmeans(model0PS.rg,"LnMass",by='flightletters')
lsmeans::contrast(flightPS.lsm,adjust='none',method='eff')
lsmeans::test(flightPS.lsm)
lsmeans::cld(flightPS.lsm,alpha=0.05,adjust='none')
plot(lsmeans::contrast(flightPS.lsm,adjust='none'))
plot(flightPS.lsm,comparisons=TRUE,alpha=0.05)


#################### Prosup cross-validation ######################

## define folds
vec<-1:21
set.seed(100)
samp<-sample(vec)
OOP_foldsList<-split(samp,ceiling(seq_along(samp)/3))
OOP_foldsListdupes<-lapply(OOP_foldsList, '+',21)
OOP_foldscomb<-NULL
for (i in 1:length(OOP_foldsList)){
  OOP_foldscomb[[i]]<-c(OOP_foldsList[[i]],OOP_foldsListdupes[[i]])
}

OOP_folds<-NULL
PScv_dats<-list()
PScv_tests<-list()
for (i in 1:(length(OOP_foldsList))){
  OOP_folds[[i]]<-proSupPlotting_ACDG[OOP_foldscomb[[i]],]
  PScv_tests[[i]]<-proSupPlotting_ACDG[proSupPlotting_ACDG$phylo %in% OOP_folds[[i]]$phylo,]
  PScv_dats[[i]]<-proSupPlotting_ACDG[!proSupPlotting_ACDG$phylo %in% OOP_folds[[i]]$phylo,]
}

library(parallel)
Sys.time()
oopTree_ACDG->inTree
inv.phylo<-inverseA(inTree,nodes="TIPS",scale=TRUE)
prior<-list(G=list(G1=list(V=1,nu=0.002)),R=list(V=1,nu=0.002))
setCores<-round(detectCores()*0.66) #use 75% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
parallel::clusterExport(cl,"PScv_dats")
parallel::clusterExport(cl,"PScv_tests")
parallel::clusterExport(cl,"inv.phylo")
parallel::clusterExport(cl,"prior")

NREPS<-length(PScv_dats)
PScv_m04_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(PScap~LnMass+flightletters+fac-1,
           random=~phylo,scale=TRUE,data=PScv_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m04 done");Sys.time()
PScv_m02_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(PScap~flightletters+fac-1,
           random=~phylo,scale=TRUE,data=PScv_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m02 done");Sys.time()
PScv_m03_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(PScap~LnMass+fac-1,
           random=~phylo,scale=TRUE,data=PScv_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m03 done");Sys.time()
PScv_m01_mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(PScap~fac-1,
           random=~phylo,scale=TRUE,data=PScv_dats[[i]],
           ginverse=list(phylo=inv.phylo$Ainv),prior=prior,
           verbose=FALSE,pr=TRUE,
           nitt=15000,burnin=1500,thin=13)})
print("m01 done");Sys.time()
stopCluster(cl)
Sys.time()

#collect relevant metrics
#lambdas first, only for PC1 for simplicity
print("collecting PC1 lambda traces");Sys.time()
PScv_m04_lambda_traces<-lapply(1:length(PScv_m04_mods),
                               function(i){(PScv_m04_mods[[i]]$VCV[,1])/(
                                 PScv_m04_mods[[i]]$VCV[,1]+PScv_m04_mods[[i]]$VCV[,2])})
PScv_m02_lambda_traces<-lapply(1:length(PScv_m02_mods),
                               function(i){(PScv_m02_mods[[i]]$VCV[,1])/(
                                 PScv_m02_mods[[i]]$VCV[,1]+PScv_m02_mods[[i]]$VCV[,2])})
PScv_m03_lambda_traces<-lapply(1:length(PScv_m03_mods),
                               function(i){(PScv_m03_mods[[i]]$VCV[,1])/(
                                 PScv_m03_mods[[i]]$VCV[,1]+PScv_m03_mods[[i]]$VCV[,2])})
PScv_m01_lambda_traces<-lapply(1:length(PScv_m01_mods),
                               function(i){(PScv_m01_mods[[i]]$VCV[,1])/(
                                 PScv_m01_mods[[i]]$VCV[,1]+PScv_m01_mods[[i]]$VCV[,2])})


#"fits" = predictions of model for training data (i.e. data that were used to
# generate the model)
print("generating model fits");Sys.time()
PScv_m04_fits<-lapply(PScv_m04_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                      verbose=TRUE)
PScv_m02_fits<-lapply(PScv_m02_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                      verbose=TRUE)
PScv_m03_fits<-lapply(PScv_m03_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                      verbose=TRUE)
PScv_m01_fits<-lapply(PScv_m01_mods,predict.MCMCglmm,marginal=NULL,posterior="all",
                      verbose=TRUE)


#"preds" = predictions on test data (data that were held out)
print("generating model predictions on test data");Sys.time()
PScv_m04_preds<-lapply(1:length(PScv_m04_mods),
                       function(i){
                         predict(PScv_m04_mods[[i]],newdata=PScv_tests[[i]],
                                 marginal=NULL,posterior="all",verbose=TRUE)})
PScv_m02_preds<-lapply(1:length(PScv_m02_mods),
                       function(i){
                         predict(PScv_m02_mods[[i]],newdata=PScv_tests[[i]],
                                 marginal=NULL,posterior="all",verbose=TRUE)})
PScv_m03_preds<-lapply(1:length(PScv_m03_mods),
                       function(i){
                         predict(PScv_m03_mods[[i]],newdata=PScv_tests[[i]],
                                 marginal=NULL,posterior="all",verbose=TRUE)})
PScv_m01_preds<-lapply(1:length(PScv_m01_mods),
                       function(i){
                         predict(PScv_m01_mods[[i]],newdata=PScv_tests[[i]],
                                 marginal=NULL,posterior="all",verbose=TRUE)})


#set up a new cluster for linear model fitting and MSEs
setCores<-round(detectCores()*0.75) #use 75% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
parallel::clusterExport(cl,"PScv_dats")
parallel::clusterExport(cl,"PScv_tests")
print("re-importing fits and preds");Sys.time()
parallel::clusterExport(cl,"PScv_m04_fits")
parallel::clusterExport(cl,"PScv_m02_fits")
parallel::clusterExport(cl,"PScv_m03_fits")
parallel::clusterExport(cl,"PScv_m01_fits")
parallel::clusterExport(cl,"PScv_m04_preds")
parallel::clusterExport(cl,"PScv_m02_preds")
parallel::clusterExport(cl,"PScv_m03_preds")
parallel::clusterExport(cl,"PScv_m01_preds")

#"fitsLMs" = fit lm()s to fits~training data
print("generating LMs of fits ~ training data");Sys.time()
PScv_m04_fitsLMs<-parallel::parLapply(cl=cl,1:length(PScv_m04_fits),
                                      function(i){
                                        lm(PScv_m04_fits[[i]]~(PScv_dats[[i]]$PScap))
                                      })
PScv_m02_fitsLMs<-parallel::parLapply(cl=cl,1:length(PScv_m02_fits),
                                      function(i){
                                        lm(PScv_m02_fits[[i]]~(PScv_dats[[i]]$PScap))
                                      })
PScv_m03_fitsLMs<-parallel::parLapply(cl=cl,1:length(PScv_m03_fits),
                                      function(i){
                                        lm(PScv_m03_fits[[i]]~(PScv_dats[[i]]$PScap))
                                      })
PScv_m01_fitsLMs<-parallel::parLapply(cl=cl,1:length(PScv_m01_fits),
                                      function(i){
                                        lm(PScv_m01_fits[[i]]~(PScv_dats[[i]]$PScap))
                                      })


#"predsLMs" = fit lm()s to preds~training data
print("generating LMs of preds ~ training data");Sys.time()
PScv_m04_predsLMs<-parallel::parLapply(cl=cl,1:length(PScv_m04_preds),
                                       function(i){
                                         lm(PScv_m04_preds[[i]]~(PScv_tests[[i]]$PScap))
                                       })
PScv_m02_predsLMs<-parallel::parLapply(cl=cl,1:length(PScv_m02_preds),
                                       function(i){
                                         lm(PScv_m02_preds[[i]]~(PScv_tests[[i]]$PScap))
                                       })
PScv_m03_predsLMs<-parallel::parLapply(cl=cl,1:length(PScv_m03_preds),
                                       function(i){
                                         lm(PScv_m03_preds[[i]]~(PScv_tests[[i]]$PScap))
                                       })
PScv_m01_predsLMs<-parallel::parLapply(cl=cl,1:length(PScv_m01_preds),
                                       function(i){
                                         lm(PScv_m01_preds[[i]]~(PScv_tests[[i]]$PScap))
                                       })


#'fitsMSEs' and 'predMSEs' = mean squared error from each regression
print("computing mean squared errors of fits");Sys.time()
PScv_m04_fitsMSEs<-parallel::parSapply(cl=cl,PScv_m04_fitsLMs,mse)
PScv_m02_fitsMSEs<-parallel::parSapply(cl=cl,PScv_m02_fitsLMs,mse)
PScv_m03_fitsMSEs<-parallel::parSapply(cl=cl,PScv_m03_fitsLMs,mse)
PScv_m01_fitsMSEs<-parallel::parSapply(cl=cl,PScv_m01_fitsLMs,mse)

print("computing mean squared errors of predictions");Sys.time()
PScv_m04_predsMSEs<-parallel::parSapply(cl=cl,PScv_m04_predsLMs,mse)
PScv_m02_predsMSEs<-parallel::parSapply(cl=cl,PScv_m02_predsLMs,mse)
PScv_m03_predsMSEs<-parallel::parSapply(cl=cl,PScv_m03_predsLMs,mse)
PScv_m01_predsMSEs<-parallel::parSapply(cl=cl,PScv_m01_predsLMs,mse)

stopCluster(cl)
Sys.time()


#collect and re-format MSEs for plotting
PScv_m04_fitsMSEs_df<-PScv_m04_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
PScv_m02_fitsMSEs_df<-PScv_m02_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
PScv_m03_fitsMSEs_df<-PScv_m03_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
PScv_m01_fitsMSEs_df<-PScv_m01_fitsMSEs %>% 
  data.frame() %>% `colnames<-`('fitsMSEs')
PScv_m04_fitsMSEs_df$df<-12
PScv_m02_fitsMSEs_df$df<-11
PScv_m03_fitsMSEs_df$df<-3
PScv_m01_fitsMSEs_df$df<-1
PScv_m04_predsMSEs_df<-PScv_m04_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
PScv_m02_predsMSEs_df<-PScv_m02_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
PScv_m03_predsMSEs_df<-PScv_m03_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
PScv_m01_predsMSEs_df<-PScv_m01_predsMSEs %>% 
  data.frame() %>% `colnames<-`('predsMSEs')
PScv_m04_predsMSEs_df$df<-12
PScv_m02_predsMSEs_df$df<-11
PScv_m03_predsMSEs_df$df<-3
PScv_m01_predsMSEs_df$df<-1

PScv_fitsMSEs<-rbind(PScv_m04_fitsMSEs_df,
                     PScv_m02_fitsMSEs_df,
                     PScv_m03_fitsMSEs_df,
                     PScv_m01_fitsMSEs_df)
PScv_predsMSEs<-rbind(PScv_m04_predsMSEs_df,
                      PScv_m02_predsMSEs_df,
                      PScv_m03_predsMSEs_df,
                      PScv_m01_predsMSEs_df)
PScv_combinedMSEs<-left_join(PScv_fitsMSEs,PScv_predsMSEs,by='df')


p <- ggplot(PScv_predsMSEs, aes(df, predsMSEs))
p + geom_point(aes(group=df),col='red',alpha=0.1,size=2) + 
  geom_point(data=PScv_fitsMSEs,aes(group=df,y=fitsMSEs),alpha=0.1,col='black',size=2)+
  stat_summary(aes(y=predsMSEs,group=1),fun.y=mean,colour="red",
               geom="point",group=1,size=4)+ 
  stat_summary(data=PScv_fitsMSEs,aes(y=fitsMSEs,group=1),fun.y=mean,
               colour="black",geom="point",group=1,size=4)+ 
  theme_bw()

aggregate(PScv_fitsMSEs$fitsMSEs,list(PScv_fitsMSEs$df),mean) 
aggregate(PScv_predsMSEs$predsMSEs,list(PScv_predsMSEs$df),mean)


mean(ldply(sapply(PScv_m04_mods,summary)[1,])$V1)
mean(ldply(lapply(PScv_m04_lambda_traces,mean))$V1)

PScv_m04_mods[[1]]->mmF;colnames(EDcv_m04_mods[[1]]$Sol)
mVarF <- var(as.vector(apply(mmF$Sol[,1:6],2,mean) %*% t(mmF$X)))
#mVarF <- var(as.vector(mean(mmF$Sol[,1]) %*% t(mmF$X)))
# MCMCglmm - marginal
mVarF/(mVarF+sum(apply(mmF$VCV,2,mean)))
# alternative with crebile intervals
vmVarF<-numeric(dim(mmF$VCV)[1])
for(i in 1:dim(mmF$VCV)[1]){
  Var<-var(as.vector(mmF$Sol[,1:6][i,] %*% t(mmF$X)))
  #Var<-var(as.vector(mmF$Sol[,1:1][i] %*% t(mmF$X)))
  vmVarF[i]<-Var}
R2m<-vmVarF/(vmVarF+mmF$VCV[,1]+mmF$VCV[,2])
mean(R2m)
posterior.mode(R2m)
HPDinterval(R2m)
# MCMCglmm - conditional
R2c<-as.mcmc((vmVarF+(mmF$VCV))/(vmVarF+rowSums(mmF$VCV)))
mean(R2c)
posterior.mode(R2c)
HPDinterval(R2c)


#################### effect sizes for twisting ROM MCMCs ######################
# effect sizes measured via cohen's f2
library(parallel)
Sys.time()
prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))
setCores<-round(detectCores()*0.66) #use 66% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
  cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
  parallel::clusterExport(cl,"proSupPlotting_ACDG")
  parallel::clusterExport(cl,"prior")
  parallel::clusterExport(cl,"PDpruned_ACDG")
  NREPS<-length(PDpruned_ACDG)
  PS_mfg_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(PScap~LnMass+flightletters+fac-1,random=~phylo,
             data=proSupPlotting_ACDG,
             ginverse=list(phylo=inverseA(PDpruned_ACDG[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
             nitt=15000,burnin=1500,thin=13)})
  print("ED_mfg_Mods done");Sys.time()
  PS_m_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(PScap~LnMass+fac-1,random=~phylo,
             data=proSupPlotting_ACDG,
             ginverse=list(phylo=inverseA(PDpruned_ACDG[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
             nitt=15000,burnin=1500,thin=13)})
  print("ED_m_Mods done");Sys.time()
  PS_fg_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(PScap~flightletters+fac-1,random=~phylo,
             data=proSupPlotting_ACDG,
             ginverse=list(phylo=inverseA(PDpruned_ACDG[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
             nitt=15000,burnin=1500,thin=13)})
  print("m03 done");Sys.time()
  PS_null_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
    MCMCglmm(PScap~fac-1,random=~phylo,
             data=proSupPlotting_ACDG,
             ginverse=list(phylo=inverseA(PDpruned_ACDG[[i]],
                                          nodes="TIPS",scale=TRUE)$Ainv),
             verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
             nitt=15000,burnin=1500,thin=13)})
  print("m01 done");Sys.time()
  stopCluster(cl)
Sys.time()

#combine results
PS_mfg_VCV<-do.call(mcmc.list,lapply(PS_mfg_Mods,function(m) m$VCV[,2]))
PS_m_VCV<-do.call(mcmc.list,lapply(PS_m_Mods,function(m) m$VCV[,2]))
PS_fg_VCV<-do.call(mcmc.list,lapply(PS_fg_Mods,function(m) m$VCV[,2]))
PS_null_VCV<-do.call(mcmc.list,lapply(PS_null_Mods,function(m) m$VCV[,2]))

# Cohen's F2, computed via residual variance
PS_v_null_mods<-lapply(PS_null_VCV,mean)
PS_v_all_mods<-lapply(PS_mfg_VCV,mean)
PS_v_nofg_mods<-lapply(PS_m_VCV,mean)
PS_v_nomass_mods<-lapply(PS_fg_VCV,mean)

#via means
PS_f2_fg<-NULL
PS_f2_mass<-NULL
for (i in 1:length(PS_v_all_mods)){
  PS_f2_fg[[i]]<-mean((((PS_v_null_mods[[i]]-PS_v_all_mods[[i]])/PS_v_null_mods[[i]])-((PS_v_null_mods[[i]]-PS_v_nofg_mods[[i]])/PS_v_null_mods[[i]]))/(1-(PS_v_null_mods[[i]]-PS_v_all_mods[[i]])/PS_v_null_mods[[i]]))
  PS_f2_mass[[i]]<-mean((((PS_v_null_mods[[i]]-PS_v_all_mods[[i]])/PS_v_null_mods[[i]])-((PS_v_null_mods[[i]]-PS_v_nomass_mods[[i]])/PS_v_null_mods[[i]]))/(1-(PS_v_null_mods[[i]]-PS_v_all_mods[[i]])/PS_v_null_mods[[i]]))
}


PS_f2s<-data.frame(flightBehavior=PS_f2_fg,
                   mass=PS_f2_mass)
quantile(PS_f2s$flightBehavior,c(0.05,0.5,0.95))
quantile(PS_f2s$mass,c(0.05,0.5,0.95))


PS_f2s_plot<-ggplot(PS_f2s) + 
  geom_density(aes(x=PS_f2_fg,y=..density..,fill='PS_f2_fg'))+
  geom_density(aes(x=PS_f2_mass,y=..density..,fill='PS_f2_mass'))+
  theme_ridges()
PS_f2s_plot

#lambda
quantile(melt(PS_m04_lambda_traces)[,1],c(0.025,0.5,0.975))
mean_hdi(melt(PS_m04_lambda_traces)$value)
median_hdi(melt(PS_m04_lambda_traces)$value)
mode_hdi(melt(PS_m04_lambda_traces)$value)


#################### effect sizes for twisting ROM MASS MCMCs ######################
# first prune the pruned trees to ACDGs
drops2<-name.check(timetree,proSupModeling,
                   data.names=proSupModeling$phylo)
PDprunPSm<-lapply(PDpruned,drop.tip,drops2$tree_not_data)


library(parallel)
Sys.time()
prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))
setCores<-round(detectCores()*0.66) #use 66% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
parallel::clusterExport(cl,"proSupPlotting")
parallel::clusterExport(cl,"prior")
parallel::clusterExport(cl,"PDprunPSm")
NREPS<-length(PDprunPSm)
#PSm_mfg_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
#  MCMCglmm(PScap~LnMass+flightletters+fac-1,random=~phylo,
#           data=proSupPlotting,
#           ginverse=list(phylo=inverseA(PDprunPSm[[i]],
#                                        nodes="TIPS",scale=TRUE)$Ainv),
#           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
#           nitt=450000,burnin=45000,thin=39)})
#print("PSm_mfg_Mods done");Sys.time()
PSm_m_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(PScap~LnMass+fac-1,random=~phylo,
           data=proSupPlotting,
           ginverse=list(phylo=inverseA(PDprunPSm[[i]],
                                        nodes="TIPS",scale=TRUE)$Ainv),
           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
           nitt=15000,burnin=1500,thin=13)})
print("PSm_m_Mods done");Sys.time()
#PSm_fg_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
#  MCMCglmm(PScap~flightletters+fac-1,random=~phylo,
#           data=proSupPlotting,
#           ginverse=list(phylo=inverseA(PDprunPSm[[i]],
#                                        nodes="TIPS",scale=TRUE)$Ainv),
#           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
#           nitt=450000,burnin=45000,thin=39)})
#print("m03 done");Sys.time()
PSm_null_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(PScap~fac-1,random=~phylo,
           data=proSupPlotting,
           ginverse=list(phylo=inverseA(PDprunPSm[[i]],
                                        nodes="TIPS",scale=TRUE)$Ainv),
           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
           nitt=15000,burnin=1500,thin=13)})
print("m01 done");Sys.time()
stopCluster(cl)
Sys.time()

#combine results
PSm_mfg_VCV<-do.call(mcmc.list,lapply(PSm_m_Mods,function(m) m$VCV[,2]))
PSm_m_VCV<-do.call(mcmc.list,lapply(PSm_m_Mods,function(m) m$VCV[,2]))
PSm_null_VCV<-do.call(mcmc.list,lapply(PSm_null_Mods,function(m) m$VCV[,2]))

# Cohen's F2, computed via residual variance
PSm_v_null_mods<-lapply(PSm_null_VCV,mean)
PSm_v_all_mods<-lapply(PSm_m_VCV,mean)
PSm_v_nomass_mods<-lapply(PSm_null_VCV,mean)

#via means
PSm_f2_mass<-NULL
for (i in 1:length(PSm_v_all_mods)){
  PSm_f2_mass[[i]]<-mean((((PSm_v_null_mods[[i]]-PSm_v_all_mods[[i]])/PSm_v_null_mods[[i]])-((PSm_v_null_mods[[i]]-PSm_v_nomass_mods[[i]])/PSm_v_null_mods[[i]]))/(1-(PSm_v_null_mods[[i]]-PSm_v_all_mods[[i]])/PSm_v_null_mods[[i]]))
}

PSm_f2s<-data.frame(mass=PSm_f2_mass)
quantile(PSm_f2s$mass,c(0.05,0.5,0.95))


PSm_f2s_plot<-ggplot(PSm_f2s) + 
  geom_density(aes(x=PSm_f2_mass,y=..density..,fill='PSm_f2_mass'))+
  theme_ridges()
PSm_f2s_plot


#lambda
quantile(melt(PSm_m04_lambda_traces)[,1],c(0.025,0.5,0.975))
mean_hdi(melt(PSm_m04_lambda_traces)$value)
median_hdi(melt(PSm_m04_lambda_traces)$value)
mode_hdi(melt(PSm_m04_lambda_traces)$value)


#################### effect sizes for twising ROM FG MCMCs ######################
# first prune the pruned trees to ACDGs
drops2<-name.check(timetree,eleDepModeling,
                   data.names=eleDepModeling$phylo)
PDprunEDm<-lapply(PDpruned,drop.tip,drops2$tree_not_data)


library(parallel)
Sys.time()
prior<-list(G=list(G1=list(V=1,nu=0.02)),R=list(V=1,nu=0.02))
setCores<-round(detectCores()*0.66) #use 66% of available logical processors
cl<-parallel::makeCluster(getOption("cl.cores",setCores))
cl.pkg<-parallel::clusterEvalQ(cl,library(MCMCglmm))
parallel::clusterExport(cl,"proSupPlotting_ACDG")
parallel::clusterExport(cl,"prior")
parallel::clusterExport(cl,"PDprunEDm")
NREPS<-length(PDprunEDm)
PSf_mfg_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(PScap~LnMass+flightletters+fac-1,random=~phylo,
           data=proSupPlotting_ACDG,
           ginverse=list(phylo=inverseA(PDprunEDm[[i]],
                                        nodes="TIPS",scale=TRUE)$Ainv),
           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
           nitt=15000,burnin=1500,thin=13)})
print("PSf_mfg_Mods done");Sys.time()
PSf_m_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(PScap~LnMass+fac-1,random=~phylo,
           data=proSupPlotting_ACDG,
           ginverse=list(phylo=inverseA(PDprunEDm[[i]],
                                        nodes="TIPS",scale=TRUE)$Ainv),
           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
           nitt=15000,burnin=1500,thin=13)})
print("PSf_m_Mods done");Sys.time()
PSf_fg_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(PScap~flightletters+fac-1,random=~phylo,
           data=proSupPlotting_ACDG,
           ginverse=list(phylo=inverseA(PDprunEDm[[i]],
                                        nodes="TIPS",scale=TRUE)$Ainv),
           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
           nitt=15000,burnin=1500,thin=13)})
print("m03 done");Sys.time()
PSf_null_Mods<-parallel::parLapply(cl=cl,1:NREPS,function(i){
  MCMCglmm(PScap~fac-1,random=~phylo,
           data=proSupPlotting_ACDG,
           ginverse=list(phylo=inverseA(PDprunEDm[[i]],
                                        nodes="TIPS",scale=TRUE)$Ainv),
           verbose=FALSE,pr=TRUE,pl=TRUE,prior=prior,
           nitt=15000,burnin=1500,thin=13)})
print("m01 done");Sys.time()
stopCluster(cl)
Sys.time()

#combine results
PSf_mfg_VCV<-do.call(mcmc.list,lapply(PSf_mfg_Mods,function(m) m$VCV[,2]))
PSf_m_VCV<-do.call(mcmc.list,lapply(PSf_fg_Mods,function(m) m$VCV[,2]))
PSf_fg_VCV<-do.call(mcmc.list,lapply(PSf_m_Mods,function(m) m$VCV[,2]))
PSf_null_VCV<-do.call(mcmc.list,lapply(PSf_null_Mods,function(m) m$VCV[,2]))

# Cohen's F2, computed via residual variance
PSf_v_null_mods<-lapply(PSf_null_VCV,mean)
PSf_v_all_mods<-lapply(PSf_mfg_VCV,mean)
PSf_v_nofg_mods<-lapply(PSf_m_VCV,mean)
PSf_v_nomass_mods<-lapply(PSf_fg_VCV,mean)

PSf_f2_fg<-NULL
PSf_f2_ms<-NULL
for (i in 1:length(PSf_v_all_mods)){
  PSf_f2_fg[[i]]<-mean((((PSf_v_null_mods[[i]]-PSf_v_all_mods[[i]])/PSf_v_null_mods[[i]])-((PSf_v_null_mods[[i]]-PSf_v_nomass_mods[[i]])/PSf_v_null_mods[[i]]))/(1-(PSf_v_null_mods[[i]]-PSf_v_all_mods[[i]])/PSf_v_null_mods[[i]]))
  PSf_f2_ms[[i]]<-mean((((PSf_v_null_mods[[i]]-PSf_v_all_mods[[i]])/PSf_v_null_mods[[i]])-((PSf_v_null_mods[[i]]-PSf_v_nofg_mods[[i]])/PSf_v_null_mods[[i]]))/(1-(PSf_v_null_mods[[i]]-PSf_v_all_mods[[i]])/PSf_v_null_mods[[i]]))
}

PSf_f2s<-data.frame(mass=PSf_f2_ms,
                    flightgroup=PSf_f2_fg)
quantile(PSf_f2s$flightgroup,c(0.05,0.5,0.95))


PSf_f2s_plot<-ggplot(PSf_f2s) + 
  geom_density(aes(x=flightgroup,y=..density..,fill='PSf_f2_mass'))+
  geom_density(aes(x=mass,y=..density..,fill='PSf_f2_fg'))+
  theme_ridges()
PSf_f2s_plot


#lambda
quantile(melt(PSf_m04_lambda_traces)[,1],c(0.025,0.5,0.975))
mean_hdi(melt(PSf_m04_lambda_traces)$value)
median_hdi(melt(PSf_m04_lambda_traces)$value)
mode_hdi(melt(PSf_m04_lambda_traces)$value)

