#Please note that this script relies on analyses run in scripts 01 through 06.

#Figures that are generated here were futher edited in Adobe 
#Illustrator for the manuscript, but the core components are in this script.

#keep in mind that many analsyes rely on MCMC, so exact shapes of distributions
#may vary. But the important aspects (mean/median estimates, HPD intervals..etc)
#should be consistent


############################### color schemes ##################################
cols.fg<-colorFactor(c("#343433","#F9A31A","#0BB6EA","#069F77","#F4E539",
                       "#989897","#F16622","#E07CAA","#0077B7"),
                     domain=flightgroup)
flightptls<-setNames(c("#343433","#F9A31A","#0BB6EA","#069F77","#F4E539",
                       "#989897","#F16622","#E07CAA","#0077B7"),
                     c("a","b","c","d","e","f","g","h","i"))


############################# define phylo order ###############################
#vector to re-order taxa based on top-to-bottom order in a ladderized tree
is_tip<-timetree$edge[,2] <= length(timetree$tip.label)
phyAlph<-as.factor(rev(timetree$edge[is_tip, 2]))
#check: timetree$tip.label[phyAlph]
data.frame(phyAlph)->phyOrder
phyOrder$ladder<-seq(1:61)
phyOrder<-phyOrder[order(phyAlph),] 
#ladder = ladderized order, as a data.frame
as.factor(phyOrder$ladder)->ladder
data.frame(ladder)->ladderDF

currentorder<-c(1:61)
reorder<-c(1:5,42,6:8,10,9,11:13,15,14,16:35,37:41,43,44,46,36,47,45,48:61)
configAlpha<-data.frame(currentorder,reorder)
#configAlpha<-configAlpha[order(reorder),]
configAlpha$reorder->phyAlpha

configSpace.proc$phyAlpha<-phyAlpha
staticshapes.proc$ladder<-ladder

########################### figure 1 components ################################
plot(timetree);axisPhylo(side=1,root.time=NULL,backward=TRUE)
dotTree(timetree,flightletters,colors=flightptls)

tmp1.config_proc<-configSpace.proc %>% arrange(phyAlpha)
tmp1.config_proc$ladder<-ladder
tmp.config_proc<-tmp1.config_proc %>% arrange(ladder)
tmp.config_eF<-efourier(tmp.config_proc,nb.h=5,verbose=TRUE,norm=FALSE)
#tmp.config_eF$ladderDF<-ladderDF
#config.arranged<-tmp.config_eF %>% arrange(ladder)
Momocs::panel(tmp.config_eF,names=TRUE,fac="as.character.flightgroup.",
      dim=c(16,4),col=flightptls)
#if need be you can use filter later to isolate species, i.e.:
#a<-filter(tmp.config_eF,as.character.flightgroup.=="1")

coo_rotate(staticshapes.proc,theta=-2)->tmp
tmp.eFourier<-efourier(tmp,nb.h=8,verbose=TRUE,norm=FALSE)
stat.arranged<-tmp.eFourier %>% arrange(ladder)
Momocs::panel(stat.arranged,names=TRUE,fac="as.character.flightalpha.",
      dim=c(16,4),col=flightptls)

tip.cols<-cols.fg(flightalpha)
names(tip.cols)<-timetree$tip.label
pmscols<-c(tip.cols[timetree$tip.label],rep("black",timetree$Nnode))
names(pmscols)<-1:(length(timetree$tip)+timetree$Nnode)
phylomorphospace(timetree,staticshapes.pPCA$S[,1:2],label="none",
                 node.size=c(0,1),control=list(col.node=pmscols))
phylomorphospace(timetree,configSpace.PCA$x[,1:2],label="none",
                 node.size=c(0,1),control=list(col.node=pmscols))

#for panel F:
plot(((statdatdat$PC1-mean(statdatdat$PC1))/sd(statdatdat$PC1)),((statdatdat$LnMass-mean(statdatdat$LnMass))/sd(statdatdat$LnMass)),pch=19,asp=1)
#repeat for newdat$PC1 and $LnMass



######Fig 2 LT and AR plots, cowplot style#####
#linkage trajectory first:
a <- ggplot(dat, aes(log(manusAngle),log(b2.s),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#343433') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='a')
b <- ggplot(dat, aes(log(manusAngle),log(b2.s),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#F9A31A') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='b')
c <- ggplot(dat, aes(log(manusAngle),log(b2.s),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#0BB6EA') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='c')
d <- ggplot(dat, aes(log(manusAngle),log(b2.s),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#069F77') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='d')
e <- ggplot(dat, aes(log(manusAngle),log(b2.s),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#F4E539') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='e')
f <- ggplot(dat, aes(log(manusAngle),log(b2.s),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#989897') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='f')
g <- ggplot(dat, aes(log(manusAngle),log(b2.s),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#F16622') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='g')
h <- ggplot(dat, aes(log(manusAngle),log(b2.s),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#E07CAA') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='h')
i <- ggplot(dat, aes(log(manusAngle),log(b2.s),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#0077B7') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='i')

plot_grid(g,f,h,b,e,c,d,i,a,ncol=3)

#aspect ratio
a <- ggplot(dat, aes(log(elbowAngle),log(manusAngle),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#343433') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='a')
b <- ggplot(dat, aes(log(elbowAngle),log(manusAngle),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#F9A31A') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='b')
c <- ggplot(dat, aes(log(elbowAngle),log(manusAngle),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#0BB6EA') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='c')
d <- ggplot(dat, aes(log(elbowAngle),log(manusAngle),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#069F77') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='d')
e <- ggplot(dat, aes(log(elbowAngle),log(manusAngle),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#F4E539') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='e')
f <- ggplot(dat, aes(log(elbowAngle),log(manusAngle),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#989897') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='f')
g <- ggplot(dat, aes(log(elbowAngle),log(manusAngle),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#F16622') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='g')
h <- ggplot(dat, aes(log(elbowAngle),log(manusAngle),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#E07CAA') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='h')
i <- ggplot(dat, aes(log(elbowAngle),log(manusAngle),group=phylo,color=flightgroup)) +
  geom_smooth(method='lm',se=FALSE,size=3,color='#0077B7') +
  coord_fixed(ratio=1/1) +theme_bw()+gghighlight(flightgroup=='i')

plot_grid(g,f,h,b,e,c,d,i,a,ncol=3)

#LT by mass
tilez<-quantile(newdat$LnMass,c(0,0.3333,0.66666,1))
massBinA<-newdat$phylo[newdat$LnMass<tilez[2]]
massBinB<-newdat$phylo[newdat$LnMass>tilez[2]&newdat$LnMass<tilez[3]]
massBinC<-newdat$phylo[newdat$LnMass>tilez[3]]
mbA<-data.frame(phylo=massBinA,MassBin="massBinA")
mbB<-data.frame(phylo=massBinB,MassBin="massBinB")
mbC<-data.frame(phylo=massBinC,MassBin="massBinC")
massBinz<-rbind(mbA,mbB,mbC)
dat->bat
batty<-left_join(bat,massBinz,by="phylo")

p <- ggplot(batty, aes(log(elbowAngle), log(manusAngle),group=phylo,colour=LnMass))
p + geom_line(stat="smooth",method = "lm",se=FALSE,size=3,aes(color=LnMass)) +
  coord_fixed(ratio=1/1) +
  scale_color_viridis(discrete=FALSE,direction=1,begin=1,end=0.666,guide=FALSE) +
  #scale_fill_gradientn(colors = viridis_pal()(20)) + 
  theme_bw()+
  gghighlight(MassBin=='massBinA')

p <- ggplot(batty, aes(log(elbowAngle), log(manusAngle),group=phylo,colour=LnMass))
p + geom_line(stat="smooth",method = "lm",se=FALSE,size=3,aes(color=LnMass)) +
  coord_fixed(ratio=1/1) +
  scale_color_viridis(discrete=FALSE,direction=1,begin=0.66666,end=0.3333,guide=FALSE) +
  #scale_fill_gradientn(colors = viridis_pal()(20)) + 
  theme_bw()+
  gghighlight(MassBin=='massBinB')

p <- ggplot(batty, aes(log(elbowAngle), log(manusAngle),group=phylo,colour=LnMass))
p + geom_line(stat="smooth",method = "lm",se=FALSE,size=3,aes(color=LnMass)) +
  coord_fixed(ratio=1/1) +
  scale_color_viridis(discrete=FALSE,direction=1,begin=0.33333,end=0,guide=FALSE) +
  #scale_fill_gradientn(colors = viridis_pal()(20)) + 
  theme_bw()+
  gghighlight(MassBin=='massBinC')

#AR too
p <- ggplot(batty, aes(log(manusAngle), log(b2.s),group=phylo,colour=LnMass))
p + geom_line(stat="smooth",method = "lm",se=FALSE,size=3,aes(color=LnMass)) +
  coord_fixed(ratio=1/1) +
  scale_color_viridis(discrete=FALSE,direction=1,begin=1,end=0.666,guide=FALSE) +
  #scale_fill_gradientn(colors = viridis_pal()(20)) + 
  theme_bw()+
  gghighlight(MassBin=='massBinA')

p <- ggplot(batty, aes(log(manusAngle), log(b2.s),group=phylo,colour=LnMass))
p + geom_line(stat="smooth",method = "lm",se=FALSE,size=3,aes(color=LnMass)) +
  coord_fixed(ratio=1/1) +
  scale_color_viridis(discrete=FALSE,direction=1,begin=0.66666,end=0.3333,guide=FALSE) +
  #scale_fill_gradientn(colors = viridis_pal()(20)) + 
  theme_bw()+
  gghighlight(MassBin=='massBinB')

p <- ggplot(batty, aes(log(manusAngle), log(b2.s),group=phylo,colour=LnMass))
p + geom_line(stat="smooth",method = "lm",se=FALSE,size=3,aes(color=LnMass)) +
  coord_fixed(ratio=1/1) +
  scale_color_viridis(discrete=FALSE,direction=1,begin=0.33333,end=0,guide=FALSE) +
  #scale_fill_gradientn(colors = viridis_pal()(20)) + 
  theme_bw()+
  gghighlight(MassBin=='massBinC')


######Fig 4: effect sizes #####
#objects:
#CS_f2s
#STAT_f2s
#LT_f2s
#ED_f2s
#PS_f2s

# what we want: one data.frame that has twocolumns:
# first column: treatment (CS_mass, CS_fg...etc)
# second column: f2

STAT_gather<-gather(STAT_f2s);STAT_gather$key<-c(rep("01_STAT_fg",nrow(STAT_gather)/2),rep("01_STAT_mass",nrow(STAT_gather)/2))
CS_gather<-gather(CS_f2s);CS_gather$key<-c(rep("02_CS_fg",nrow(CS_gather)/2),rep("02_CS_mass",nrow(CS_gather)/2))
LT_gather<-gather(LT_f2s);LT_gather$key<-c(rep("03_LT_fg",nrow(LT_gather)/2),rep("03_LT_mass",nrow(LT_gather)/2))
ED_gather<-gather(ED_f2s);ED_gather$key<-c(rep("04_ED_fg",nrow(ED_gather)/2),rep("04_ED_mass",nrow(ED_gather)/2))
PS_gather<-gather(PS_f2s);PS_gather$key<-c(rep("06_PS_fg",nrow(PS_gather)/2),rep("06_PS_mass",nrow(PS_gather)/2))


f2s_df<-rbind(STAT_gather,CS_gather,LT_gather,
              ED_gather,
              PS_gather
              )

ggplot(f2s_df, aes(x = value, y = key)) +
  geom_halfeyeh(.width=0.95,scale="width") +
  geom_vline(xintercept=0) + theme_ridges()

ggplot(f2s_df,aes(x=value,y=key))+ 
  geom_density_ridges2(aes(fill=key),alpha=0.85,
                       scale=0.85,rel_min_height=1E-10)+
  geom_vline(xintercept=0)+
  scale_fill_manual(values = c(rep("#6495ED",1),rep("#FC4E07",1),
                               rep("#6495ED",1),rep("#FC4E07",1),
                               rep("#6495ED",1),rep("#FC4E07",1),
                               rep("#6495ED",1),rep("#FC4E07",1),
                               rep("#6495ED",1),rep("#FC4E07",1))) +
  theme_ridges()


################### Fig 4: phylogentic signal & sensitivity ####################
#first collect univariate data
#these will be analyzed using Blomberg's K
staticmorph[,c(3:5)]->morphodat
log(staticmorph[,6:11])->logtmp
cbind(morphodat,logtmp,log(CSareas),log(LTlengths))->morphodat

physigSensiList<-NULL
for (i in 1:ncol(morphodat)){
  col_name<-colnames(morphodat)[i]
  physigSensiList[[i]]<-influ_physig(col_name,
                                     morphodat,stattree,
                                     method="K")$influ.physig.estimates
}
names(physigSensiList)<-colnames(morphodat)
ldply(physigSensiList)->physigSensiMat

#to get estimates for the table
quantile(physigSensiList$LnMass$estimate,c(0.05,0.5,0.95))

OOPcap<-data.frame(eleDepModeling$EDcap,
                   proSupSummary$PScap)
rownames(OOPcap)<-eleDepModeling$phylo

physigSensiList_OOP<-NULL
for (i in 1:ncol(OOPcap)){
  col_name<-colnames(OOPcap)[i]
  physigSensiList_OOP[[i]]<-influ_physig(col_name,
                                         OOPcap,oopTree,
                                         method="K")$influ.physig.estimates
}
names(physigSensiList_OOP)<-colnames(OOPcap)
ldply(physigSensiList_OOP)->physigSensiMat_OOP

rbind(physigSensiMat,physigSensiMat_OOP)->physigSensiMat_univ

physigSensiMat_univ %>%mutate(var = fct_reorder(.id, estimate, fun=median)) -> g
ggplot(g,aes(x=estimate,y=var))+ geom_point()+coord_cartesian(xlim=c(0,1.5))+theme_ridges()

ggplot(g, aes(x = estimate, y = var))+ 
  geom_density_ridges2(aes(fill = .id),alpha=0.85,scale=0.85,rel_min_height=1E-10)+
  coord_cartesian(xlim=c(0,1.5)) +
  geom_vline(xintercept=1)+
  theme_ridges()


#next collect multivariate data
#these will be analyzed using the multivariate generalization of Blomberg's K
#first, collect data
configSpace.eFourier$coe->obj;rownames(obj)<-rownames(cS.PCA.scores)
arg<-efourier(staticshapes.proc,nb.h=6,verbose=TRUE,norm=FALSE);arg$coe->dobj
rownames(dobj)<-rownames(staticmorph)
as.data.frame(obj)->obdf
as.data.frame(dobj)->dobdf

a<-influ_physig_kmult(obdf,timetree)
b<-influ_physig_kmult(dobdf,timetree)
c<-influ_physig_kmult(flightmat_binaryDF,timetree)
list(a$influ.physig.estimates,
     b$influ.physig.estimates,
     c$influ.physig.estimates)->d
names(d)<-c("eROM shape","Wing shape","Flight behavior")

ldply(d)->physigSensiMat_mult
physigSensiMat_mult %>%mutate(var = fct_reorder(.id, estimate, fun=median)) -> m

ggplot(m, aes(x = estimate, y = var))+ 
  geom_density_ridges2(aes(fill = .id),alpha=0.85,scale=0.5,rel_min_height=1E-10)+ 
  coord_cartesian(xlim=c(0,1.5)) +
  geom_vline(xintercept=1)+
  scale_fill_manual(values = c("#00AFBB", "#E7B800", "#FC4E07"))+
  theme_ridges()


#all together (only if using K)
rbind(g,m)->k
k %>%mutate(var = fct_reorder(.id, estimate, fun=median)) -> all_k
ggplot(all_k,aes(x=estimate,y=var)) + 
  geom_density_ridges2(aes(fill=.id),alpha=0.85,scale=1,
                       size=0.7,rel_min_height=1E-5) + 
  coord_cartesian(xlim=c(summary(all_k$estimate)[1],
                         summary(all_k$estimate)[6])) +
  geom_vline(xintercept=1) +
  scale_fill_manual(values = c(rep("#6495ED",1),rep("#FC4E07",2),
                               rep("#6495ED",3),rep("#FC4E07",2),
                               rep("#6495ED",1),rep("#FC4E07",1),
                               rep("#6495ED",6))) +
  theme_ridges()


## now vary the phylogeny
PDpruned<-read.tree("./trees/PDpruned_1Ktrees.tre")

physigSensiList_phy<-NULL
for (i in 1:ncol(morphodat)){
  col_name<-colnames(morphodat)[i]
  physigSensiList_phy[[i]]<-tree_physig(col_name,morphodat,PDpruned,n.tree="all"
                                        ,method="K")$tree.physig.estimates
}
names(physigSensiList_phy)<-colnames(morphodat)
ldply(physigSensiList_phy)->physigSensiMat_phy

quantile(physigSensiList_phy$LnMass$estimate,c(0.05,0.5,0.95))

physigSensiList_OOP_phy<-NULL
for (i in 1:ncol(OOPcap)){
  col_name<-colnames(OOPcap)[i]
  physigSensiList_OOP_phy[[i]]<-tree_physig(col_name,OOPcap,PDpruned,
                                            n.tree="all",
                                            method="K")$tree.physig.estimates
}
names(physigSensiList_OOP_phy)<-colnames(OOPcap)
ldply(physigSensiList_OOP_phy)->physigSensiMat_OOP_phy

rbind(physigSensiMat_phy,physigSensiMat_OOP_phy)->physigSensiMat_univ_phy

physigSensiMat_univ_phy %>%mutate(var = fct_reorder(.id, estimate, fun=median)) -> q
ggplot(q,aes(x=estimate,y=var))+ geom_point()+coord_cartesian(xlim=c(0,1.5))+theme_ridges()


a<-tree_physig_kmult(obdf,PDpruned,n.tree="all")
b<-tree_physig_kmult(dobdf,PDpruned,n.tree="all")
c<-tree_physig_kmult(flightmat_binaryDF,PDpruned,n.tree="all")
list(a$tree.physig.estimates,
     b$tree.physig.estimates,
     c$tree.physig.estimates)->l
names(l)<-c("eROM shape","Wing shape","Flight behavior")

ldply(l)->physigSensiMat_mult_phy
physigSensiMat_mult_phy %>%mutate(var = fct_reorder(.id, estimate, fun=median)) -> h

ggplot(h, aes(x = estimate, y = var))+ 
  geom_density_ridges2(aes(fill = .id),alpha=0.85,scale=0.5,rel_min_height=1E-10)+ 
  coord_cartesian(xlim=c(0,1.5)) +
  geom_vline(xintercept=1)+
  scale_fill_manual(values = c("#00AFBB", "#E7B800", "#FC4E07"))+
  theme_ridges()


#all together (only if using K)
rbind(q,h)->f
f %>%mutate(var = fct_reorder(.id, estimate, fun=median)) -> all_k_phy
ggplot(all_k_phy,aes(x=estimate,y=var)) + 
  geom_density_ridges2(aes(fill=.id),alpha=0.85,scale=1,
                       size=0.7,rel_min_height=1E-5) + 
  coord_cartesian(xlim=c(summary(all_k_phy$estimate)[1],
                         summary(all_k_phy$estimate)[6])) +
  geom_vline(xintercept=1) +
  scale_fill_manual(values = c(rep("#6495ED",1),rep("#FC4E07",2),
                               rep("#6495ED",3),rep("#FC4E07",2),
                               rep("#6495ED",1),rep("#FC4E07",1),
                               rep("#6495ED",6))) +
  theme_ridges()

